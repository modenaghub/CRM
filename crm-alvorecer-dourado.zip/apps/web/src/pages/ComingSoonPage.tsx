import { ReactNode } from 'react';
import { PageHeader } from '../components/ui/PageHeader';
import { Card, CardBody } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';

// Honestidade arquitetural (prompt-mestre, seção 52): "não simular
// funcionalidades" — para integrações que dependem de credenciais/infra
// externa ainda não conectadas nesta demonstração, mostramos exatamente o que
// já está pronto na arquitetura e o que falta ser configurado, em vez de um
// botão falso que finge funcionar.
export function ComingSoonPage({
  icon,
  title,
  description,
  ready,
  pending,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  ready: string[];
  pending: string[];
}) {
  return (
    <div className="space-y-6">
      <PageHeader title={title} subtitle={description} />

      <Card className="overflow-hidden">
        <div className="flex flex-col items-center gap-3 border-b border-slate-100 bg-gradient-to-b from-brand-50/60 to-white px-6 py-10 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-600 text-white">{icon}</div>
          <h2 className="text-base font-semibold text-slate-800">Arquitetura pronta — integração real fica para a próxima fase</h2>
          <p className="max-w-lg text-sm text-slate-500">
            Esta tela existe de propósito: a estrutura de dados, permissões e fluxos já foram construídos. O que falta é
            conectar a credencial/API do provedor externo — assim que isso acontecer, a tela passa a operar com dados reais,
            sem qualquer alteração de arquitetura.
          </p>
        </div>
        <CardBody className="grid gap-6 sm:grid-cols-2">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Já implementado</p>
            <ul className="space-y-2">
              {ready.map((r) => (
                <li key={r} className="flex items-start gap-2 text-sm text-slate-600">
                  <Badge tone="success" dot>
                    &nbsp;
                  </Badge>
                  {r}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Pendente de configuração</p>
            <ul className="space-y-2">
              {pending.map((r) => (
                <li key={r} className="flex items-start gap-2 text-sm text-slate-600">
                  <Badge tone="warning" dot>
                    &nbsp;
                  </Badge>
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
