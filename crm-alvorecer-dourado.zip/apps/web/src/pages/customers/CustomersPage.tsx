import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { FormEvent, MouseEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, friendlyError } from '../../lib/api';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, CardGridSkeleton } from '../../components/ui/EmptyState';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { Tabs } from '../../components/ui/Tabs';
import { Toast } from '../../components/ui/Toast';
import { useToast } from '../../hooks/useToast';
import { IconPlus, IconSearch, IconPhone, IconWhatsapp, IconMail, IconBuilding, IconUsers, IconClock, IconTrendingUp } from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const currencyCompact = new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1, style: 'currency', currency: 'BRL' });
const onlyDigits = (v: string) => v.replace(/\D/g, '');

function relativeDate(iso?: string | null) {
  if (!iso) return null;
  const diffMs = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diffMs / 86400000);
  if (days <= 0) return 'hoje';
  if (days === 1) return 'ontem';
  if (days < 30) return `há ${days}d`;
  const months = Math.floor(days / 30);
  if (months < 12) return `há ${months}m`;
  return `há ${Math.floor(months / 12)}a`;
}

// Fase (prompt-mestre): deriva o estágio comercial do cliente a partir dos
// dados reais — sem depender de um campo manual que desatualiza.
function customerStage(c: any): { label: string; tone: 'neutral' | 'brand' | 'success' | 'warning' | 'info' } {
  if (c.status === 'inactive') return { label: 'Inativo', tone: 'neutral' };
  if (c.salesCount > 0) return { label: 'Cliente ativo', tone: 'success' };
  if (c.openOpportunities > 0) return { label: 'Em negociação', tone: 'warning' };
  return { label: 'Prospecção', tone: 'info' };
}

export function CustomersPage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { message, notify } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ companyName: '', city: '', state: '', email: '', phone: '', whatsapp: '', abcClassification: 'B' });

  const { data, isLoading } = useQuery({
    queryKey: ['customers', search],
    queryFn: async () => (await api.get('/customers', { params: { search, pageSize: 100 } })).data,
  });

  const createMutation = useMutation({
    mutationFn: async () => api.post('/customers', form),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setOpen(false);
      setForm({ companyName: '', city: '', state: '', email: '', phone: '', whatsapp: '', abcClassification: 'B' });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  // Registro rápido de comunicação (prompt-mestre: histórico conectado ao Cliente
  // 360º) — cada ação de contato pelo card já vira uma atividade concluída.
  const logInteraction = useMutation({
    mutationFn: async (payload: { customerId: string; type: string; title: string }) =>
      api.post('/tasks', { ...payload, status: 'done', priority: 'normal' }),
    onSuccess: (_res, vars) => {
      queryClient.invalidateQueries({ queryKey: ['customer', vars.customerId] });
    },
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  function quickContact(e: MouseEvent, c: any, type: 'call' | 'whatsapp' | 'email') {
    e.stopPropagation();
    if (type === 'call' && c.phone) {
      window.open(`tel:${onlyDigits(c.phone)}`, '_self');
      logInteraction.mutate({ customerId: c.id, type: 'call', title: `Ligação para ${c.companyName}` });
      notify(`Ligação registrada para ${c.companyName}`);
    } else if (type === 'whatsapp' && c.whatsapp) {
      window.open(`https://wa.me/${onlyDigits(c.whatsapp)}`, '_blank', 'noopener');
      logInteraction.mutate({ customerId: c.id, type: 'whatsapp', title: `WhatsApp com ${c.companyName}` });
      notify(`WhatsApp registrado para ${c.companyName}`);
    } else if (type === 'email' && c.email) {
      window.open(`mailto:${c.email}`, '_self');
      logInteraction.mutate({ customerId: c.id, type: 'email', title: `E-mail para ${c.companyName}` });
      notify(`E-mail registrado para ${c.companyName}`);
    }
  }

  const filtered = (data?.data ?? []).filter((c: any) => statusFilter === 'all' || c.status === statusFilter);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Clientes"
        subtitle="Clique em um card para abrir o Cliente 360º, ou use os atalhos para ligar, chamar no WhatsApp ou enviar e-mail."
        actions={<Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Novo cliente</Button>}
      />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative max-w-sm flex-1">
          <IconSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" width={16} height={16} />
          <Input placeholder="Buscar por nome, CNPJ ou e-mail..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Tabs
          tabs={[
            { key: 'all', label: 'Todos', count: data?.data?.length },
            { key: 'active', label: 'Ativos', count: data?.data?.filter((c: any) => c.status === 'active').length },
            { key: 'inactive', label: 'Inativos', count: data?.data?.filter((c: any) => c.status === 'inactive').length },
          ]}
          active={statusFilter}
          onChange={setStatusFilter}
        />
      </div>

      {isLoading && <CardGridSkeleton />}
      {!isLoading && filtered.length === 0 && <EmptyState title="Nenhum cliente encontrado" description="Ajuste a busca ou cadastre um novo cliente." />}

      {!isLoading && filtered.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((c: any) => (
            <Card key={c.id} interactive onClick={() => navigate(`/customers/${c.id}`)} className="group flex flex-col">
              <CardBody className="flex flex-1 flex-col p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <Avatar name={c.companyName} size={40} />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-slate-800" title={c.companyName}>{c.companyName}</p>
                      <p className="flex items-center gap-1 text-xs text-slate-400">
                        <IconBuilding width={12} height={12} />
                        {[c.city, c.state].filter(Boolean).join('/') || 'Local não informado'}
                      </p>
                    </div>
                  </div>
                </div>

                {(() => {
                  const stage = customerStage(c);
                  return (
                    <div className="mt-3 flex flex-wrap items-center gap-1.5">
                      <Badge tone={stage.tone} dot>{stage.label}</Badge>
                      <Badge tone="brand">Classe {c.abcClassification ?? '—'}</Badge>
                      {c.openOpportunities > 0 && <Badge tone="warning">{c.openOpportunities} oport. aberta{c.openOpportunities > 1 ? 's' : ''}</Badge>}
                    </div>
                  );
                })()}

                <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 px-2.5 py-2">
                  <div className="text-center">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconTrendingUp width={11} height={11} /> Vendas
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700" title={c.salesTotal ? currency.format(Number(c.salesTotal)) : undefined}>
                      {c.salesCount > 0 ? `${c.salesCount} · ${currencyCompact.format(Number(c.salesTotal))}` : '—'}
                    </p>
                  </div>
                  <div className="text-center border-x border-slate-200">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconUsers width={11} height={11} /> Contatos
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700">{c.contactsCount ?? 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconClock width={11} height={11} /> Contato
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700">{relativeDate(c.lastInteractionAt) ?? '—'}</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-slate-50 pt-3">
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">Ticket médio</p>
                    <p className="text-sm font-semibold text-slate-700">{c.ticketAverage ? currency.format(Number(c.ticketAverage)) : '—'}</p>
                  </div>
                  <div className="flex items-center gap-1.5 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                    <button
                      title="Ligar"
                      disabled={!c.phone}
                      onClick={(e) => quickContact(e, c, 'call')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-brand-300 hover:bg-brand-50 hover:text-brand-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconPhone width={14} height={14} />
                    </button>
                    <button
                      title="WhatsApp"
                      disabled={!c.whatsapp}
                      onClick={(e) => quickContact(e, c, 'whatsapp')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconWhatsapp width={14} height={14} />
                    </button>
                    <button
                      title="E-mail"
                      disabled={!c.email}
                      onClick={(e) => quickContact(e, c, 'email')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-sky-300 hover:bg-sky-50 hover:text-sky-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconMail width={14} height={14} />
                    </button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Novo cliente">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Razão social / Nome da empresa">
            <Input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Cidade">
              <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </Field>
            <Field label="UF">
              <Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} maxLength={2} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="E-mail">
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
            <Field label="Telefone">
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="WhatsApp">
              <Input value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} placeholder="Ex.: 5511999999999" />
            </Field>
            <Field label="Classificação ABC">
              <Select value={form.abcClassification} onChange={(e) => setForm({ ...form, abcClassification: e.target.value })}>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
              </Select>
            </Field>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">
            {createMutation.isPending ? 'Salvando...' : 'Salvar cliente'}
          </Button>
        </form>
      </Modal>

      <Toast message={message} />
    </div>
  );
}
