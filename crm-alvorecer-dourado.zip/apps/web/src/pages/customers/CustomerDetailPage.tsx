import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { FormEvent, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, friendlyError } from '../../lib/api';
import { Card, CardBody } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select, Textarea } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { Toast } from '../../components/ui/Toast';
import { useToast } from '../../hooks/useToast';
import { LoadingState, EmptyState } from '../../components/ui/EmptyState';
import {
  IconBuilding, IconChevronRight, IconFileText, IconTrendingUp, IconEdit,
  IconPhone, IconWhatsapp, IconMail, IconCalendar, IconArrowDownLeft, IconArrowUpRight, IconClock,
} from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateBR = (v?: string | null) => (v ? new Date(v).toLocaleDateString('pt-BR') : '—');
const dateTimeBR = (v?: string | null) => (v ? new Date(v).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');

const quoteStatusTone: Record<string, any> = { draft: 'neutral', sent: 'info', approved: 'success', rejected: 'danger', converted: 'brand', expired: 'neutral' };
const quoteStatusLabel: Record<string, string> = { draft: 'Rascunho', sent: 'Enviado', approved: 'Aprovado', rejected: 'Rejeitado', converted: 'Convertido', expired: 'Expirado' };
const orderStatusTone: Record<string, any> = { pending: 'neutral', confirmed: 'info', invoiced: 'brand', completed: 'success', cancelled: 'danger' };
const orderStatusLabel: Record<string, string> = { pending: 'Pendente', confirmed: 'Confirmado', invoiced: 'Faturado', completed: 'Concluído', cancelled: 'Cancelado' };

const COMM_TYPES = ['call', 'whatsapp', 'email', 'meeting'] as const;
type CommType = (typeof COMM_TYPES)[number];
const commIcon: Record<CommType, any> = { call: IconPhone, whatsapp: IconWhatsapp, email: IconMail, meeting: IconCalendar };
const commLabel: Record<CommType, string> = { call: 'Ligação', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reunião' };
const commTone: Record<CommType, any> = { call: 'brand', whatsapp: 'success', email: 'info', meeting: 'warning' };

export function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const { message, notify } = useToast();
  const [tab, setTab] = useState('resumo');
  const [editOpen, setEditOpen] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>(null);
  const [logModal, setLogModal] = useState<{ open: boolean; type: CommType }>({ open: false, type: 'call' });
  const [logForm, setLogForm] = useState({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done' as 'done' | 'schedule', dueAt: '' });

  const { data: customer, isLoading } = useQuery({
    queryKey: ['customer', id],
    queryFn: async () => (await api.get(`/customers/${id}`)).data,
    enabled: !!id,
  });

  const updateCustomer = useMutation({
    mutationFn: async () => api.patch(`/customers/${id}`, editForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer', id] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setEditOpen(false);
      notify('Dados do cliente atualizados');
    },
    onError: (err) => setEditError(friendlyError(err)),
  });

  const logInteraction = useMutation({
    mutationFn: async () => {
      const type = logModal.type;
      const title = `${commLabel[type]} ${logForm.mode === 'done' ? 'com' : 'agendada com'} ${customer.companyName}`;
      return api.post('/tasks', {
        type,
        title,
        description: logForm.description || undefined,
        customerId: id,
        status: logForm.mode === 'done' ? 'done' : 'pending',
        direction: type !== 'meeting' && logForm.mode === 'done' ? logForm.direction : undefined,
        durationMinutes: type === 'call' && logForm.mode === 'done' && logForm.durationMinutes ? Number(logForm.durationMinutes) : undefined,
        dueAt: logForm.mode === 'schedule' && logForm.dueAt ? new Date(logForm.dueAt).toISOString() : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer', id] });
      setLogModal({ open: false, type: 'call' });
      setLogForm({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done', dueAt: '' });
      notify(logForm.mode === 'done' ? 'Interação registrada no histórico' : 'Atividade agendada');
    },
  });

  if (isLoading) return <LoadingState />;
  if (!customer) return <EmptyState title="Cliente não encontrado" />;

  function openLog(type: CommType) {
    setLogForm({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done', dueAt: '' });
    setLogModal({ open: true, type });
  }

  function openEdit() {
    setEditForm({
      companyName: customer.companyName ?? '',
      city: customer.city ?? '',
      state: customer.state ?? '',
      email: customer.email ?? '',
      phone: customer.phone ?? '',
      whatsapp: customer.whatsapp ?? '',
      document: customer.document ?? '',
      paymentTerms: customer.paymentTerms ?? '',
      abcClassification: customer.abcClassification ?? 'B',
      status: customer.status ?? 'active',
    });
    setEditError(null);
    setEditOpen(true);
  }

  const communications = customer.tasks
    .filter((t: any) => COMM_TYPES.includes(t.type))
    .sort((a: any, b: any) => new Date(b.completedAt ?? b.dueAt ?? b.createdAt).getTime() - new Date(a.completedAt ?? a.dueAt ?? a.createdAt).getTime());

  const timeline = [
    ...customer.opportunities.map((o: any) => ({ type: 'opportunity', date: o.createdAt, title: `Oportunidade criada: ${o.title}`, sub: o.value ? currency.format(Number(o.value)) : undefined })),
    ...customer.quotes.map((q: any) => ({ type: 'quote', date: q.createdAt, title: `Orçamento #${q.number} — ${quoteStatusLabel[q.status] ?? q.status}`, sub: currency.format(Number(q.totalValue)) })),
    ...customer.salesOrders.map((s: any) => ({ type: 'order', date: s.createdAt, title: `Pedido #${s.number} — ${orderStatusLabel[s.status] ?? s.status}`, sub: currency.format(Number(s.totalValue)) })),
    ...customer.tasks
      .filter((t: any) => !COMM_TYPES.includes(t.type))
      .map((t: any) => ({ type: 'task', date: t.createdAt, title: `Tarefa: ${t.title}`, sub: t.status === 'done' ? 'Concluída' : 'Pendente' })),
    ...communications.map((t: any) => ({
      type: t.type,
      date: t.completedAt ?? t.dueAt ?? t.createdAt,
      title: t.title,
      sub: t.status === 'done' ? 'Concluída' : 'Agendada',
    })),
    ...customer.notes.map((n: any) => ({ type: 'note', date: n.createdAt, title: 'Nota interna', sub: n.body })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const tabs = [
    { key: 'resumo', label: 'Resumo' },
    { key: 'timeline', label: 'Timeline', count: timeline.length },
    { key: 'comunicacao', label: 'Comunicação', count: communications.length },
    { key: 'oportunidades', label: 'Oportunidades', count: customer.opportunities.length },
    { key: 'vendas', label: 'Vendas', count: customer.quotes.length + customer.salesOrders.length },
    { key: 'contatos', label: 'Contatos', count: customer.contacts.length },
    { key: 'tarefas', label: 'Tarefas', count: customer.tasks.filter((t: any) => !COMM_TYPES.includes(t.type)).length },
    { key: 'notas', label: 'Notas', count: customer.notes.length },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-1.5 text-xs text-slate-400">
        <Link to="/customers" className="hover:text-slate-600">Clientes</Link>
        <IconChevronRight width={12} height={12} />
        <span className="text-slate-500">{customer.companyName}</span>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
            <IconBuilding width={26} height={26} />
          </div>
          <div>
            <h1 className="font-display text-xl font-semibold text-slate-800">{customer.companyName}</h1>
            <p className="text-sm text-slate-500">{[customer.city, customer.state].filter(Boolean).join('/') || 'Localização não informada'} · {customer.document || 'sem documento'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {(() => {
            const salesCount = (customer.salesOrders ?? []).filter((s: any) => s.status === 'completed').length;
            const openOpp = (customer.opportunities ?? []).filter((o: any) => o.status === 'open').length;
            const stage = customer.status === 'inactive'
              ? { label: 'Inativo', tone: 'neutral' as const }
              : salesCount > 0
              ? { label: 'Cliente ativo', tone: 'success' as const }
              : openOpp > 0
              ? { label: 'Em negociação', tone: 'warning' as const }
              : { label: 'Prospecção', tone: 'info' as const };
            return <Badge tone={stage.tone} dot>{stage.label}</Badge>;
          })()}
          <Badge tone="brand">Classe {customer.abcClassification ?? '—'}</Badge>
          <Button variant="secondary" size="sm" onClick={openEdit}>
            <IconEdit width={14} height={14} /> Editar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Ticket médio</p><p className="mt-1 text-lg font-semibold text-slate-800">{customer.ticketAverage ? currency.format(Number(customer.ticketAverage)) : '—'}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">LTV</p><p className="mt-1 text-lg font-semibold text-slate-800">{customer.ltv ? currency.format(Number(customer.ltv)) : '—'}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Última compra</p><p className="mt-1 text-lg font-semibold text-slate-800">{dateBR(customer.lastPurchaseAt)}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Oportunidades abertas</p><p className="mt-1 text-lg font-semibold text-slate-800">{customer.opportunities.filter((o: any) => o.status === 'open').length}</p></CardBody></Card>
      </div>

      {/* Ações rápidas de comunicação — histórico conectado ao Cliente 360º */}
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" size="sm" onClick={() => openLog('call')}><IconPhone width={14} height={14} /> Registrar ligação</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('whatsapp')}><IconWhatsapp width={14} height={14} /> Registrar WhatsApp</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('email')}><IconMail width={14} height={14} /> Registrar e-mail</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('meeting')}><IconCalendar width={14} height={14} /> Agendar reunião</Button>
      </div>

      <Card>
        <Tabs tabs={tabs} active={tab} onChange={setTab} />
        <CardBody>
          {tab === 'resumo' && (
            <div className="grid gap-6 sm:grid-cols-2">
              <div className="space-y-2 text-sm">
                <p><span className="text-slate-400">Razão social:</span> <span className="text-slate-700">{customer.companyName}</span></p>
                <p><span className="text-slate-400">E-mail:</span> <span className="text-slate-700">{customer.email || '—'}</span></p>
                <p><span className="text-slate-400">Telefone:</span> <span className="text-slate-700">{customer.phone || '—'}</span></p>
                <p><span className="text-slate-400">WhatsApp:</span> <span className="text-slate-700">{customer.whatsapp || '—'}</span></p>
                <p><span className="text-slate-400">Condição de pagamento:</span> <span className="text-slate-700">{customer.paymentTerms || '—'}</span></p>
                <p><span className="text-slate-400">Vendedor responsável:</span> <span className="text-slate-700">{customer.ownerId ? 'Atribuído' : '—'}</span></p>
              </div>
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Próximas atividades</p>
                {customer.tasks.filter((t: any) => t.status !== 'done').length === 0 && <p className="text-sm text-slate-400">Nenhuma pendência.</p>}
                {customer.tasks.filter((t: any) => t.status !== 'done').slice(0, 4).map((t: any) => (
                  <div key={t.id} className="flex items-center justify-between border-b border-slate-50 py-2 text-sm last:border-0">
                    <span className="text-slate-600">{t.title}</span>
                    <span className="text-xs text-slate-400">{dateBR(t.dueAt)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'timeline' && (
            <div className="space-y-0">
              {timeline.length === 0 && <p className="py-6 text-center text-sm text-slate-400">Sem eventos registrados ainda.</p>}
              {timeline.map((e, i) => (
                <div key={i} className="flex gap-3 border-b border-slate-50 py-3 last:border-0">
                  <div className="mt-1 h-2 w-2 shrink-0 rounded-full bg-brand-500" />
                  <div className="min-w-0">
                    <p className="text-sm text-slate-700">{e.title}</p>
                    {e.sub && <p className="truncate text-xs text-slate-400">{e.sub}</p>}
                    <p className="text-[11px] text-slate-400">{dateBR(e.date)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'comunicacao' && (
            <div className="space-y-0">
              {communications.length === 0 && (
                <EmptyState title="Nenhuma interação registrada" description="Use os atalhos acima para registrar ligações, WhatsApp, e-mails ou agendar reuniões." />
              )}
              {communications.map((t: any) => {
                const Icon = commIcon[t.type as CommType];
                const done = t.status === 'done';
                return (
                  <div key={t.id} className="flex items-start gap-3 border-b border-slate-50 py-3.5 last:border-0">
                    <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${done ? 'bg-slate-100 text-slate-500' : 'bg-amber-50 text-amber-600'}`}>
                      <Icon width={16} height={16} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-medium text-slate-700">{t.title}</p>
                        <Badge tone={commTone[t.type as CommType]}>{commLabel[t.type as CommType]}</Badge>
                        {t.direction && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                            {t.direction === 'inbound' ? <IconArrowDownLeft width={11} height={11} /> : <IconArrowUpRight width={11} height={11} />}
                            {t.direction === 'inbound' ? 'Recebida' : 'Realizada'}
                          </span>
                        )}
                        {t.durationMinutes != null && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                            <IconClock width={11} height={11} /> {t.durationMinutes} min
                          </span>
                        )}
                        <Badge tone={done ? 'success' : 'info'}>{done ? 'Concluída' : 'Agendada'}</Badge>
                      </div>
                      {t.description && <p className="mt-1 text-sm text-slate-500">{t.description}</p>}
                      <p className="mt-1 text-[11px] text-slate-400">{dateTimeBR(t.completedAt ?? t.dueAt ?? t.createdAt)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'oportunidades' && (
            <div className="divide-y divide-slate-50">
              {customer.opportunities.length === 0 && <EmptyState title="Nenhuma oportunidade" />}
              {customer.opportunities.map((o: any) => (
                <div key={o.id} className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-2.5">
                    <IconTrendingUp className="text-slate-400" width={16} height={16} />
                    <span className="text-sm text-slate-700">{o.title}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-500">{o.value ? currency.format(Number(o.value)) : '—'}</span>
                    <Badge tone={o.status === 'won' ? 'success' : o.status === 'lost' ? 'danger' : 'info'}>{o.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'vendas' && (
            <div className="space-y-6">
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Orçamentos</p>
                <div className="divide-y divide-slate-50">
                  {customer.quotes.length === 0 && <p className="py-3 text-sm text-slate-400">Nenhum orçamento.</p>}
                  {customer.quotes.map((q: any) => (
                    <div key={q.id} className="flex items-center justify-between py-2.5">
                      <div className="flex items-center gap-2.5">
                        <IconFileText className="text-slate-400" width={16} height={16} />
                        <span className="text-sm text-slate-700">Orçamento #{q.number}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-slate-500">{currency.format(Number(q.totalValue))}</span>
                        <Badge tone={quoteStatusTone[q.status]}>{quoteStatusLabel[q.status] ?? q.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Pedidos de venda</p>
                <div className="divide-y divide-slate-50">
                  {customer.salesOrders.length === 0 && <p className="py-3 text-sm text-slate-400">Nenhum pedido.</p>}
                  {customer.salesOrders.map((s: any) => (
                    <div key={s.id} className="flex items-center justify-between py-2.5">
                      <span className="text-sm text-slate-700">Pedido #{s.number}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-slate-500">{currency.format(Number(s.totalValue))}</span>
                        <Badge tone={orderStatusTone[s.status]}>{orderStatusLabel[s.status] ?? s.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === 'contatos' && (
            <div className="divide-y divide-slate-50">
              {customer.contacts.length === 0 && <EmptyState title="Nenhum contato cadastrado" />}
              {customer.contacts.map((c: any) => (
                <div key={c.id} className="flex items-center gap-3 py-3">
                  <Avatar name={c.name} size={32} />
                  <div>
                    <p className="text-sm font-medium text-slate-700">{c.name} {c.isPrimary && <Badge tone="brand" className="ml-1">Principal</Badge>}</p>
                    <p className="text-xs text-slate-400">{c.jobTitle} · {c.email || c.phone || 'sem contato'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'tarefas' && (
            <div className="divide-y divide-slate-50">
              {customer.tasks.filter((t: any) => !COMM_TYPES.includes(t.type)).length === 0 && <EmptyState title="Nenhuma tarefa" />}
              {customer.tasks.filter((t: any) => !COMM_TYPES.includes(t.type)).map((t: any) => (
                <div key={t.id} className="flex items-center justify-between py-3">
                  <span className="text-sm text-slate-700">{t.title}</span>
                  <Badge tone={t.status === 'done' ? 'success' : 'neutral'}>{t.status === 'done' ? 'Concluída' : 'Pendente'}</Badge>
                </div>
              ))}
            </div>
          )}

          {tab === 'notas' && (
            <div className="space-y-3">
              {customer.notes.length === 0 && <EmptyState title="Nenhuma nota" />}
              {customer.notes.map((n: any) => (
                <div key={n.id} className="rounded-lg bg-slate-50 p-3 text-sm text-slate-600">
                  {n.body}
                  <p className="mt-1 text-[11px] text-slate-400">{dateBR(n.createdAt)}</p>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      {/* Modal: registrar/agendar interação de comunicação */}
      <Modal open={logModal.open} onClose={() => setLogModal({ open: false, type: 'call' })} title={`${commLabel[logModal.type]} — ${customer.companyName}`}>
        <div className="space-y-4">
          <div className="flex rounded-lg bg-slate-100 p-1 text-sm">
            <button
              type="button"
              onClick={() => setLogForm((f) => ({ ...f, mode: 'done' }))}
              className={`flex-1 rounded-md py-1.5 font-medium transition-colors ${logForm.mode === 'done' ? 'bg-white text-slate-800 shadow-card' : 'text-slate-500'}`}
            >
              Já aconteceu
            </button>
            <button
              type="button"
              onClick={() => setLogForm((f) => ({ ...f, mode: 'schedule' }))}
              className={`flex-1 rounded-md py-1.5 font-medium transition-colors ${logForm.mode === 'schedule' ? 'bg-white text-slate-800 shadow-card' : 'text-slate-500'}`}
            >
              Agendar para depois
            </button>
          </div>

          {logForm.mode === 'done' && logModal.type !== 'meeting' && (
            <Field label="Direção">
              <Select value={logForm.direction} onChange={(e) => setLogForm((f) => ({ ...f, direction: e.target.value }))}>
                <option value="outbound">Realizada por nós (saída)</option>
                <option value="inbound">Recebida do cliente (entrada)</option>
              </Select>
            </Field>
          )}

          {logForm.mode === 'done' && logModal.type === 'call' && (
            <Field label="Duração (minutos)">
              <Input type="number" min="0" value={logForm.durationMinutes} onChange={(e) => setLogForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
            </Field>
          )}

          {logForm.mode === 'schedule' && (
            <Field label="Data e hora">
              <Input type="datetime-local" value={logForm.dueAt} onChange={(e) => setLogForm((f) => ({ ...f, dueAt: e.target.value }))} required />
            </Field>
          )}

          <Field label={logModal.type === 'email' ? 'Resumo / assunto' : 'Anotações'}>
            <Textarea rows={3} value={logForm.description} onChange={(e) => setLogForm((f) => ({ ...f, description: e.target.value }))} placeholder="O que foi conversado..." />
          </Field>

          <Button
            className="w-full"
            disabled={logInteraction.isPending || (logForm.mode === 'schedule' && !logForm.dueAt)}
            onClick={() => logInteraction.mutate()}
          >
            {logInteraction.isPending ? 'Salvando...' : logForm.mode === 'done' ? 'Registrar no histórico' : 'Agendar'}
          </Button>
        </div>
      </Modal>

      {/* Modal: editar dados do cliente */}
      <Modal open={editOpen} onClose={() => setEditOpen(false)} title="Editar cliente" wide>
        {editForm && (
          <div className="space-y-4">
            <Field label="Razão social / Nome da empresa">
              <Input value={editForm.companyName} onChange={(e) => setEditForm({ ...editForm, companyName: e.target.value })} required />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Documento (CNPJ/CPF)">
                <Input value={editForm.document} onChange={(e) => setEditForm({ ...editForm, document: e.target.value })} />
              </Field>
              <Field label="Condição de pagamento">
                <Input value={editForm.paymentTerms} onChange={(e) => setEditForm({ ...editForm, paymentTerms: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Cidade">
                <Input value={editForm.city} onChange={(e) => setEditForm({ ...editForm, city: e.target.value })} />
              </Field>
              <Field label="UF">
                <Input value={editForm.state} onChange={(e) => setEditForm({ ...editForm, state: e.target.value })} maxLength={2} />
              </Field>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="E-mail">
                <Input type="email" value={editForm.email} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} />
              </Field>
              <Field label="Telefone">
                <Input value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} />
              </Field>
              <Field label="WhatsApp">
                <Input value={editForm.whatsapp} onChange={(e) => setEditForm({ ...editForm, whatsapp: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Classificação ABC">
                <Select value={editForm.abcClassification} onChange={(e) => setEditForm({ ...editForm, abcClassification: e.target.value })}>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                </Select>
              </Field>
              <Field label="Status">
                <Select value={editForm.status} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}>
                  <option value="active">Ativo</option>
                  <option value="inactive">Inativo</option>
                </Select>
              </Field>
            </div>
            {editError && <p className="text-sm text-red-600">{editError}</p>}
            <Button className="w-full" disabled={updateCustomer.isPending} onClick={() => updateCustomer.mutate()}>
              {updateCustomer.isPending ? 'Salvando...' : 'Salvar alterações'}
            </Button>
          </div>
        )}
      </Modal>

      <Toast message={message} />
    </div>
  );
}
