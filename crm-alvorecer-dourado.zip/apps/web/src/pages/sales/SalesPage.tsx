import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api, friendlyError } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Tabs } from '../../components/ui/Tabs';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, LoadingState } from '../../components/ui/EmptyState';
import { StatCard } from '../../components/ui/StatCard';
import { IconPlus, IconFileText, IconCart, IconTrendingUp, IconFlag } from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateBR = (v?: string) => (v ? new Date(v).toLocaleDateString('pt-BR') : '—');

const quoteStatusTone: Record<string, any> = { draft: 'neutral', sent: 'info', approved: 'success', rejected: 'danger', converted: 'brand', expired: 'neutral' };
const quoteStatusLabel: Record<string, string> = { draft: 'Rascunho', sent: 'Enviado', approved: 'Aprovado', rejected: 'Rejeitado', converted: 'Convertido', expired: 'Expirado' };
const orderStatusTone: Record<string, any> = { pending: 'neutral', confirmed: 'info', invoiced: 'brand', completed: 'success', cancelled: 'danger' };
const orderStatusLabel: Record<string, string> = { pending: 'Pendente', confirmed: 'Confirmado', invoiced: 'Faturado', completed: 'Concluído', cancelled: 'Cancelado' };

type ItemRow = { productId: string; quantity: string; unitPrice: string };

export function SalesPage() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState('quotes');
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [customerId, setCustomerId] = useState('');
  const [items, setItems] = useState<ItemRow[]>([{ productId: '', quantity: '1', unitPrice: '' }]);
  const [sellerFilter, setSellerFilter] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const { data: customers } = useQuery({ queryKey: ['customers-all'], queryFn: async () => (await api.get('/customers', { params: { pageSize: 100 } })).data });
  const { data: products } = useQuery({ queryKey: ['products-all'], queryFn: async () => (await api.get('/products', { params: { pageSize: 100 } })).data });
  const { data: quotes, isLoading: loadingQuotes } = useQuery({ queryKey: ['quotes'], queryFn: async () => (await api.get('/quotes')).data });
  const { data: orders, isLoading: loadingOrders } = useQuery({ queryKey: ['sales-orders'], queryFn: async () => (await api.get('/sales-orders')).data });
  const { data: sellers } = useQuery({ queryKey: ['rpt-sellers-sales'], queryFn: async () => (await api.get('/reports/seller-performance')).data });

  const customerMap = useMemo(() => Object.fromEntries((customers?.data ?? []).map((c: any) => [c.id, c.companyName])), [customers]);
  const productMap = useMemo(() => Object.fromEntries((products?.data ?? []).map((p: any) => [p.id, p])), [products]);
  const sellerMap = useMemo(() => Object.fromEntries((sellers ?? []).map((s: any) => [s.id, s.name])), [sellers]);

  const inRange = (iso?: string) => {
    if (!iso) return true;
    const d = new Date(iso).getTime();
    if (fromDate && d < new Date(fromDate).getTime()) return false;
    if (toDate && d > new Date(toDate).getTime() + 86400000) return false;
    return true;
  };

  const filteredQuotes = useMemo(
    () => (quotes ?? []).filter((q: any) => (!sellerFilter || q.sellerId === sellerFilter) && inRange(q.createdAt)),
    [quotes, sellerFilter, fromDate, toDate],
  );
  const filteredOrders = useMemo(
    () => (orders ?? []).filter((o: any) => (!sellerFilter || o.sellerId === sellerFilter) && inRange(o.createdAt)),
    [orders, sellerFilter, fromDate, toDate],
  );

  const salesStats = useMemo(() => {
    const completed = filteredOrders.filter((o: any) => o.status === 'completed');
    const revenue = completed.reduce((acc: number, o: any) => acc + Number(o.totalValue), 0);
    return {
      quotesCount: filteredQuotes.length,
      ordersCount: filteredOrders.length,
      revenue,
      avgTicket: completed.length > 0 ? revenue / completed.length : 0,
    };
  }, [filteredQuotes, filteredOrders]);

  const createQuote = useMutation({
    mutationFn: async () =>
      api.post('/quotes', {
        customerId,
        items: items.filter((i) => i.productId).map((i) => ({ productId: i.productId, quantity: Number(i.quantity), unitPrice: Number(i.unitPrice) })),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['quotes'] });
      setOpen(false);
      setCustomerId('');
      setItems([{ productId: '', quantity: '1', unitPrice: '' }]);
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const convertQuote = useMutation({
    mutationFn: async (id: string) => api.post(`/quotes/${id}/convert`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['quotes'] });
      queryClient.invalidateQueries({ queryKey: ['sales-orders'] });
      setTab('orders');
    },
  });

  const updateOrderStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => api.patch(`/sales-orders/${id}/status`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sales-orders'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      queryClient.invalidateQueries({ queryKey: ['goals'] });
    },
  });

  function updateItem(idx: number, patch: Partial<ItemRow>) {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  }
  function onSelectProduct(idx: number, productId: string) {
    const product = productMap[productId];
    updateItem(idx, { productId, unitPrice: product?.price ? String(product.price) : '' });
  }

  const total = items.reduce((acc, i) => acc + (Number(i.quantity) || 0) * (Number(i.unitPrice) || 0), 0);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Vendas"
        subtitle="Fluxo comercial: orçamento → pedido → venda concluída."
        actions={<Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Novo orçamento</Button>}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Orçamentos" value={salesStats.quotesCount} icon={<IconFileText width={16} height={16} />} tone="info" />
        <StatCard label="Pedidos de venda" value={salesStats.ordersCount} icon={<IconCart width={16} height={16} />} tone="brand" />
        <StatCard label="Faturamento (concluídos)" value={currency.format(salesStats.revenue)} icon={<IconTrendingUp width={16} height={16} />} tone="success" />
        <StatCard label="Ticket médio" value={currency.format(salesStats.avgTicket)} icon={<IconFlag width={16} height={16} />} tone="violet" />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Select value={sellerFilter} onChange={(e) => setSellerFilter(e.target.value)} className="w-auto">
          <option value="">Todos os vendedores</option>
          {(sellers ?? []).map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </Select>
        <div className="flex items-center gap-1.5 text-xs text-slate-500">
          <span>De</span>
          <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="w-auto" />
          <span>até</span>
          <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="w-auto" />
        </div>
        {(sellerFilter || fromDate || toDate) && (
          <button onClick={() => { setSellerFilter(''); setFromDate(''); setToDate(''); }} className="text-xs font-medium text-brand-600 hover:underline">Limpar filtros</button>
        )}
      </div>

      <Card>
        <Tabs
          tabs={[
            { key: 'quotes', label: 'Orçamentos', count: filteredQuotes.length },
            { key: 'orders', label: 'Pedidos de venda', count: filteredOrders.length },
          ]}
          active={tab}
          onChange={setTab}
        />
        <CardBody>
          {tab === 'quotes' && (
            <>
              {loadingQuotes && <LoadingState />}
              {!loadingQuotes && filteredQuotes.length === 0 && <EmptyState title="Nenhum orçamento encontrado" description="Ajuste os filtros ou crie um novo orçamento." />}
              {!loadingQuotes && filteredQuotes.length > 0 && (
                <table className="w-full text-sm">
                  <thead className="text-left text-xs font-medium uppercase text-slate-500">
                    <tr>
                      <th className="py-2">Número</th>
                      <th className="py-2">Cliente</th>
                      <th className="py-2">Vendedor</th>
                      <th className="py-2">Valor</th>
                      <th className="py-2">Status</th>
                      <th className="py-2">Data</th>
                      <th className="py-2"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredQuotes.map((q: any) => (
                      <tr key={q.id}>
                        <td className="py-2.5 font-medium text-slate-700">#{q.number}</td>
                        <td className="py-2.5 text-slate-600">{customerMap[q.customerId] ?? '—'}</td>
                        <td className="py-2.5 text-slate-500">{sellerMap[q.sellerId] ?? '—'}</td>
                        <td className="py-2.5 text-slate-600">{currency.format(Number(q.totalValue))}</td>
                        <td className="py-2.5"><Badge tone={quoteStatusTone[q.status]}>{quoteStatusLabel[q.status] ?? q.status}</Badge></td>
                        <td className="py-2.5 text-slate-500">{dateBR(q.createdAt)}</td>
                        <td className="py-2.5 text-right">
                          {q.status !== 'converted' && (
                            <Button size="sm" variant="secondary" onClick={() => convertQuote.mutate(q.id)} disabled={convertQuote.isPending}>
                              Converter em pedido
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          )}

          {tab === 'orders' && (
            <>
              {loadingOrders && <LoadingState />}
              {!loadingOrders && filteredOrders.length === 0 && <EmptyState title="Nenhum pedido de venda encontrado" description="Ajuste os filtros ou converta um orçamento aprovado em pedido." />}
              {!loadingOrders && filteredOrders.length > 0 && (
                <table className="w-full text-sm">
                  <thead className="text-left text-xs font-medium uppercase text-slate-500">
                    <tr>
                      <th className="py-2">Número</th>
                      <th className="py-2">Cliente</th>
                      <th className="py-2">Vendedor</th>
                      <th className="py-2">Valor</th>
                      <th className="py-2">Status</th>
                      <th className="py-2">Data</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredOrders.map((o: any) => (
                      <tr key={o.id}>
                        <td className="py-2.5 font-medium text-slate-700">#{o.number}</td>
                        <td className="py-2.5 text-slate-600">{customerMap[o.customerId] ?? '—'}</td>
                        <td className="py-2.5 text-slate-500">{sellerMap[o.sellerId] ?? '—'}</td>
                        <td className="py-2.5 text-slate-600">{currency.format(Number(o.totalValue))}</td>
                        <td className="py-2.5">
                          <Select
                            value={o.status}
                            onChange={(e) => updateOrderStatus.mutate({ id: o.id, status: e.target.value })}
                            className={`w-40 !py-1 text-xs ${orderStatusTone[o.status] === 'success' ? 'text-emerald-700' : ''}`}
                          >
                            {Object.entries(orderStatusLabel).map(([k, v]) => (
                              <option key={k} value={k}>{v}</option>
                            ))}
                          </Select>
                        </td>
                        <td className="py-2.5 text-slate-500">{dateBR(o.createdAt)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          )}
        </CardBody>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Novo orçamento" wide>
        <div className="space-y-4">
          <Field label="Cliente">
            <Select value={customerId} onChange={(e) => setCustomerId(e.target.value)} required>
              <option value="">Selecione...</option>
              {(customers?.data ?? []).map((c: any) => (
                <option key={c.id} value={c.id}>{c.companyName}</option>
              ))}
            </Select>
          </Field>

          <div>
            <p className="mb-2 text-xs font-medium text-slate-600">Itens</p>
            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Select value={item.productId} onChange={(e) => onSelectProduct(idx, e.target.value)} className="flex-1">
                    <option value="">Selecione um produto...</option>
                    {(products?.data ?? []).map((p: any) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </Select>
                  <Input type="number" min="0.01" step="0.01" value={item.quantity} onChange={(e) => updateItem(idx, { quantity: e.target.value })} className="w-20" placeholder="Qtd" />
                  <Input type="number" min="0" step="0.01" value={item.unitPrice} onChange={(e) => updateItem(idx, { unitPrice: e.target.value })} className="w-28" placeholder="Preço" />
                  <button
                    type="button"
                    onClick={() => setItems((prev) => prev.filter((_, i) => i !== idx))}
                    className="text-slate-400 hover:text-red-500"
                    disabled={items.length === 1}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setItems((prev) => [...prev, { productId: '', quantity: '1', unitPrice: '' }])}
              className="mt-2 text-xs font-medium text-brand-600 hover:underline"
            >
              + Adicionar item
            </button>
          </div>

          <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3 text-sm">
            <span className="text-slate-500">Total estimado</span>
            <span className="font-semibold text-slate-800">{currency.format(total)}</span>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button
            onClick={() => {
              setError(null);
              createQuote.mutate();
            }}
            disabled={createQuote.isPending || !customerId || !items.some((i) => i.productId)}
            className="w-full"
          >
            {createQuote.isPending ? 'Salvando...' : 'Salvar orçamento'}
          </Button>
        </div>
      </Modal>
    </div>
  );
}
