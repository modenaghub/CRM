import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { FormEvent, useState } from 'react';
import { api, friendlyError } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, LoadingState } from '../../components/ui/EmptyState';
import { IconPlus, IconFlag } from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const metricLabel: Record<string, string> = { revenue: 'Receita', new_customers: 'Novos clientes', opportunities_won: 'Oportunidades ganhas' };
const scopeLabel: Record<string, string> = { organization: 'Organização', team: 'Equipe', user: 'Vendedor' };

function formatValue(metric: string, value: number) {
  return metric === 'revenue' ? currency.format(value) : String(value);
}

export function GoalsPage() {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const today = new Date();
  const firstDay = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
  const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().slice(0, 10);
  const [form, setForm] = useState({ scopeType: 'organization', metric: 'revenue', targetValue: '', periodStart: firstDay, periodEnd: lastDay });

  const { data, isLoading } = useQuery({ queryKey: ['goals'], queryFn: async () => (await api.get('/goals')).data });

  const createMutation = useMutation({
    mutationFn: async () => api.post('/goals', { ...form, targetValue: Number(form.targetValue) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setOpen(false);
      setForm({ scopeType: 'organization', metric: 'revenue', targetValue: '', periodStart: firstDay, periodEnd: lastDay });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Metas"
        subtitle="Meta x realizado, calculado em tempo real a partir das vendas, clientes e oportunidades."
        actions={<Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Nova meta</Button>}
      />

      {isLoading && <LoadingState />}
      {!isLoading && (data ?? []).length === 0 && <EmptyState title="Nenhuma meta cadastrada" description="Defina metas por organização, equipe ou vendedor." />}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {(data ?? []).map((g: any) => (
          <Card key={g.id}>
            <CardBody>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  <IconFlag width={13} height={13} /> {scopeLabel[g.scopeType]}
                </span>
                <span className="text-xs text-slate-400">{new Date(g.periodStart).toLocaleDateString('pt-BR')} – {new Date(g.periodEnd).toLocaleDateString('pt-BR')}</span>
              </div>
              <p className="mt-2 text-sm font-medium text-slate-700">{metricLabel[g.metric]}</p>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="text-lg font-semibold text-slate-800">{formatValue(g.metric, Number(g.achievedValue))}</span>
                <span className="text-xs text-slate-400">meta {formatValue(g.metric, Number(g.targetValue))}</span>
              </div>
              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100">
                <div className={`h-full rounded-full ${g.progressPercent >= 100 ? 'bg-emerald-500' : 'bg-brand-600'}`} style={{ width: `${Math.min(100, g.progressPercent)}%` }} />
              </div>
              <p className="mt-1 text-xs text-slate-400">{g.progressPercent}%</p>
            </CardBody>
          </Card>
        ))}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Nova meta">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Escopo">
            <Select value={form.scopeType} onChange={(e) => setForm({ ...form, scopeType: e.target.value })}>
              <option value="organization">Organização</option>
              <option value="team">Equipe</option>
              <option value="user">Vendedor</option>
            </Select>
          </Field>
          <Field label="Métrica">
            <Select value={form.metric} onChange={(e) => setForm({ ...form, metric: e.target.value })}>
              <option value="revenue">Receita (vendas concluídas)</option>
              <option value="new_customers">Novos clientes</option>
              <option value="opportunities_won">Oportunidades ganhas</option>
            </Select>
          </Field>
          <Field label="Valor da meta">
            <Input type="number" step="0.01" value={form.targetValue} onChange={(e) => setForm({ ...form, targetValue: e.target.value })} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Início do período">
              <Input type="date" value={form.periodStart} onChange={(e) => setForm({ ...form, periodStart: e.target.value })} required />
            </Field>
            <Field label="Fim do período">
              <Input type="date" value={form.periodEnd} onChange={(e) => setForm({ ...form, periodEnd: e.target.value })} required />
            </Field>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">
            {createMutation.isPending ? 'Salvando...' : 'Salvar meta'}
          </Button>
        </form>
      </Modal>
    </div>
  );
}
