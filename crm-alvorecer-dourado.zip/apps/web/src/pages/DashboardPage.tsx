import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuthStore } from '../store/auth';
import { StatCard } from '../components/ui/StatCard';
import { Card, CardBody, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Avatar } from '../components/ui/Avatar';
import {
  IconBuilding, IconTarget, IconTrendingUp, IconFlag, IconCheckSquare, IconCart, IconBarChart, IconSparkles,
} from '../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const currencyCompact = new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1, style: 'currency', currency: 'BRL' });

export function DashboardPage() {
  const { user, organization } = useAuthStore();

  const { data: summary } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: async () => (await api.get('/dashboard/summary')).data,
  });
  const { data: funnel } = useQuery({
    queryKey: ['dashboard-funnel'],
    queryFn: async () => (await api.get('/dashboard/funnel')).data,
  });
  const { data: agenda } = useQuery({
    queryKey: ['dashboard-agenda'],
    queryFn: async () => (await api.get('/dashboard/my-agenda')).data,
  });
  const { data: goals } = useQuery({
    queryKey: ['goals'],
    queryFn: async () => (await api.get('/goals')).data,
  });
  const { data: topDeals } = useQuery({
    queryKey: ['dashboard-top-deals'],
    queryFn: async () => (await api.get('/reports/top-deals', { params: { status: 'open', limit: 5 } })).data,
  });
  const { data: funnelRpt } = useQuery({
    queryKey: ['dashboard-funnel-rpt'],
    queryFn: async () => (await api.get('/reports/funnel-conversion')).data,
  });

  const maxCount = Math.max(1, ...(funnel?.stages?.map((s: any) => s.count) ?? [1]));
  const myGoal = (goals ?? []).find((g: any) => g.scopeType === 'user' && g.scopeId === user?.id) ?? (goals ?? [])[0];

  return (
    <div className="space-y-6">
      {/* Hero — visão executiva do comercial, com gradiente de marca (prompt-mestre:
          layout impactante, nada de branco pálido) */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-brand-600 via-indigo-600 to-fuchsia-600 px-6 py-7 text-white shadow-modal">
        <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/10 blur-2xl" />
        <div className="pointer-events-none absolute -bottom-20 left-1/3 h-56 w-56 rounded-full bg-fuchsia-400/20 blur-3xl" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-tight">Olá, {user?.name?.split(' ')[0]} 👋</h1>
            <p className="mt-1 text-sm text-brand-100">{organization?.name} — visão geral do seu comercial</p>
          </div>
          <div className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2.5 backdrop-blur-sm">
            <IconSparkles width={18} height={18} />
            <div className="text-sm">
              <p className="font-semibold">{funnelRpt ? `${funnelRpt.winRate}% de taxa de vitória` : '—'}</p>
              <p className="text-xs text-brand-100">{funnelRpt ? `${funnelRpt.opportunitiesWon} ganhas · ${funnelRpt.opportunitiesLost} perdidas` : ''}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        <StatCard label="Clientes ativos" value={summary?.customersActive ?? '—'} icon={<IconBuilding width={16} height={16} />} tone="brand" />
        <StatCard label="Em prospecção" value={summary?.prospectsOpen ?? '—'} hint="prospects em aberto" icon={<IconTarget width={16} height={16} />} tone="info" />
        <StatCard
          label="Em negociação"
          value={summary?.opportunitiesOpen ?? '—'}
          hint={summary ? currencyCompact.format(summary.opportunitiesOpenValue) + ' em pipeline' : undefined}
          icon={<IconTrendingUp width={16} height={16} />}
          tone="warning"
        />
        <StatCard
          label="Ganho no mês"
          value={summary ? currency.format(summary.opportunitiesWonThisMonthValue) : '—'}
          hint={summary ? `${summary.opportunitiesWonThisMonth} fechamentos` : undefined}
          icon={<IconCart width={16} height={16} />}
          tone="success"
        />
        <StatCard label="Tarefas hoje" value={summary?.tasksToday ?? '—'} icon={<IconCheckSquare width={16} height={16} />} tone="slate" />
        <StatCard
          label="Tarefas atrasadas"
          value={summary?.tasksOverdue ?? '—'}
          hint={summary?.tasksOverdue > 0 ? 'Requer atenção' : undefined}
          icon={<IconCheckSquare width={16} height={16} />}
          tone={summary?.tasksOverdue > 0 ? 'danger' : 'slate'}
        />
        <StatCard label="Conversão prospect→cliente" value={funnelRpt ? `${funnelRpt.conversionRate}%` : '—'} icon={<IconBarChart width={16} height={16} />} tone="violet" />
        <StatCard label="Clientes cadastrados" value={funnelRpt?.customersTotal ?? '—'} icon={<IconBuilding width={16} height={16} />} tone="info" />
      </div>

      <Card>
        <CardHeader
          title="Melhores negócios em aberto"
          subtitle="Oportunidades de maior valor no pipeline — priorize estas"
          action={<Link to="/opportunities" className="text-xs font-medium text-brand-600 hover:underline">Ver funil completo →</Link>}
        />
        <CardBody className="space-y-1">
          {(topDeals ?? []).length === 0 && <p className="text-xs text-slate-400">Nenhuma oportunidade aberta no momento.</p>}
          {(topDeals ?? []).map((d: any, i: number) => (
            <div key={d.id} className="flex items-center gap-3 rounded-lg px-2 py-2.5 transition-colors hover:bg-slate-50">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 text-[11px] font-bold text-white">#{i + 1}</span>
              <Avatar name={d.accountName ?? '—'} size={30} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-700">{d.title}</p>
                <p className="truncate text-xs text-slate-400">{d.accountName ?? 'Sem conta vinculada'}</p>
              </div>
              <Badge tone="brand" className="hidden sm:inline-flex">{d.stageName ?? '—'}</Badge>
              <p className="w-24 shrink-0 text-right text-sm font-semibold text-slate-700">{d.value != null ? currencyCompact.format(d.value) : '—'}</p>
            </div>
          ))}
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title={`Funil comercial — ${funnel?.pipeline?.name ?? ''}`} subtitle="Oportunidades abertas por etapa" />
          <CardBody className="space-y-2.5">
            {(funnel?.stages ?? []).map((s: any) => (
              <div key={s.stage.id} className="flex items-center gap-3">
                <div className="w-32 shrink-0 truncate text-xs text-slate-500">{s.stage.name}</div>
                <div className="h-6 flex-1 rounded bg-slate-100">
                  <div
                    className="h-6 rounded text-right text-xs leading-6 text-white transition-all"
                    style={{
                      width: `${Math.max(6, (s.count / maxCount) * 100)}%`,
                      backgroundColor: s.stage.color ?? '#4f46e5',
                    }}
                  >
                    <span className="pr-2">{s.count > 0 ? s.count : ''}</span>
                  </div>
                </div>
              </div>
            ))}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Minha agenda" subtitle="Próximos 7 dias" />
          <CardBody className="space-y-3">
            {(agenda ?? []).length === 0 && <p className="text-xs text-slate-400">Nenhuma atividade pendente.</p>}
            {(agenda ?? []).slice(0, 6).map((t: any) => (
              <div key={t.id} className="flex items-center justify-between border-b border-slate-50 pb-2.5 last:border-0">
                <div>
                  <p className="text-sm font-medium text-slate-700">{t.title}</p>
                  <p className="text-xs text-slate-400">{t.dueAt ? new Date(t.dueAt).toLocaleDateString('pt-BR') : 'Sem prazo'}</p>
                </div>
                <Badge tone={t.priority === 'high' ? 'danger' : 'neutral'}>{t.priority}</Badge>
              </div>
            ))}
            <Link to="/tasks" className="block pt-1 text-xs font-medium text-brand-600 hover:underline">Ver todas as tarefas →</Link>
          </CardBody>
        </Card>
      </div>

      {myGoal && (
        <Card>
          <CardHeader
            title="Meta do período"
            subtitle={`${new Date(myGoal.periodStart).toLocaleDateString('pt-BR')} — ${new Date(myGoal.periodEnd).toLocaleDateString('pt-BR')}`}
            action={<Link to="/goals" className="flex items-center gap-1.5 text-xs font-medium text-brand-600 hover:underline"><IconFlag width={14} height={14} /> Ver metas</Link>}
          />
          <CardBody>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">
                {myGoal.metric === 'revenue' ? currency.format(Number(myGoal.achievedValue)) : myGoal.achievedValue} realizado
              </span>
              <span className="font-medium text-slate-700">
                meta: {myGoal.metric === 'revenue' ? currency.format(Number(myGoal.targetValue)) : myGoal.targetValue}
              </span>
            </div>
            <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className={`h-full rounded-full ${myGoal.progressPercent >= 100 ? 'bg-emerald-500' : 'bg-brand-600'}`}
                style={{ width: `${Math.min(100, myGoal.progressPercent)}%` }}
              />
            </div>
            <p className="mt-1.5 text-xs text-slate-400">{myGoal.progressPercent}% da meta atingido</p>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
