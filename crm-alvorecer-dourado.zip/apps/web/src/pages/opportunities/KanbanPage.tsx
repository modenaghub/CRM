import { DndContext, DragEndEvent, PointerSensor, useDraggable, useDroppable, useSensor, useSensors } from '@dnd-kit/core';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { FormEvent, useEffect, useState } from 'react';
import { api, friendlyError } from '../../lib/api';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { LoadingState } from '../../components/ui/EmptyState';
import { PageHeader } from '../../components/ui/PageHeader';
import { IconPlus } from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });

function OpportunityCard({ opportunity, stageColor }: { opportunity: any; stageColor: string }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({ id: opportunity.id });
  const style = transform ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` } : undefined;
  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={`group cursor-grab overflow-hidden rounded-lg border border-slate-200 bg-white shadow-card transition-all duration-150 ease-smooth hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-popover active:cursor-grabbing ${isDragging ? 'opacity-50 z-10 rotate-2' : ''}`}
    >
      <div className="h-1" style={{ backgroundColor: stageColor }} />
      <div className="p-3">
        <p className="text-sm font-medium text-slate-700">{opportunity.title}</p>
        <div className="mt-2 flex items-center justify-between">
          <span className="rounded-md bg-slate-50 px-1.5 py-0.5 text-xs font-semibold text-slate-600">
            {opportunity.value ? currency.format(Number(opportunity.value)) : 'Sem valor'}
          </span>
          {opportunity.probability != null && <span className="text-[10px] text-slate-400">{opportunity.probability}%</span>}
        </div>
      </div>
    </div>
  );
}

function KanbanColumn({ column }: { column: { stage: any; opportunities: any[] } }) {
  const { setNodeRef, isOver } = useDroppable({ id: column.stage.id });
  const total = column.opportunities.reduce((acc, o) => acc + Number(o.value ?? 0), 0);
  const color = column.stage.color ?? '#94a3b8';
  return (
    <div
      ref={setNodeRef}
      className={`flex w-72 shrink-0 flex-col overflow-hidden rounded-xl border shadow-card transition-colors ${isOver ? 'border-brand-400 bg-brand-50/40' : 'border-slate-200 bg-white'}`}
    >
      <div className="h-1.5" style={{ backgroundColor: color }} />
      <div className="flex items-center justify-between px-3 pt-3">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ backgroundColor: color }} />
          <span className="text-sm font-semibold text-slate-700">{column.stage.name}</span>
        </div>
        <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-slate-100 px-1.5 text-[11px] font-semibold text-slate-500">{column.opportunities.length}</span>
      </div>
      <p className="px-3 pb-3 pt-1 text-xs font-medium" style={{ color }}>{currency.format(total)}</p>
      <div className="min-h-[80px] flex-1 space-y-2 bg-slate-50/60 p-2.5">
        {column.opportunities.map((o) => (
          <OpportunityCard key={o.id} opportunity={o} stageColor={color} />
        ))}
      </div>
    </div>
  );
}

export function KanbanPage() {
  const queryClient = useQueryClient();
  const [pipelineId, setPipelineId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ title: '', value: '' });

  const { data: pipelines } = useQuery({
    queryKey: ['pipelines'],
    queryFn: async () => (await api.get('/pipelines')).data,
  });

  useEffect(() => {
    if (!pipelineId && pipelines?.length) setPipelineId(pipelines[0].id);
  }, [pipelines, pipelineId]);

  const { data: board, isLoading } = useQuery({
    queryKey: ['kanban', pipelineId],
    queryFn: async () => (await api.get('/opportunities/kanban', { params: { pipelineId } })).data,
    enabled: !!pipelineId,
  });

  const moveMutation = useMutation({
    mutationFn: async ({ id, stageId }: { id: string; stageId: string }) => api.post(`/opportunities/${id}/move-stage`, { stageId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kanban', pipelineId] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-funnel'] });
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => api.post('/opportunities', { title: form.title, pipelineId, value: form.value ? Number(form.value) : undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kanban', pipelineId] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setOpen(false);
      setForm({ title: '', value: '' });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over) return;
    const stageId = String(over.id);
    const opportunityId = String(active.id);
    const currentColumn = board?.columns.find((c: any) => c.opportunities.some((o: any) => o.id === opportunityId));
    if (currentColumn?.stage.id === stageId) return;
    moveMutation.mutate({ id: opportunityId, stageId });
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Oportunidades"
        subtitle="Arraste os cards entre as etapas do funil."
        actions={
          <>
            {pipelines && pipelines.length > 1 && (
              <Select value={pipelineId ?? ''} onChange={(e) => setPipelineId(e.target.value)} className="w-48">
                {pipelines.map((p: any) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </Select>
            )}
            <Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Nova oportunidade</Button>
          </>
        }
      />

      {isLoading && <LoadingState />}

      {board && (
        <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {board.columns.map((col: any) => (
              <KanbanColumn key={col.stage.id} column={col} />
            ))}
          </div>
        </DndContext>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Nova oportunidade">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Título">
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </Field>
          <Field label="Valor estimado (R$)">
            <Input type="number" step="0.01" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
          </Field>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">
            {createMutation.isPending ? 'Salvando...' : 'Salvar oportunidade'}
          </Button>
        </form>
      </Modal>
    </div>
  );
}
