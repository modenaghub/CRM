import { useAuthStore } from '../../store/auth';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';

// Configurações (prompt-mestre, seção 45): personalização por organização.
export function SettingsPage() {
  const { organization, enabledModules } = useAuthStore();

  return (
    <div className="space-y-6">
      <PageHeader title="Configurações" subtitle="Personalização da organização, módulos ativos e preferências." />

      <Card>
        <CardHeader title="Organização" subtitle="Dados básicos da sua empresa nesta plataforma." />
        <CardBody className="grid gap-4 sm:grid-cols-2">
          <div>
            <p className="text-xs font-medium text-slate-400">Nome</p>
            <p className="text-sm text-slate-700">{organization?.name}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-400">Segmento (vertical)</p>
            <p className="text-sm capitalize text-slate-700">{organization?.segmentKey}</p>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Módulos ativos" subtitle="Habilitados automaticamente pelo template do seu segmento (Vertical Engine)." />
        <CardBody className="flex flex-wrap gap-2">
          {enabledModules.map((m) => (
            <Badge key={m} tone="brand">
              {m}
            </Badge>
          ))}
        </CardBody>
      </Card>

      <Card className="border-dashed">
        <CardBody className="text-sm text-slate-500">
          Gestão de usuários, papéis/permissões granulares, campos personalizados por entidade e motivos de perda ficam
          disponíveis aqui na próxima fase — o motor de permissões (RBAC) e o Custom Field Builder já existem no backend.
        </CardBody>
      </Card>
    </div>
  );
}
