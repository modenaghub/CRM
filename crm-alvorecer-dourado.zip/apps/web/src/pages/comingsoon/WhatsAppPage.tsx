import { ComingSoonPage } from '../ComingSoonPage';
import { IconMessage } from '../../components/ui/Icons';

export function WhatsAppPage() {
  return (
    <ComingSoonPage
      icon={<IconMessage width={24} height={24} />}
      title="Central de WhatsApp"
      description="Caixa de entrada omnichannel com múltiplos números, filas e histórico por cliente."
      ready={[
        'Modelo de dados para múltiplas contas de WhatsApp por organização/filial/vendedor',
        'Vínculo automático de conversas ao cadastro de cliente/prospect (mesma FK usada por notas e anexos)',
        'Fila de eventos (Event Bus) pronta para disparar automações a partir de mensagens recebidas',
        'Tela de configuração de números e distribuição de conversas desenhada',
      ]}
      pending={[
        'Credenciais da WhatsApp Business API (ou provedor como Twilio/360dialog)',
        'Webhook público para recebimento de mensagens em tempo real',
        'Aprovação de templates de mensagem junto à Meta',
      ]}
    />
  );
}
