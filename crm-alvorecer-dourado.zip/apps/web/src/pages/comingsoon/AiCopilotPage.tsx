import { ComingSoonPage } from '../ComingSoonPage';
import { IconSparkles } from '../../components/ui/Icons';

export function AiCopilotPage() {
  return (
    <ComingSoonPage
      icon={<IconSparkles width={24} height={24} />}
      title="Copiloto Comercial (IA)"
      description="Assistente que responde perguntas usando os dados reais do seu CRM — nunca dados inventados."
      ready={[
        'Todos os endpoints de dados (clientes, pipeline, vendas, compras, metas) já expõem indicadores reais e agregados',
        'Módulo de metas com meta x realizado calculado em tempo real, pronto para servir de contexto à IA',
        'Auditoria e histórico estruturados para perguntas como "o que mudou nesta oportunidade"',
      ]}
      pending={[
        'Conexão com um provedor de LLM (chave de API)',
        'Camada de function-calling ligando as perguntas às consultas reais do banco',
        'Guardrail para a IA responder "não tenho dados suficientes" quando aplicável (exigido pelo prompt-mestre)',
      ]}
    />
  );
}
