import { ComingSoonPage } from '../ComingSoonPage';
import { IconBarChart } from '../../components/ui/Icons';

export function BiPage() {
  return (
    <ComingSoonPage
      icon={<IconBarChart width={24} height={24} />}
      title="Relatórios & BI"
      description="Dashboards configuráveis, exportação em PDF/Excel e relatórios por vendedor, produto e região."
      ready={[
        'Dashboard executivo com KPIs reais (receita, pipeline, funil, tarefas) já em produção',
        'Módulo de Metas com progresso por escopo (organização/equipe/vendedor)',
        'Auditoria consultável por entidade — base para relatórios de atividade',
      ]}
      pending={[
        'Biblioteca de gráficos avançados e dashboards arrastar-e-soltar',
        'Exportação para PDF/Excel',
        'Relatórios agendados por e-mail',
      ]}
    />
  );
}
