import { ComingSoonPage } from '../ComingSoonPage';
import { IconMail } from '../../components/ui/Icons';

export function EmailPage() {
  return (
    <ComingSoonPage
      icon={<IconMail width={24} height={24} />}
      title="E-mail integrado"
      description="Caixa de entrada, envio e histórico de e-mails vinculados a clientes e oportunidades."
      ready={[
        'Modelo de dados de e-mails vinculados a cliente/prospect/fornecedor/oportunidade',
        'Cliente HTTP com refresh automático já preparado para autenticação OAuth',
        'Estrutura de templates e assinaturas planejada no schema',
      ]}
      pending={[
        'Conexão OAuth com Gmail/Google Workspace ou Microsoft 365',
        'Configuração de IMAP/SMTP para provedores próprios',
        'Sincronização periódica (webhook ou polling) da caixa de entrada',
      ]}
    />
  );
}
