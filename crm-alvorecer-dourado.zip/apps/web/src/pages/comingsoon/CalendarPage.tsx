import { useQuery } from '@tanstack/react-query';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { LoadingState, EmptyState } from '../../components/ui/EmptyState';
import { IconCalendar } from '../../components/ui/Icons';

const typeLabel: Record<string, string> = {
  call: 'Ligação', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reunião', visit: 'Visita',
  followup: 'Follow-up', internal: 'Interna', proposal: 'Proposta',
};

// Calendário (prompt-mestre, seção 15): por ora consolida as atividades reais
// (Tarefas) numa visão de agenda; a integração externa (Google/Outlook) é a
// próxima camada sobre a mesma tabela de atividades.
export function CalendarPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['tasks-agenda'],
    queryFn: async () => (await api.get('/tasks')).data,
  });

  const upcoming = (data ?? []).filter((t: any) => t.status !== 'done').sort((a: any, b: any) => new Date(a.dueAt ?? 0).getTime() - new Date(b.dueAt ?? 0).getTime());

  const grouped = upcoming.reduce((acc: Record<string, any[]>, t: any) => {
    const key = t.dueAt ? new Date(t.dueAt).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' }) : 'Sem data';
    acc[key] = acc[key] ?? [];
    acc[key].push(t);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <PageHeader title="Calendário" subtitle="Agenda consolidada a partir das atividades da equipe." />

      <Card className="border-dashed bg-brand-50/40">
        <CardBody className="flex items-center gap-3 py-3.5 text-sm text-slate-600">
          <IconCalendar className="shrink-0 text-brand-600" />
          Integração com Google Agenda / Microsoft Outlook fica pronta para a próxima fase — hoje esta visão já usa dados reais das
          suas tarefas e reuniões.
        </CardBody>
      </Card>

      {isLoading && <LoadingState />}
      {!isLoading && upcoming.length === 0 && <EmptyState title="Nenhum compromisso pendente" />}

      <div className="space-y-4">
        {Object.entries(grouped).map(([day, items]) => (
          <Card key={day}>
            <CardHeader title={day.charAt(0).toUpperCase() + day.slice(1)} />
            <CardBody className="space-y-2 pt-0">
              {(items as any[]).map((t: any) => (
                <div key={t.id} className="flex items-center justify-between border-b border-slate-50 py-2.5 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-slate-700">{t.title}</p>
                    <p className="text-xs text-slate-400">{typeLabel[t.type] ?? t.type}</p>
                  </div>
                  <Badge tone={t.priority === 'high' ? 'danger' : t.priority === 'low' ? 'neutral' : 'info'}>{t.priority}</Badge>
                </div>
              ))}
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
