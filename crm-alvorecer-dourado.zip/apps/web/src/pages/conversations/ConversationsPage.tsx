import { useEffect, useMemo, useState } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Avatar } from '../../components/ui/Avatar';
import { Badge } from '../../components/ui/Badge';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Tabs } from '../../components/ui/Tabs';
import { StatCard } from '../../components/ui/StatCard';
import { LoadingState } from '../../components/ui/EmptyState';
import { IconWhatsapp, IconSearch, IconInbox, IconCheckSquare, IconClock } from '../../components/ui/Icons';

function relativeTime(iso?: string | null) {
  if (!iso) return '';
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'agora';
  if (mins < 60) return `${mins}min`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d`;
  return new Date(iso).toLocaleDateString('pt-BR');
}

export function ConversationsPage() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState('open');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  const { data: list, isLoading } = useQuery({
    queryKey: ['conversations', statusFilter, search],
    queryFn: async () => (await api.get('/conversations', { params: { status: statusFilter === 'all' ? undefined : statusFilter, search: search || undefined } })).data,
    refetchInterval: 15000,
  });

  const { data: summary } = useQuery({
    queryKey: ['conversations-summary'],
    queryFn: async () => (await api.get('/conversations/summary')).data,
    refetchInterval: 15000,
  });

  const { data: activeConv } = useQuery({
    queryKey: ['conversation', selectedId],
    queryFn: async () => (await api.get(`/conversations/${selectedId}`)).data,
    enabled: !!selectedId,
    refetchInterval: 10000,
  });

  useEffect(() => {
    if (!selectedId && list?.length) setSelectedId(list[0].id);
  }, [list, selectedId]);

  const markRead = useMutation({
    mutationFn: async (id: string) => api.post(`/conversations/${id}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      queryClient.invalidateQueries({ queryKey: ['conversations-summary'] });
      queryClient.invalidateQueries({ queryKey: ['conversation', selectedId] });
    },
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, action }: { id: string; action: 'close' | 'reopen' }) => api.patch(`/conversations/${id}/${action}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      queryClient.invalidateQueries({ queryKey: ['conversations-summary'] });
      queryClient.invalidateQueries({ queryKey: ['conversation', selectedId] });
    },
  });

  const sendMessage = useMutation({
    mutationFn: async ({ id, body }: { id: string; body: string }) => api.post(`/conversations/${id}/messages`, { body, direction: 'outbound' }),
    onSuccess: () => {
      setDraft('');
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
      queryClient.invalidateQueries({ queryKey: ['conversations-summary'] });
      queryClient.invalidateQueries({ queryKey: ['conversation', selectedId] });
    },
  });

  function selectConversation(id: string) {
    setSelectedId(id);
    const conv = (list ?? []).find((c: any) => c.id === id);
    if (conv?.unreadCount > 0) markRead.mutate(id);
  }

  function handleSend() {
    if (!selectedId || !draft.trim()) return;
    sendMessage.mutate({ id: selectedId, body: draft.trim() });
  }

  const conversations = list ?? [];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Conversas"
        subtitle="Central de mensagens — WhatsApp e outros canais, com histórico e relatórios de atendimento."
        actions={<span className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm"><IconWhatsapp width={14} height={14} /> Central de WhatsApp</span>}
      />

      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Conversas abertas" value={summary?.open ?? '—'} icon={<IconInbox width={16} height={16} />} tone="brand" />
        <StatCard label="Não lidas" value={summary?.unread ?? '—'} icon={<IconWhatsapp width={16} height={16} />} tone={summary?.unread > 0 ? 'danger' : 'slate'} />
        <StatCard label="Encerradas" value={summary?.closed ?? '—'} icon={<IconCheckSquare width={16} height={16} />} tone="success" />
      </div>

      <div className="grid grid-cols-1 gap-4 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-card lg:grid-cols-[340px_1fr]" style={{ minHeight: 560 }}>
        {/* Lista de conversas */}
        <div className="flex flex-col border-r border-slate-100">
          <div className="space-y-2 border-b border-slate-100 p-3">
            <div className="relative">
              <IconSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" width={14} height={14} />
              <Input placeholder="Buscar contato..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 text-sm" />
            </div>
            <Tabs
              tabs={[
                { key: 'open', label: 'Abertas' },
                { key: 'closed', label: 'Encerradas' },
                { key: 'all', label: 'Todas' },
              ]}
              active={statusFilter}
              onChange={setStatusFilter}
            />
          </div>
          <div className="flex-1 overflow-y-auto">
            {isLoading && <LoadingState />}
            {!isLoading && conversations.length === 0 && (
              <p className="p-6 text-center text-xs text-slate-400">Nenhuma conversa encontrada.</p>
            )}
            {conversations.map((c: any) => (
              <button
                key={c.id}
                onClick={() => selectConversation(c.id)}
                className={`flex w-full items-start gap-2.5 border-b border-slate-50 px-3 py-3 text-left transition-colors hover:bg-slate-50 ${selectedId === c.id ? 'bg-brand-50/60' : ''}`}
              >
                <Avatar name={c.contactName ?? 'Contato'} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-medium text-slate-700">{c.contactName ?? 'Sem nome'}</p>
                    <span className="shrink-0 text-[10px] text-slate-400">{relativeTime(c.lastMessageAt)}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-xs text-slate-400">{c.lastMessagePreview ?? 'Sem mensagens ainda'}</p>
                    {c.unreadCount > 0 && (
                      <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500 px-1 text-[10px] font-semibold text-white">{c.unreadCount}</span>
                    )}
                  </div>
                  {c.status === 'closed' && <Badge tone="neutral" className="mt-1">Encerrada</Badge>}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Painel da conversa */}
        <div className="flex flex-col">
          {!activeConv && <div className="flex flex-1 items-center justify-center text-sm text-slate-400">Selecione uma conversa</div>}
          {activeConv && (
            <>
              <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
                <div className="flex items-center gap-2.5">
                  <Avatar name={activeConv.contactName ?? 'Contato'} size={36} />
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{activeConv.contactName ?? 'Sem nome'}</p>
                    <p className="text-xs text-slate-400">{activeConv.contactPhone ?? '—'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={activeConv.status === 'open' ? 'success' : 'neutral'} dot>{activeConv.status === 'open' ? 'Aberta' : 'Encerrada'}</Badge>
                  {activeConv.status === 'open' ? (
                    <Button variant="ghost" className="text-xs" onClick={() => setStatus.mutate({ id: activeConv.id, action: 'close' })}>Encerrar</Button>
                  ) : (
                    <Button variant="ghost" className="text-xs" onClick={() => setStatus.mutate({ id: activeConv.id, action: 'reopen' })}>Reabrir</Button>
                  )}
                </div>
              </div>

              <div className="flex-1 space-y-3 overflow-y-auto bg-slate-50/60 p-4">
                {(activeConv.messages ?? []).length === 0 && <p className="text-center text-xs text-slate-400">Nenhuma mensagem ainda.</p>}
                {(activeConv.messages ?? []).map((m: any) => (
                  <div key={m.id} className={`flex ${m.direction === 'outbound' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] rounded-2xl px-3.5 py-2 text-sm shadow-sm ${m.direction === 'outbound' ? 'rounded-br-sm bg-gradient-to-br from-brand-500 to-indigo-600 text-white' : 'rounded-bl-sm bg-white text-slate-700'}`}>
                      <p className="whitespace-pre-wrap">{m.body}</p>
                      <p className={`mt-1 flex items-center gap-1 text-[10px] ${m.direction === 'outbound' ? 'text-brand-100' : 'text-slate-400'}`}>
                        <IconClock width={10} height={10} /> {new Date(m.sentAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 border-t border-slate-100 p-3">
                <Input
                  placeholder="Digite uma mensagem..."
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') handleSend(); }}
                  className="flex-1"
                />
                <Button onClick={handleSend} disabled={!draft.trim() || sendMessage.isPending}>Enviar</Button>
              </div>
            </>
          )}
        </div>
      </div>

      <p className="text-center text-xs text-slate-400">
        Envio real via WhatsApp Business API pendente de configuração de credenciais em Preferências — o histórico, os relatórios e a organização das conversas já são 100% reais.
      </p>
    </div>
  );
}
