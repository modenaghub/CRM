import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api, friendlyError } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Tabs } from '../../components/ui/Tabs';
import { Badge } from '../../components/ui/Badge';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, LoadingState } from '../../components/ui/EmptyState';
import { IconPlus } from '../../components/ui/Icons';

const dateBR = (v?: string) => (v ? new Date(v).toLocaleDateString('pt-BR') : '—');
const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

const requestStatusTone: Record<string, any> = { open: 'info', quoting: 'warning', ordered: 'brand', cancelled: 'danger' };
const requestStatusLabel: Record<string, string> = { open: 'Aberta', quoting: 'Em cotação', ordered: 'Pedido gerado', cancelled: 'Cancelada' };
const poStatusTone: Record<string, any> = { pending: 'neutral', sent: 'info', confirmed: 'brand', received: 'success', cancelled: 'danger' };
const poStatusLabel: Record<string, string> = { pending: 'Pendente', sent: 'Enviado', confirmed: 'Confirmado', received: 'Recebido', cancelled: 'Cancelado' };

type ReqItemRow = { productId: string; quantity: string };

export function PurchasesPage() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState('requests');
  const [newRequestOpen, setNewRequestOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [reqItems, setReqItems] = useState<ReqItemRow[]>([{ productId: '', quantity: '10' }]);

  const [generateFor, setGenerateFor] = useState<any | null>(null);
  const [supplierId, setSupplierId] = useState('');
  const [unitCosts, setUnitCosts] = useState<Record<string, string>>({});

  const { data: suppliers } = useQuery({ queryKey: ['suppliers-all'], queryFn: async () => (await api.get('/suppliers', { params: { pageSize: 100 } })).data });
  const { data: products } = useQuery({ queryKey: ['products-all'], queryFn: async () => (await api.get('/products', { params: { pageSize: 100 } })).data });
  const { data: requests, isLoading: loadingRequests } = useQuery({ queryKey: ['purchase-requests'], queryFn: async () => (await api.get('/purchase-requests')).data });
  const { data: orders, isLoading: loadingOrders } = useQuery({ queryKey: ['purchase-orders'], queryFn: async () => (await api.get('/purchase-orders')).data });

  const supplierMap = useMemo(() => Object.fromEntries((suppliers?.data ?? []).map((s: any) => [s.id, s.companyName])), [suppliers]);
  const productMap = useMemo(() => Object.fromEntries((products?.data ?? []).map((p: any) => [p.id, p])), [products]);

  const createRequest = useMutation({
    mutationFn: async () =>
      api.post('/purchase-requests', {
        title,
        items: reqItems.filter((i) => i.productId).map((i) => ({ productId: i.productId, quantity: Number(i.quantity) })),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase-requests'] });
      setNewRequestOpen(false);
      setTitle('');
      setReqItems([{ productId: '', quantity: '10' }]);
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const createOrder = useMutation({
    mutationFn: async () =>
      api.post('/purchase-orders', {
        supplierId,
        purchaseRequestId: generateFor.id,
        items: generateFor.items.map((i: any) => ({ productId: i.productId, quantity: Number(i.quantity), unitCost: Number(unitCosts[i.id] ?? productMap[i.productId]?.cost ?? 0) })),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase-orders'] });
      queryClient.invalidateQueries({ queryKey: ['purchase-requests'] });
      setGenerateFor(null);
      setSupplierId('');
      setUnitCosts({});
      setTab('orders');
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const receiveOrder = useMutation({
    mutationFn: async (id: string) => api.post(`/purchase-orders/${id}/receive`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['purchase-orders'] });
      queryClient.invalidateQueries({ queryKey: ['products-all'] });
    },
  });

  function updateReqItem(idx: number, patch: Partial<ReqItemRow>) {
    setReqItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  }

  async function openGenerate(request: any) {
    const { data } = await api.get(`/purchase-requests/${request.id}`);
    setGenerateFor(data);
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Compras"
        subtitle="Fluxo: necessidade → cotação com fornecedor → pedido de compra → recebimento."
        actions={<Button onClick={() => setNewRequestOpen(true)}><IconPlus width={16} height={16} /> Nova solicitação</Button>}
      />

      <Card>
        <Tabs
          tabs={[
            { key: 'requests', label: 'Solicitações', count: requests?.length },
            { key: 'orders', label: 'Pedidos de compra', count: orders?.length },
          ]}
          active={tab}
          onChange={setTab}
        />
        <CardBody>
          {tab === 'requests' && (
            <>
              {loadingRequests && <LoadingState />}
              {!loadingRequests && (requests ?? []).length === 0 && <EmptyState title="Nenhuma solicitação de compra" />}
              {!loadingRequests && (requests ?? []).length > 0 && (
                <table className="w-full text-sm">
                  <thead className="text-left text-xs font-medium uppercase text-slate-500">
                    <tr>
                      <th className="py-2">Número</th>
                      <th className="py-2">Solicitação</th>
                      <th className="py-2">Status</th>
                      <th className="py-2">Data</th>
                      <th className="py-2"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {requests.map((r: any) => (
                      <tr key={r.id}>
                        <td className="py-2.5 font-medium text-slate-700">#{r.number}</td>
                        <td className="py-2.5 text-slate-600">{r.title}</td>
                        <td className="py-2.5"><Badge tone={requestStatusTone[r.status]}>{requestStatusLabel[r.status] ?? r.status}</Badge></td>
                        <td className="py-2.5 text-slate-500">{dateBR(r.createdAt)}</td>
                        <td className="py-2.5 text-right">
                          {r.status === 'open' && (
                            <Button size="sm" variant="secondary" onClick={() => openGenerate(r)}>
                              Selecionar fornecedor
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          )}

          {tab === 'orders' && (
            <>
              {loadingOrders && <LoadingState />}
              {!loadingOrders && (orders ?? []).length === 0 && <EmptyState title="Nenhum pedido de compra" />}
              {!loadingOrders && (orders ?? []).length > 0 && (
                <table className="w-full text-sm">
                  <thead className="text-left text-xs font-medium uppercase text-slate-500">
                    <tr>
                      <th className="py-2">Número</th>
                      <th className="py-2">Fornecedor</th>
                      <th className="py-2">Valor</th>
                      <th className="py-2">Status</th>
                      <th className="py-2">Data</th>
                      <th className="py-2"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {orders.map((o: any) => (
                      <tr key={o.id}>
                        <td className="py-2.5 font-medium text-slate-700">#{o.number}</td>
                        <td className="py-2.5 text-slate-600">{supplierMap[o.supplierId] ?? '—'}</td>
                        <td className="py-2.5 text-slate-600">{currency.format(Number(o.totalValue))}</td>
                        <td className="py-2.5"><Badge tone={poStatusTone[o.status]}>{poStatusLabel[o.status] ?? o.status}</Badge></td>
                        <td className="py-2.5 text-slate-500">{dateBR(o.createdAt)}</td>
                        <td className="py-2.5 text-right">
                          {o.status !== 'received' && o.status !== 'cancelled' && (
                            <Button size="sm" variant="secondary" onClick={() => receiveOrder.mutate(o.id)} disabled={receiveOrder.isPending}>
                              Registrar recebimento
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          )}
        </CardBody>
      </Card>

      <Modal open={newRequestOpen} onClose={() => setNewRequestOpen(false)} title="Nova solicitação de compra" wide>
        <div className="space-y-4">
          <Field label="Título da solicitação">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Reposição de estoque Q4" required />
          </Field>
          <div>
            <p className="mb-2 text-xs font-medium text-slate-600">Itens necessários</p>
            <div className="space-y-2">
              {reqItems.map((item, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Select value={item.productId} onChange={(e) => updateReqItem(idx, { productId: e.target.value })} className="flex-1">
                    <option value="">Selecione um produto...</option>
                    {(products?.data ?? []).map((p: any) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </Select>
                  <Input type="number" min="1" value={item.quantity} onChange={(e) => updateReqItem(idx, { quantity: e.target.value })} className="w-24" placeholder="Qtd" />
                  <button type="button" onClick={() => setReqItems((prev) => prev.filter((_, i) => i !== idx))} className="text-slate-400 hover:text-red-500" disabled={reqItems.length === 1}>✕</button>
                </div>
              ))}
            </div>
            <button type="button" onClick={() => setReqItems((prev) => [...prev, { productId: '', quantity: '10' }])} className="mt-2 text-xs font-medium text-brand-600 hover:underline">
              + Adicionar item
            </button>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button onClick={() => { setError(null); createRequest.mutate(); }} disabled={createRequest.isPending || !title || !reqItems.some((i) => i.productId)} className="w-full">
            {createRequest.isPending ? 'Salvando...' : 'Salvar solicitação'}
          </Button>
        </div>
      </Modal>

      <Modal open={!!generateFor} onClose={() => setGenerateFor(null)} title={`Gerar pedido de compra — Solicitação #${generateFor?.number ?? ''}`} wide>
        {generateFor && (
          <div className="space-y-4">
            <Field label="Fornecedor selecionado (comparação de fornecedores)">
              <Select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} required>
                <option value="">Selecione...</option>
                {(suppliers?.data ?? []).map((s: any) => (
                  <option key={s.id} value={s.id}>{s.companyName} {s.rating ? `— ${s.rating}★` : ''}</option>
                ))}
              </Select>
            </Field>
            <div>
              <p className="mb-2 text-xs font-medium text-slate-600">Itens e custo unitário cotado</p>
              <div className="space-y-2">
                {generateFor.items.map((item: any) => (
                  <div key={item.id} className="flex items-center gap-2 text-sm">
                    <span className="flex-1 text-slate-600">{productMap[item.productId]?.name ?? 'Produto'} · {item.quantity} un.</span>
                    <Input
                      type="number"
                      step="0.01"
                      value={unitCosts[item.id] ?? productMap[item.productId]?.cost ?? ''}
                      onChange={(e) => setUnitCosts((prev) => ({ ...prev, [item.id]: e.target.value }))}
                      className="w-28"
                      placeholder="Custo un."
                    />
                  </div>
                ))}
              </div>
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <Button onClick={() => { setError(null); createOrder.mutate(); }} disabled={createOrder.isPending || !supplierId} className="w-full">
              {createOrder.isPending ? 'Gerando...' : 'Gerar pedido de compra'}
            </Button>
          </div>
        )}
      </Modal>
    </div>
  );
}
