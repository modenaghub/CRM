import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, PieChart, Pie, Cell, Legend,
} from 'recharts';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardBody } from '../../components/ui/Card';
import { StatCard } from '../../components/ui/StatCard';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { Avatar } from '../../components/ui/Avatar';
import {
  IconBarChart, IconTrendingUp, IconBuilding, IconCart, IconTarget, IconCheckSquare, IconTruck, IconFlag,
} from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const currencyCompact = new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1, style: 'currency', currency: 'BRL' });
const monthLabel = (key: string) => {
  const [y, m] = key.split('-');
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');
};

const CHART_COLORS = ['#4f46e5', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#a855f7', '#ec4899', '#14b8a6'];
const ACTIVITY_LABELS: Record<string, string> = {
  call: 'Ligações', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reuniões', visit: 'Visitas', followup: 'Follow-up',
};

function Tooltip2({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-popover">
      <p className="text-xs font-semibold text-slate-700">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-xs text-slate-500">
          {p.name}: <span className="font-medium text-slate-700">{typeof p.value === 'number' && p.value > 1000 ? currency.format(p.value) : p.value}</span>
        </p>
      ))}
    </div>
  );
}

export function ReportsPage() {
  const [section, setSection] = useState('vendas');

  const { data: revenue } = useQuery({ queryKey: ['rpt-revenue'], queryFn: async () => (await api.get('/reports/revenue-by-month', { params: { months: 6 } })).data });
  const { data: topCustomers } = useQuery({ queryKey: ['rpt-top-customers'], queryFn: async () => (await api.get('/reports/top-customers')).data });
  const { data: sellers } = useQuery({ queryKey: ['rpt-sellers'], queryFn: async () => (await api.get('/reports/seller-performance')).data });
  const { data: topProducts } = useQuery({ queryKey: ['rpt-top-products'], queryFn: async () => (await api.get('/reports/top-products')).data });
  const { data: funnel } = useQuery({ queryKey: ['rpt-funnel'], queryFn: async () => (await api.get('/reports/funnel-conversion')).data });
  const { data: activity } = useQuery({ queryKey: ['rpt-activity'], queryFn: async () => (await api.get('/reports/activity-summary')).data });
  const { data: purchases } = useQuery({ queryKey: ['rpt-purchases'], queryFn: async () => (await api.get('/reports/purchases-summary')).data });

  const revenueChartData = (revenue ?? []).map((r: any) => ({ ...r, label: monthLabel(r.month) }));
  const totalRevenue6m = (revenue ?? []).reduce((acc: number, r: any) => acc + r.total, 0);
  const totalOrders6m = (revenue ?? []).reduce((acc: number, r: any) => acc + r.count, 0);

  const activityRows = Object.entries(activity ?? {}).map(([type, v]: [string, any]) => ({
    type: ACTIVITY_LABELS[type] ?? type, ...v, total: v.done + v.pending + v.overdue,
  }));

  return (
    <div className="space-y-5">
      <PageHeader
        title="Relatórios & BI"
        subtitle="Indicadores gerenciais calculados em tempo real a partir dos dados do CRM — sem números fictícios."
        actions={<span className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-brand-500 to-fuchsia-500 px-3 py-1.5 text-xs font-semibold text-white shadow-sm"><IconBarChart width={14} height={14} /> Central analítica</span>}
      />

      <Tabs
        tabs={[
          { key: 'vendas', label: 'Vendas & Faturamento' },
          { key: 'comercial', label: 'Funil Comercial' },
          { key: 'atividades', label: 'Atividades & Time' },
          { key: 'compras', label: 'Compras & Fornecedores' },
        ]}
        active={section}
        onChange={setSection}
      />

      {section === 'vendas' && (
        <div className="animate-page-in space-y-5">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard label="Faturamento (6 meses)" value={currencyCompact.format(totalRevenue6m)} hint={`${totalOrders6m} pedidos concluídos`} icon={<IconTrendingUp width={16} height={16} />} tone="brand" />
            <StatCard label="Ticket médio" value={totalOrders6m > 0 ? currency.format(totalRevenue6m / totalOrders6m) : '—'} icon={<IconCart width={16} height={16} />} tone="success" />
            <StatCard label="Melhor vendedor" value={sellers?.[0]?.name ?? '—'} hint={sellers?.[0] ? currencyCompact.format(sellers[0].revenue) : undefined} icon={<IconFlag width={16} height={16} />} tone="violet" />
            <StatCard label="Cliente #1" value={topCustomers?.[0]?.companyName ?? '—'} hint={topCustomers?.[0] ? currencyCompact.format(topCustomers[0].total) : undefined} icon={<IconBuilding width={16} height={16} />} tone="info" />
          </div>

          <Card>
            <CardHeader title="Evolução do faturamento" subtitle="Últimos 6 meses — pedidos de venda concluídos" />
            <CardBody>
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={revenueChartData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => currencyCompact.format(v)} width={64} />
                  <Tooltip content={<Tooltip2 />} />
                  <Area type="monotone" dataKey="total" name="Faturamento" stroke="#4f46e5" strokeWidth={2.5} fill="url(#revGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardBody>
          </Card>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            <Card>
              <CardHeader title="Top clientes" subtitle="Por faturamento total (pedidos concluídos)" />
              <CardBody className="space-y-1">
                {(topCustomers ?? []).length === 0 && <p className="text-xs text-slate-400">Nenhuma venda concluída ainda.</p>}
                {(topCustomers ?? []).map((c: any, i: number) => (
                  <div key={c.id} className="flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-slate-50">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-[11px] font-semibold text-slate-500">{i + 1}</span>
                    <Avatar name={c.companyName} size={28} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-700">{c.companyName}</p>
                      <p className="text-xs text-slate-400">{c.orders} pedido{c.orders !== 1 ? 's' : ''}</p>
                    </div>
                    <p className="text-sm font-semibold text-slate-700">{currencyCompact.format(c.total)}</p>
                  </div>
                ))}
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Top produtos" subtitle="Por receita gerada (itens vendidos)" />
              <CardBody className="space-y-1">
                {(topProducts ?? []).length === 0 && <p className="text-xs text-slate-400">Nenhuma venda concluída ainda.</p>}
                {(topProducts ?? []).map((p: any, i: number) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-slate-50">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-white text-[11px] font-semibold" style={{ backgroundColor: CHART_COLORS[i % CHART_COLORS.length] }}>{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-700">{p.name}</p>
                      <p className="text-xs text-slate-400">{p.quantity} unid. vendidas</p>
                    </div>
                    <p className="text-sm font-semibold text-slate-700">{currencyCompact.format(p.revenue)}</p>
                  </div>
                ))}
              </CardBody>
            </Card>
          </div>

          <Card>
            <CardHeader title="Desempenho por vendedor" subtitle="Receita, pedidos e oportunidades ganhas" />
            <CardBody>
              <ResponsiveContainer width="100%" height={Math.max(180, (sellers?.length ?? 0) * 44)}>
                <BarChart data={sellers ?? []} layout="vertical" margin={{ left: 8, right: 24 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => currencyCompact.format(v)} />
                  <YAxis type="category" dataKey="name" width={110} tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                  <Tooltip content={<Tooltip2 />} />
                  <Bar dataKey="revenue" name="Receita" radius={[0, 6, 6, 0]} fill="#4f46e5" />
                </BarChart>
              </ResponsiveContainer>
            </CardBody>
          </Card>
        </div>
      )}

      {section === 'comercial' && (
        <div className="animate-page-in space-y-5">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard label="Prospects" value={funnel?.prospectsTotal ?? '—'} hint={`${funnel?.conversionRate ?? 0}% convertidos`} icon={<IconTarget width={16} height={16} />} tone="info" />
            <StatCard label="Clientes" value={funnel?.customersTotal ?? '—'} icon={<IconBuilding width={16} height={16} />} tone="brand" />
            <StatCard label="Oportunidades abertas" value={funnel?.opportunitiesOpen ?? '—'} icon={<IconTrendingUp width={16} height={16} />} tone="warning" />
            <StatCard label="Taxa de vitória" value={`${funnel?.winRate ?? 0}%`} hint={`${funnel?.opportunitiesWon ?? 0} ganhas · ${funnel?.opportunitiesLost ?? 0} perdidas`} icon={<IconFlag width={16} height={16} />} tone="success" />
          </div>

          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader title="Funil de conversão" subtitle="Da prospecção ao fechamento" />
              <CardBody>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart
                    data={[
                      { stage: 'Prospects', value: funnel?.prospectsTotal ?? 0 },
                      { stage: 'Convertidos', value: funnel?.prospectsConverted ?? 0 },
                      { stage: 'Oport. abertas', value: funnel?.opportunitiesOpen ?? 0 },
                      { stage: 'Ganhas', value: funnel?.opportunitiesWon ?? 0 },
                    ]}
                    margin={{ top: 8, right: 12, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                    <XAxis dataKey="stage" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                    <Tooltip content={<Tooltip2 />} />
                    <Bar dataKey="value" name="Quantidade" radius={[6, 6, 0, 0]}>
                      {['#94a3b8', '#38bdf8', '#f59e0b', '#22c55e'].map((c, i) => <Cell key={i} fill={c} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardBody>
            </Card>

            <Card>
              <CardHeader title="Ganhas vs. perdidas" />
              <CardBody className="flex flex-col items-center">
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Ganhas', value: funnel?.opportunitiesWon ?? 0 },
                        { name: 'Perdidas', value: funnel?.opportunitiesLost ?? 0 },
                      ]}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={55}
                      outerRadius={80}
                      paddingAngle={3}
                    >
                      <Cell fill="#22c55e" />
                      <Cell fill="#ef4444" />
                    </Pie>
                    <Tooltip content={<Tooltip2 />} />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
                <p className="text-center text-xs text-slate-400">Valor total ganho: <span className="font-semibold text-slate-600">{currencyCompact.format(funnel?.opportunitiesWonValue ?? 0)}</span></p>
              </CardBody>
            </Card>
          </div>
        </div>
      )}

      {section === 'atividades' && (
        <div className="animate-page-in space-y-5">
          <Card>
            <CardHeader title="Atividades por tipo" subtitle="Concluídas, pendentes e atrasadas — ligações, WhatsApp, e-mail, reuniões e visitas" />
            <CardBody>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={activityRows} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="type" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} allowDecimals={false} />
                  <Tooltip content={<Tooltip2 />} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="done" name="Concluídas" stackId="a" fill="#22c55e" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="pending" name="Pendentes" stackId="a" fill="#38bdf8" />
                  <Bar dataKey="overdue" name="Atrasadas" stackId="a" fill="#ef4444" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardBody>
          </Card>

          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {activityRows.map((r, i) => (
              <StatCard key={r.type} label={r.type} value={r.total} hint={`${r.done} concluídas`} icon={<IconCheckSquare width={16} height={16} />} tone={(['brand', 'success', 'info', 'violet', 'warning', 'danger'] as const)[i % 6]} />
            ))}
          </div>
        </div>
      )}

      {section === 'compras' && (
        <div className="animate-page-in space-y-5">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard label="Total investido em compras" value={currencyCompact.format(purchases?.totalSpent ?? 0)} icon={<IconCart width={16} height={16} />} tone="brand" />
            <StatCard label="Pedidos recebidos" value={purchases?.ordersReceived ?? 0} icon={<IconTruck width={16} height={16} />} tone="info" />
            <StatCard label="Fornecedor principal" value={purchases?.topSuppliers?.[0]?.companyName ?? '—'} hint={purchases?.topSuppliers?.[0] ? currencyCompact.format(purchases.topSuppliers[0].total) : undefined} icon={<IconTruck width={16} height={16} />} tone="violet" />
            <StatCard label="Ticket médio de compra" value={purchases?.ordersReceived > 0 ? currency.format(purchases.totalSpent / purchases.ordersReceived) : '—'} icon={<IconCart width={16} height={16} />} tone="success" />
          </div>

          <Card>
            <CardHeader title="Top fornecedores" subtitle="Por volume de compras recebidas" />
            <CardBody>
              <ResponsiveContainer width="100%" height={Math.max(180, (purchases?.topSuppliers?.length ?? 0) * 44)}>
                <BarChart data={purchases?.topSuppliers ?? []} layout="vertical" margin={{ left: 8, right: 24 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => currencyCompact.format(v)} />
                  <YAxis type="category" dataKey="companyName" width={160} tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                  <Tooltip content={<Tooltip2 />} />
                  <Bar dataKey="total" name="Total comprado" radius={[0, 6, 6, 0]} fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </CardBody>
          </Card>
        </div>
      )}
    </div>
  );
}
