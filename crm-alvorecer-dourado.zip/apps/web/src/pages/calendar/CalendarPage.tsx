import { useMemo, useState, FormEvent } from 'react';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { api, friendlyError } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select, Textarea } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';
import { StatCard } from '../../components/ui/StatCard';
import { IconCalendar, IconChevronLeft, IconChevronRight, IconPlus, IconCheckSquare, IconClock } from '../../components/ui/Icons';

const TYPE_LABEL: Record<string, string> = {
  call: 'Ligação', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reunião', visit: 'Visita',
  followup: 'Follow-up', internal: 'Interna', proposal: 'Proposta', return: 'Retorno',
};

const TYPE_COLOR: Record<string, string> = {
  call: 'bg-sky-100 text-sky-700 border-sky-200',
  whatsapp: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  email: 'bg-indigo-100 text-indigo-700 border-indigo-200',
  meeting: 'bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200',
  visit: 'bg-amber-100 text-amber-700 border-amber-200',
  followup: 'bg-slate-100 text-slate-700 border-slate-200',
  internal: 'bg-slate-100 text-slate-700 border-slate-200',
  proposal: 'bg-purple-100 text-purple-700 border-purple-200',
  return: 'bg-rose-100 text-rose-700 border-rose-200',
};

const WEEKDAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

function ymd(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function buildMonthGrid(year: number, month: number) {
  const first = new Date(year, month, 1);
  const startOffset = first.getDay();
  const gridStart = new Date(year, month, 1 - startOffset);
  const days: Date[] = [];
  for (let i = 0; i < 42; i++) days.push(new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i));
  return days;
}

export function CalendarPage() {
  const queryClient = useQueryClient();
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDay, setSelectedDay] = useState<string>(ymd(today));
  const [createOpen, setCreateOpen] = useState(false);
  const [detailTask, setDetailTask] = useState<any | null>(null);
  const [reportText, setReportText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ type: 'meeting', title: '', dueDate: ymd(today), dueTime: '09:00', priority: 'normal', description: '' });

  const { data: tasks } = useQuery({ queryKey: ['tasks-all'], queryFn: async () => (await api.get('/tasks')).data });

  const monthDays = useMemo(() => buildMonthGrid(cursor.getFullYear(), cursor.getMonth()), [cursor]);

  const byDay = useMemo(() => {
    const map = new Map<string, any[]>();
    for (const t of tasks ?? []) {
      if (!t.dueAt) continue;
      const key = ymd(new Date(t.dueAt));
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(t);
    }
    for (const arr of map.values()) arr.sort((a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime());
    return map;
  }, [tasks]);

  const monthStats = useMemo(() => {
    const inMonth = (tasks ?? []).filter((t: any) => t.dueAt && new Date(t.dueAt).getMonth() === cursor.getMonth() && new Date(t.dueAt).getFullYear() === cursor.getFullYear());
    return {
      total: inMonth.length,
      meetings: inMonth.filter((t: any) => t.type === 'meeting' || t.type === 'visit').length,
      done: inMonth.filter((t: any) => t.status === 'done').length,
      overdue: inMonth.filter((t: any) => t.status !== 'done' && new Date(t.dueAt) < today).length,
    };
  }, [tasks, cursor]);

  const createMutation = useMutation({
    mutationFn: async () => api.post('/tasks', {
      type: form.type,
      title: form.title,
      description: form.description || undefined,
      priority: form.priority,
      dueAt: new Date(`${form.dueDate}T${form.dueTime}:00`).toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setCreateOpen(false);
      setForm({ type: 'meeting', title: '', dueDate: selectedDay, dueTime: '09:00', priority: 'normal', description: '' });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  // Concluir com relatório: fecha a atividade e grava o resultado (reunião/ligação)
  // direto na descrição — vira histórico consultável no Cliente/Fornecedor 360º.
  const completeWithReport = useMutation({
    mutationFn: async () => api.patch(`/tasks/${detailTask.id}`, {
      status: 'done',
      description: reportText ? `${detailTask.description ? detailTask.description + '\n\n' : ''}Relatório: ${reportText}` : detailTask.description,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setDetailTask(null);
      setReportText('');
    },
  });

  function handleCreate(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  function openCreateForDay(day: string) {
    setForm((f) => ({ ...f, dueDate: day }));
    setCreateOpen(true);
  }

  const selectedItems = byDay.get(selectedDay) ?? [];
  const monthLabel = cursor.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });

  return (
    <div className="space-y-5">
      <PageHeader
        title="Calendário"
        subtitle="Agenda de visitas, reuniões e ligações — com relatório de resultado direto na atividade."
        actions={<Button onClick={() => openCreateForDay(selectedDay)}><IconPlus width={16} height={16} /> Novo agendamento</Button>}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Compromissos no mês" value={monthStats.total} icon={<IconCalendar width={16} height={16} />} tone="brand" />
        <StatCard label="Reuniões & visitas" value={monthStats.meetings} icon={<IconCheckSquare width={16} height={16} />} tone="violet" />
        <StatCard label="Concluídos" value={monthStats.done} icon={<IconCheckSquare width={16} height={16} />} tone="success" />
        <StatCard label="Atrasados" value={monthStats.overdue} icon={<IconClock width={16} height={16} />} tone={monthStats.overdue > 0 ? 'danger' : 'slate'} />
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[1fr_320px]">
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-card">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
            <h2 className="text-sm font-semibold capitalize text-slate-800">{monthLabel}</h2>
            <div className="flex items-center gap-1">
              <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"><IconChevronLeft width={16} height={16} /></button>
              <button onClick={() => { setCursor(new Date(today.getFullYear(), today.getMonth(), 1)); setSelectedDay(ymd(today)); }} className="rounded-lg px-2.5 py-1 text-xs font-medium text-slate-500 hover:bg-slate-100">Hoje</button>
              <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"><IconChevronRight width={16} height={16} /></button>
            </div>
          </div>

          <div className="grid grid-cols-7 border-b border-slate-100 bg-slate-50/60 text-center text-[11px] font-medium uppercase tracking-wide text-slate-400">
            {WEEKDAYS.map((w) => <div key={w} className="py-2">{w}</div>)}
          </div>

          <div className="grid grid-cols-7">
            {monthDays.map((day) => {
              const key = ymd(day);
              const items = byDay.get(key) ?? [];
              const inMonth = day.getMonth() === cursor.getMonth();
              const isToday = key === ymd(today);
              const isSelected = key === selectedDay;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedDay(key)}
                  onDoubleClick={() => openCreateForDay(key)}
                  className={`flex min-h-[92px] flex-col items-stretch gap-1 border-b border-r border-slate-50 p-1.5 text-left transition-colors last:border-r-0 hover:bg-brand-50/50 ${!inMonth ? 'bg-slate-50/40' : ''} ${isSelected ? 'ring-2 ring-inset ring-brand-400' : ''}`}
                >
                  <span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-medium ${isToday ? 'bg-brand-600 text-white' : inMonth ? 'text-slate-600' : 'text-slate-300'}`}>{day.getDate()}</span>
                  <div className="flex flex-1 flex-col gap-0.5 overflow-hidden">
                    {items.slice(0, 2).map((t) => (
                      <span key={t.id} className={`truncate rounded border px-1 py-0.5 text-[10px] font-medium ${TYPE_COLOR[t.type] ?? 'bg-slate-100 text-slate-600 border-slate-200'} ${t.status === 'done' ? 'opacity-50 line-through' : ''}`}>
                        {t.title}
                      </span>
                    ))}
                    {items.length > 2 && <span className="text-[10px] font-medium text-slate-400">+{items.length - 2} mais</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-card">
          <h3 className="text-sm font-semibold text-slate-800">
            {new Date(selectedDay + 'T00:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
          </h3>
          <div className="mt-3 space-y-2">
            {selectedItems.length === 0 && <p className="text-xs text-slate-400">Nenhum compromisso neste dia.</p>}
            {selectedItems.map((t) => (
              <button key={t.id} onClick={() => { setDetailTask(t); setReportText(''); }} className="block w-full rounded-lg border border-slate-200 p-2.5 text-left transition-colors hover:border-brand-300 hover:bg-brand-50/40">
                <div className="flex items-center justify-between gap-2">
                  <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${TYPE_COLOR[t.type] ?? 'bg-slate-100 text-slate-600 border-slate-200'}`}>{TYPE_LABEL[t.type] ?? t.type}</span>
                  <span className="text-[11px] text-slate-400">{new Date(t.dueAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className={`mt-1.5 text-sm font-medium ${t.status === 'done' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{t.title}</p>
                {t.status === 'done' && <Badge tone="success" className="mt-1.5">Concluído</Badge>}
              </button>
            ))}
          </div>
          <Button variant="secondary" className="mt-3 w-full" onClick={() => openCreateForDay(selectedDay)}>
            <IconPlus width={14} height={14} /> Agendar neste dia
          </Button>
        </div>
      </div>

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Novo agendamento">
        <form onSubmit={handleCreate} className="space-y-4">
          <Field label="Título">
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Ex.: Visita técnica — Rede Mineira" required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tipo">
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </Select>
            </Field>
            <Field label="Prioridade">
              <Select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                <option value="low">Baixa</option>
                <option value="normal">Normal</option>
                <option value="high">Alta</option>
              </Select>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Data">
              <Input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} required />
            </Field>
            <Field label="Hora">
              <Input type="time" value={form.dueTime} onChange={(e) => setForm({ ...form, dueTime: e.target.value })} required />
            </Field>
          </div>
          <Field label="Observações">
            <Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Pauta, endereço, contexto..." />
          </Field>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">{createMutation.isPending ? 'Salvando...' : 'Agendar'}</Button>
        </form>
      </Modal>

      <Modal open={!!detailTask} onClose={() => setDetailTask(null)} title={detailTask?.title ?? ''}>
        {detailTask && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${TYPE_COLOR[detailTask.type] ?? ''}`}>{TYPE_LABEL[detailTask.type] ?? detailTask.type}</span>
              <span className="text-xs text-slate-400">{new Date(detailTask.dueAt).toLocaleString('pt-BR')}</span>
              {detailTask.status === 'done' && <Badge tone="success">Concluído</Badge>}
            </div>
            {detailTask.description && <p className="whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{detailTask.description}</p>}
            {detailTask.status !== 'done' && (
              <>
                <Field label="Relatório da reunião / ligação (opcional)">
                  <Textarea rows={3} value={reportText} onChange={(e) => setReportText(e.target.value)} placeholder="O que foi conversado, próximos passos, decisões..." />
                </Field>
                <Button className="w-full" onClick={() => completeWithReport.mutate()} disabled={completeWithReport.isPending}>
                  <IconCheckSquare width={14} height={14} /> {completeWithReport.isPending ? 'Salvando...' : 'Marcar como concluído'}
                </Button>
              </>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
