import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, friendlyError } from '../../lib/api';
import { Card, CardBody } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Tabs } from '../../components/ui/Tabs';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select, Textarea } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { Toast } from '../../components/ui/Toast';
import { useToast } from '../../hooks/useToast';
import { LoadingState, EmptyState } from '../../components/ui/EmptyState';
import {
  IconTruck, IconChevronRight, IconEdit, IconPhone, IconWhatsapp, IconMail, IconCalendar,
  IconArrowDownLeft, IconArrowUpRight, IconClock,
} from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateBR = (v?: string | null) => (v ? new Date(v).toLocaleDateString('pt-BR') : '—');
const dateTimeBR = (v?: string | null) => (v ? new Date(v).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—');
const poStatusTone: Record<string, any> = { pending: 'neutral', sent: 'info', confirmed: 'brand', received: 'success', cancelled: 'danger' };
const poStatusLabel: Record<string, string> = { pending: 'Pendente', sent: 'Enviado', confirmed: 'Confirmado', received: 'Recebido', cancelled: 'Cancelado' };

const COMM_TYPES = ['call', 'whatsapp', 'email', 'meeting'] as const;
type CommType = (typeof COMM_TYPES)[number];
const commIcon: Record<CommType, any> = { call: IconPhone, whatsapp: IconWhatsapp, email: IconMail, meeting: IconCalendar };
const commLabel: Record<CommType, string> = { call: 'Ligação', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reunião' };
const commTone: Record<CommType, any> = { call: 'brand', whatsapp: 'success', email: 'info', meeting: 'warning' };

export function SupplierDetailPage() {
  const { id } = useParams<{ id: string }>();
  const queryClient = useQueryClient();
  const { message, notify } = useToast();
  const [tab, setTab] = useState('resumo');
  const [editOpen, setEditOpen] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<any>(null);
  const [logModal, setLogModal] = useState<{ open: boolean; type: CommType }>({ open: false, type: 'call' });
  const [logForm, setLogForm] = useState({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done' as 'done' | 'schedule', dueAt: '' });

  const { data: supplier, isLoading } = useQuery({
    queryKey: ['supplier', id],
    queryFn: async () => (await api.get(`/suppliers/${id}`)).data,
    enabled: !!id,
  });

  const updateSupplier = useMutation({
    mutationFn: async () => api.patch(`/suppliers/${id}`, editForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['supplier', id] });
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
      setEditOpen(false);
      notify('Dados do fornecedor atualizados');
    },
    onError: (err) => setEditError(friendlyError(err)),
  });

  const logInteraction = useMutation({
    mutationFn: async () => {
      const type = logModal.type;
      const title = `${commLabel[type]} ${logForm.mode === 'done' ? 'com' : 'agendada com'} ${supplier.companyName}`;
      return api.post('/tasks', {
        type,
        title,
        description: logForm.description || undefined,
        supplierId: id,
        status: logForm.mode === 'done' ? 'done' : 'pending',
        direction: type !== 'meeting' && logForm.mode === 'done' ? logForm.direction : undefined,
        durationMinutes: type === 'call' && logForm.mode === 'done' && logForm.durationMinutes ? Number(logForm.durationMinutes) : undefined,
        dueAt: logForm.mode === 'schedule' && logForm.dueAt ? new Date(logForm.dueAt).toISOString() : undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['supplier', id] });
      setLogModal({ open: false, type: 'call' });
      setLogForm({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done', dueAt: '' });
      notify(logForm.mode === 'done' ? 'Interação registrada no histórico' : 'Atividade agendada');
    },
  });

  if (isLoading) return <LoadingState />;
  if (!supplier) return <EmptyState title="Fornecedor não encontrado" />;

  function openLog(type: CommType) {
    setLogForm({ description: '', direction: 'outbound', durationMinutes: '15', mode: 'done', dueAt: '' });
    setLogModal({ open: true, type });
  }

  function openEdit() {
    setEditForm({
      companyName: supplier.companyName ?? '',
      city: supplier.city ?? '',
      state: supplier.state ?? '',
      email: supplier.email ?? '',
      phone: supplier.phone ?? '',
      whatsapp: supplier.whatsapp ?? '',
      document: supplier.document ?? '',
      commercialTerms: supplier.commercialTerms ?? '',
      status: supplier.status ?? 'active',
    });
    setEditError(null);
    setEditOpen(true);
  }

  const communications = (supplier.tasks ?? [])
    .filter((t: any) => COMM_TYPES.includes(t.type))
    .sort((a: any, b: any) => new Date(b.completedAt ?? b.dueAt ?? b.createdAt).getTime() - new Date(a.completedAt ?? a.dueAt ?? a.createdAt).getTime());

  const tabs = [
    { key: 'resumo', label: 'Resumo' },
    { key: 'comunicacao', label: 'Comunicação', count: communications.length },
    { key: 'produtos', label: 'Produtos', count: supplier.products.length },
    { key: 'compras', label: 'Compras', count: supplier.purchaseOrders.length },
    { key: 'contatos', label: 'Contatos', count: supplier.contacts.length },
  ];

  const totalPurchased = supplier.purchaseOrders.filter((o: any) => o.status === 'received').reduce((acc: number, o: any) => acc + Number(o.totalValue), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-1.5 text-xs text-slate-400">
        <Link to="/suppliers" className="hover:text-slate-600">Fornecedores</Link>
        <IconChevronRight width={12} height={12} />
        <span className="text-slate-500">{supplier.companyName}</span>
      </div>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-600">
            <IconTruck width={26} height={26} />
          </div>
          <div>
            <h1 className="font-display text-xl font-semibold text-slate-800">{supplier.companyName}</h1>
            <p className="text-sm text-slate-500">{supplier.segment || 'Segmento não informado'} · {[supplier.city, supplier.state].filter(Boolean).join('/') || '—'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge tone={supplier.status === 'active' ? 'success' : 'neutral'} dot>{supplier.status === 'active' ? 'Ativo' : 'Inativo'}</Badge>
          <Button variant="secondary" size="sm" onClick={openEdit}>
            <IconEdit width={14} height={14} /> Editar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Total comprado</p><p className="mt-1 text-lg font-semibold text-slate-800">{currency.format(totalPurchased)}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Avaliação</p><p className="mt-1 text-lg font-semibold text-slate-800">{supplier.rating ? `${supplier.rating}/5` : '—'}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Prazo médio (dias)</p><p className="mt-1 text-lg font-semibold text-slate-800">{supplier.leadTimeDays ?? '—'}</p></CardBody></Card>
        <Card><CardBody className="p-4"><p className="text-xs text-slate-500">Produtos fornecidos</p><p className="mt-1 text-lg font-semibold text-slate-800">{supplier.products.length}</p></CardBody></Card>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" size="sm" onClick={() => openLog('call')}><IconPhone width={14} height={14} /> Registrar ligação</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('whatsapp')}><IconWhatsapp width={14} height={14} /> Registrar WhatsApp</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('email')}><IconMail width={14} height={14} /> Registrar e-mail</Button>
        <Button variant="secondary" size="sm" onClick={() => openLog('meeting')}><IconCalendar width={14} height={14} /> Agendar reunião</Button>
      </div>

      <Card>
        <Tabs tabs={tabs} active={tab} onChange={setTab} />
        <CardBody>
          {tab === 'resumo' && (
            <div className="grid gap-2 text-sm sm:grid-cols-2">
              <p><span className="text-slate-400">Documento:</span> <span className="text-slate-700">{supplier.document || '—'}</span></p>
              <p><span className="text-slate-400">E-mail:</span> <span className="text-slate-700">{supplier.email || '—'}</span></p>
              <p><span className="text-slate-400">Telefone:</span> <span className="text-slate-700">{supplier.phone || '—'}</span></p>
              <p><span className="text-slate-400">WhatsApp:</span> <span className="text-slate-700">{supplier.whatsapp || '—'}</span></p>
              <p><span className="text-slate-400">Condições comerciais:</span> <span className="text-slate-700">{supplier.commercialTerms || '—'}</span></p>
            </div>
          )}

          {tab === 'comunicacao' && (
            <div className="space-y-0">
              {communications.length === 0 && (
                <EmptyState title="Nenhuma interação registrada" description="Use os atalhos acima para registrar ligações, WhatsApp, e-mails ou agendar reuniões." />
              )}
              {communications.map((t: any) => {
                const Icon = commIcon[t.type as CommType];
                const done = t.status === 'done';
                return (
                  <div key={t.id} className="flex items-start gap-3 border-b border-slate-50 py-3.5 last:border-0">
                    <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${done ? 'bg-slate-100 text-slate-500' : 'bg-amber-50 text-amber-600'}`}>
                      <Icon width={16} height={16} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-medium text-slate-700">{t.title}</p>
                        <Badge tone={commTone[t.type as CommType]}>{commLabel[t.type as CommType]}</Badge>
                        {t.direction && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                            {t.direction === 'inbound' ? <IconArrowDownLeft width={11} height={11} /> : <IconArrowUpRight width={11} height={11} />}
                            {t.direction === 'inbound' ? 'Recebida' : 'Realizada'}
                          </span>
                        )}
                        {t.durationMinutes != null && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                            <IconClock width={11} height={11} /> {t.durationMinutes} min
                          </span>
                        )}
                        <Badge tone={done ? 'success' : 'info'}>{done ? 'Concluída' : 'Agendada'}</Badge>
                      </div>
                      {t.description && <p className="mt-1 text-sm text-slate-500">{t.description}</p>}
                      <p className="mt-1 text-[11px] text-slate-400">{dateTimeBR(t.completedAt ?? t.dueAt ?? t.createdAt)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'produtos' && (
            <div className="divide-y divide-slate-50">
              {supplier.products.length === 0 && <EmptyState title="Nenhum produto vinculado" />}
              {supplier.products.map((p: any) => (
                <div key={p.id} className="flex items-center justify-between py-3">
                  <span className="text-sm text-slate-700">{p.name}</span>
                  <span className="text-sm text-slate-500">{p.cost ? currency.format(Number(p.cost)) : '—'}</span>
                </div>
              ))}
            </div>
          )}

          {tab === 'compras' && (
            <div className="divide-y divide-slate-50">
              {supplier.purchaseOrders.length === 0 && <EmptyState title="Nenhum pedido de compra" />}
              {supplier.purchaseOrders.map((o: any) => (
                <div key={o.id} className="flex items-center justify-between py-3">
                  <div>
                    <span className="text-sm text-slate-700">Pedido de compra #{o.number}</span>
                    <p className="text-xs text-slate-400">{dateBR(o.createdAt)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-slate-500">{currency.format(Number(o.totalValue))}</span>
                    <Badge tone={poStatusTone[o.status]}>{poStatusLabel[o.status] ?? o.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'contatos' && (
            <div className="divide-y divide-slate-50">
              {supplier.contacts.length === 0 && <EmptyState title="Nenhum contato cadastrado" />}
              {supplier.contacts.map((c: any) => (
                <div key={c.id} className="flex items-center gap-3 py-3">
                  <Avatar name={c.name} size={32} />
                  <div>
                    <p className="text-sm font-medium text-slate-700">{c.name}</p>
                    <p className="text-xs text-slate-400">{c.jobTitle} · {c.email || c.phone || 'sem contato'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      <Modal open={logModal.open} onClose={() => setLogModal({ open: false, type: 'call' })} title={`${commLabel[logModal.type]} — ${supplier.companyName}`}>
        <div className="space-y-4">
          <div className="flex rounded-lg bg-slate-100 p-1 text-sm">
            <button
              type="button"
              onClick={() => setLogForm((f) => ({ ...f, mode: 'done' }))}
              className={`flex-1 rounded-md py-1.5 font-medium transition-colors ${logForm.mode === 'done' ? 'bg-white text-slate-800 shadow-card' : 'text-slate-500'}`}
            >
              Já aconteceu
            </button>
            <button
              type="button"
              onClick={() => setLogForm((f) => ({ ...f, mode: 'schedule' }))}
              className={`flex-1 rounded-md py-1.5 font-medium transition-colors ${logForm.mode === 'schedule' ? 'bg-white text-slate-800 shadow-card' : 'text-slate-500'}`}
            >
              Agendar para depois
            </button>
          </div>

          {logForm.mode === 'done' && logModal.type !== 'meeting' && (
            <Field label="Direção">
              <Select value={logForm.direction} onChange={(e) => setLogForm((f) => ({ ...f, direction: e.target.value }))}>
                <option value="outbound">Realizada por nós (saída)</option>
                <option value="inbound">Recebida do fornecedor (entrada)</option>
              </Select>
            </Field>
          )}

          {logForm.mode === 'done' && logModal.type === 'call' && (
            <Field label="Duração (minutos)">
              <Input type="number" min="0" value={logForm.durationMinutes} onChange={(e) => setLogForm((f) => ({ ...f, durationMinutes: e.target.value }))} />
            </Field>
          )}

          {logForm.mode === 'schedule' && (
            <Field label="Data e hora">
              <Input type="datetime-local" value={logForm.dueAt} onChange={(e) => setLogForm((f) => ({ ...f, dueAt: e.target.value }))} required />
            </Field>
          )}

          <Field label={logModal.type === 'email' ? 'Resumo / assunto' : 'Anotações'}>
            <Textarea rows={3} value={logForm.description} onChange={(e) => setLogForm((f) => ({ ...f, description: e.target.value }))} placeholder="O que foi conversado..." />
          </Field>

          <Button
            className="w-full"
            disabled={logInteraction.isPending || (logForm.mode === 'schedule' && !logForm.dueAt)}
            onClick={() => logInteraction.mutate()}
          >
            {logInteraction.isPending ? 'Salvando...' : logForm.mode === 'done' ? 'Registrar no histórico' : 'Agendar'}
          </Button>
        </div>
      </Modal>

      <Modal open={editOpen} onClose={() => setEditOpen(false)} title="Editar fornecedor" wide>
        {editForm && (
          <div className="space-y-4">
            <Field label="Nome da empresa">
              <Input value={editForm.companyName} onChange={(e) => setEditForm({ ...editForm, companyName: e.target.value })} required />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Documento">
                <Input value={editForm.document} onChange={(e) => setEditForm({ ...editForm, document: e.target.value })} />
              </Field>
              <Field label="Condições comerciais">
                <Input value={editForm.commercialTerms} onChange={(e) => setEditForm({ ...editForm, commercialTerms: e.target.value })} />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Cidade">
                <Input value={editForm.city} onChange={(e) => setEditForm({ ...editForm, city: e.target.value })} />
              </Field>
              <Field label="UF">
                <Input value={editForm.state} onChange={(e) => setEditForm({ ...editForm, state: e.target.value })} maxLength={2} />
              </Field>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="E-mail">
                <Input type="email" value={editForm.email} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} />
              </Field>
              <Field label="Telefone">
                <Input value={editForm.phone} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} />
              </Field>
              <Field label="WhatsApp">
                <Input value={editForm.whatsapp} onChange={(e) => setEditForm({ ...editForm, whatsapp: e.target.value })} />
              </Field>
            </div>
            <Field label="Status">
              <Select value={editForm.status} onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}>
                <option value="active">Ativo</option>
                <option value="inactive">Inativo</option>
              </Select>
            </Field>
            {editError && <p className="text-sm text-red-600">{editError}</p>}
            <Button className="w-full" disabled={updateSupplier.isPending} onClick={() => updateSupplier.mutate()}>
              {updateSupplier.isPending ? 'Salvando...' : 'Salvar alterações'}
            </Button>
          </div>
        )}
      </Modal>

      <Toast message={message} />
    </div>
  );
}
