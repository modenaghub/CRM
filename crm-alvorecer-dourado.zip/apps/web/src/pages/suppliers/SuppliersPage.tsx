import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { FormEvent, MouseEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, friendlyError } from '../../lib/api';
import { Button } from '../../components/ui/Button';
import { Field, Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, CardGridSkeleton } from '../../components/ui/EmptyState';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { Toast } from '../../components/ui/Toast';
import { useToast } from '../../hooks/useToast';
import { IconPlus, IconSearch, IconPhone, IconWhatsapp, IconMail, IconBuilding, IconUsers, IconClock, IconCart } from '../../components/ui/Icons';

const currencyCompact = new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1, style: 'currency', currency: 'BRL' });
const onlyDigits = (v: string) => v.replace(/\D/g, '');

function relativeDate(iso?: string | null) {
  if (!iso) return null;
  const diffMs = Date.now() - new Date(iso).getTime();
  const days = Math.floor(diffMs / 86400000);
  if (days <= 0) return 'hoje';
  if (days === 1) return 'ontem';
  if (days < 30) return `há ${days}d`;
  const months = Math.floor(days / 30);
  if (months < 12) return `há ${months}m`;
  return `há ${Math.floor(months / 12)}a`;
}

export function SuppliersPage() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { message, notify } = useToast();
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ companyName: '', city: '', state: '', phone: '', whatsapp: '', email: '' });

  const { data, isLoading } = useQuery({
    queryKey: ['suppliers', search],
    queryFn: async () => (await api.get('/suppliers', { params: { search, pageSize: 100 } })).data,
  });

  const createMutation = useMutation({
    mutationFn: async () => api.post('/suppliers', form),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
      setOpen(false);
      setForm({ companyName: '', city: '', state: '', phone: '', whatsapp: '', email: '' });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const logInteraction = useMutation({
    mutationFn: async (payload: { supplierId: string; type: string; title: string }) =>
      api.post('/tasks', { ...payload, status: 'done', priority: 'normal' }),
    onSuccess: (_res, vars) => {
      queryClient.invalidateQueries({ queryKey: ['supplier', vars.supplierId] });
    },
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  function quickContact(e: MouseEvent, s: any, type: 'call' | 'whatsapp' | 'email') {
    e.stopPropagation();
    if (type === 'call' && s.phone) {
      window.open(`tel:${onlyDigits(s.phone)}`, '_self');
      logInteraction.mutate({ supplierId: s.id, type: 'call', title: `Ligação para ${s.companyName}` });
      notify(`Ligação registrada para ${s.companyName}`);
    } else if (type === 'whatsapp' && s.whatsapp) {
      window.open(`https://wa.me/${onlyDigits(s.whatsapp)}`, '_blank', 'noopener');
      logInteraction.mutate({ supplierId: s.id, type: 'whatsapp', title: `WhatsApp com ${s.companyName}` });
      notify(`WhatsApp registrado para ${s.companyName}`);
    } else if (type === 'email' && s.email) {
      window.open(`mailto:${s.email}`, '_self');
      logInteraction.mutate({ supplierId: s.id, type: 'email', title: `E-mail para ${s.companyName}` });
      notify(`E-mail registrado para ${s.companyName}`);
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Fornecedores"
        subtitle="Clique em um card para abrir o Fornecedor 360º, ou use os atalhos para contato rápido."
        actions={<Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Novo fornecedor</Button>}
      />

      <div className="relative max-w-sm">
        <IconSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" width={16} height={16} />
        <Input placeholder="Buscar fornecedor..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      {isLoading && <CardGridSkeleton />}
      {!isLoading && data?.data?.length === 0 && <EmptyState title="Nenhum fornecedor cadastrado" />}

      {!isLoading && data?.data?.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {data.data.map((s: any) => (
            <Card key={s.id} interactive onClick={() => navigate(`/suppliers/${s.id}`)} className="group flex flex-col">
              <CardBody className="flex flex-1 flex-col p-4">
                <div className="flex items-center gap-3">
                  <Avatar name={s.companyName} size={40} />
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800" title={s.companyName}>{s.companyName}</p>
                    <p className="flex items-center gap-1 text-xs text-slate-400">
                      <IconBuilding width={12} height={12} />
                      {[s.city, s.state].filter(Boolean).join('/') || 'Local não informado'}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-1.5">
                  <Badge tone={s.status === 'active' ? 'success' : 'neutral'} dot>{s.status === 'active' ? 'Ativo' : 'Inativo'}</Badge>
                  {s.rating ? <Badge tone="warning">{'★'.repeat(s.rating)}</Badge> : null}
                  {s.openOrders > 0 && <Badge tone="info">{s.openOrders} pedido{s.openOrders > 1 ? 's' : ''} aberto{s.openOrders > 1 ? 's' : ''}</Badge>}
                </div>

                <div className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 px-2.5 py-2">
                  <div className="text-center">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconCart width={11} height={11} /> Compras
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700" title={s.totalSpent ? currencyCompact.format(Number(s.totalSpent)) : undefined}>
                      {s.ordersReceived > 0 ? `${s.ordersReceived} · ${currencyCompact.format(Number(s.totalSpent))}` : '—'}
                    </p>
                  </div>
                  <div className="text-center border-x border-slate-200">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconUsers width={11} height={11} /> Contatos
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700">{s.contactsCount ?? 0}</p>
                  </div>
                  <div className="text-center">
                    <p className="flex items-center justify-center gap-1 text-[10px] uppercase tracking-wide text-slate-400">
                      <IconClock width={11} height={11} /> Contato
                    </p>
                    <p className="mt-0.5 text-xs font-semibold text-slate-700">{relativeDate(s.lastInteractionAt) ?? '—'}</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-slate-50 pt-3">
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">Prazo médio</p>
                    <p className="text-sm font-semibold text-slate-700">{s.leadTimeDays ? `${s.leadTimeDays} dias` : '—'}</p>
                  </div>
                  <div className="flex items-center gap-1.5 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                    <button
                      title="Ligar"
                      disabled={!s.phone}
                      onClick={(e) => quickContact(e, s, 'call')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-brand-300 hover:bg-brand-50 hover:text-brand-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconPhone width={14} height={14} />
                    </button>
                    <button
                      title="WhatsApp"
                      disabled={!s.whatsapp}
                      onClick={(e) => quickContact(e, s, 'whatsapp')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconWhatsapp width={14} height={14} />
                    </button>
                    <button
                      title="E-mail"
                      disabled={!s.email}
                      onClick={(e) => quickContact(e, s, 'email')}
                      className="rounded-full border border-slate-200 p-2 text-slate-500 transition-colors hover:border-sky-300 hover:bg-sky-50 hover:text-sky-600 disabled:cursor-not-allowed disabled:opacity-30"
                    >
                      <IconMail width={14} height={14} />
                    </button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Novo fornecedor">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Nome da empresa">
            <Input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Cidade">
              <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </Field>
            <Field label="UF">
              <Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} maxLength={2} />
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Telefone">
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <Field label="WhatsApp">
              <Input value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} />
            </Field>
            <Field label="E-mail">
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
          </div>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">
            {createMutation.isPending ? 'Salvando...' : 'Salvar fornecedor'}
          </Button>
        </form>
      </Modal>

      <Toast message={message} />
    </div>
  );
}
