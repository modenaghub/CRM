import { useQuery } from '@tanstack/react-query';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardBody } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { EmptyState, LoadingState } from '../../components/ui/EmptyState';

const actionLabel: Record<string, string> = {
  create: 'criou', update: 'atualizou', delete: 'removeu', move_stage: 'moveu de etapa',
  convert: 'converteu', update_status: 'atualizou o status de', receive: 'registrou o recebimento de',
};
const entityLabel: Record<string, string> = {
  customer: 'cliente', prospect: 'prospect', opportunity: 'oportunidade', quote: 'orçamento',
  sales_order: 'pedido de venda', purchase_order: 'pedido de compra', purchase_request: 'solicitação de compra',
};

// Auditoria (prompt-mestre, seção 22): "Giovani alterou o valor da oportunidade
// de R$ 20.000 para R$ 25.000 em 06/09/2026 às 15:42" — frase legível, não log cru.
function describe(log: any) {
  const action = actionLabel[log.action] ?? log.action;
  const entity = entityLabel[log.entityType] ?? log.entityType;
  return `${log.userName} ${action} um(a) ${entity}`;
}

export function AuditPage() {
  const { data, isLoading } = useQuery({ queryKey: ['audit-logs'], queryFn: async () => (await api.get('/audit-logs')).data });

  return (
    <div className="space-y-5">
      <PageHeader title="Auditoria" subtitle="Quem fez o quê, quando — registro de todas as ações relevantes do sistema." />

      {isLoading && <LoadingState />}
      {!isLoading && (data ?? []).length === 0 && <EmptyState title="Nenhuma ação registrada ainda" />}

      {!isLoading && (data ?? []).length > 0 && (
        <Card>
          <CardBody className="divide-y divide-slate-50 p-0">
            {data.map((log: any) => (
              <div key={log.id} className="flex items-start justify-between gap-4 px-5 py-3.5">
                <div>
                  <p className="text-sm text-slate-700">{describe(log)}</p>
                  <p className="text-xs text-slate-400">{new Date(log.createdAt).toLocaleString('pt-BR')}</p>
                </div>
                <Badge tone="neutral">{log.action}</Badge>
              </div>
            ))}
          </CardBody>
        </Card>
      )}
    </div>
  );
}
