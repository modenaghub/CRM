import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { FormEvent, useMemo, useState } from 'react';
import { api, friendlyError } from '../../lib/api';
import { Button } from '../../components/ui/Button';
import { Field, Input, Select, Textarea } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { EmptyState, LoadingState } from '../../components/ui/EmptyState';
import { PageHeader } from '../../components/ui/PageHeader';
import { Badge } from '../../components/ui/Badge';
import { StatCard } from '../../components/ui/StatCard';
import { IconPlus, IconSearch, IconCheckSquare, IconClock, IconFlag } from '../../components/ui/Icons';

const TYPE_LABEL: Record<string, string> = {
  call: 'Ligação', whatsapp: 'WhatsApp', email: 'E-mail', meeting: 'Reunião', visit: 'Visita',
  followup: 'Follow-up', internal: 'Interna', proposal: 'Proposta', return: 'Retorno',
};

const PRIORITY_LABEL: Record<string, string> = { low: 'Baixa', normal: 'Normal', high: 'Alta' };

function isOverdue(t: any) {
  return t.status !== 'done' && t.dueAt && new Date(t.dueAt) < new Date();
}

export function TasksPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ type: 'followup', title: '', description: '', priority: 'normal', dueAt: '', customerId: '', prospectId: '' });

  const { data, isLoading } = useQuery({ queryKey: ['tasks'], queryFn: async () => (await api.get('/tasks')).data });
  const { data: customers } = useQuery({ queryKey: ['customers-lite'], queryFn: async () => (await api.get('/customers', { params: { pageSize: 100 } })).data });
  const { data: prospects } = useQuery({ queryKey: ['prospects-lite'], queryFn: async () => (await api.get('/prospects', { params: { pageSize: 100 } })).data });

  const createMutation = useMutation({
    mutationFn: async () => api.post('/tasks', {
      ...form,
      dueAt: form.dueAt ? new Date(form.dueAt).toISOString() : undefined,
      customerId: form.customerId || undefined,
      prospectId: form.prospectId || undefined,
      description: form.description || undefined,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setOpen(false);
      setForm({ type: 'followup', title: '', description: '', priority: 'normal', dueAt: '', customerId: '', prospectId: '' });
    },
    onError: (err) => setError(friendlyError(err)),
  });

  const completeMutation = useMutation({
    mutationFn: async (id: string) => api.post(`/tasks/${id}/complete`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['tasks-all'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-summary'] });
      setDetail(null);
    },
  });

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    createMutation.mutate();
  }

  const filtered = useMemo(() => {
    return (data ?? []).filter((t: any) => {
      if (typeFilter && t.type !== typeFilter) return false;
      if (priorityFilter && t.priority !== priorityFilter) return false;
      if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [data, typeFilter, priorityFilter, search]);

  const columns = useMemo(() => {
    const overdue = filtered.filter((t: any) => isOverdue(t)).sort((a: any, b: any) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime());
    const pending = filtered.filter((t: any) => t.status !== 'done' && !isOverdue(t)).sort((a: any, b: any) => new Date(a.dueAt ?? 0).getTime() - new Date(b.dueAt ?? 0).getTime());
    const done = filtered.filter((t: any) => t.status === 'done').sort((a: any, b: any) => new Date(b.completedAt ?? b.updatedAt).getTime() - new Date(a.completedAt ?? a.updatedAt).getTime());
    return { overdue, pending, done };
  }, [filtered]);

  const stats = {
    total: (data ?? []).length,
    pending: (data ?? []).filter((t: any) => t.status !== 'done').length,
    overdue: (data ?? []).filter((t: any) => isOverdue(t)).length,
    doneThisWeek: (data ?? []).filter((t: any) => t.status === 'done' && t.completedAt && (Date.now() - new Date(t.completedAt).getTime()) < 7 * 86400000).length,
  };

  function TaskCard({ t }: { t: any }) {
    return (
      <button onClick={() => setDetail(t)} className="block w-full rounded-lg border border-slate-200 bg-white p-3 text-left shadow-card transition-all duration-150 hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-popover">
        <div className="flex items-center justify-between gap-2">
          <Badge tone={t.status === 'done' ? 'success' : isOverdue(t) ? 'danger' : t.priority === 'high' ? 'warning' : 'neutral'}>
            {TYPE_LABEL[t.type] ?? t.type}
          </Badge>
          {t.priority === 'high' && t.status !== 'done' && <IconFlag width={13} height={13} className="text-red-500" />}
        </div>
        <p className={`mt-2 text-sm font-medium ${t.status === 'done' ? 'text-slate-400 line-through' : 'text-slate-700'}`}>{t.title}</p>
        <p className="mt-1 flex items-center gap-1 text-xs text-slate-400">
          <IconClock width={11} height={11} /> {t.dueAt ? new Date(t.dueAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'sem prazo'}
        </p>
      </button>
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Tarefas"
        subtitle="Gerenciador de atividades e follow-ups — organizado por status, com histórico conectado ao Cliente 360º."
        actions={<Button onClick={() => setOpen(true)}><IconPlus width={16} height={16} /> Nova tarefa</Button>}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total de tarefas" value={stats.total} icon={<IconCheckSquare width={16} height={16} />} tone="brand" />
        <StatCard label="Pendentes" value={stats.pending} icon={<IconClock width={16} height={16} />} tone="info" />
        <StatCard label="Atrasadas" value={stats.overdue} icon={<IconClock width={16} height={16} />} tone={stats.overdue > 0 ? 'danger' : 'slate'} />
        <StatCard label="Concluídas (7 dias)" value={stats.doneThisWeek} icon={<IconCheckSquare width={16} height={16} />} tone="success" />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative max-w-xs flex-1">
          <IconSearch className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" width={14} height={14} />
          <Input placeholder="Buscar tarefa..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" />
        </div>
        <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="w-auto">
          <option value="">Todos os tipos</option>
          {Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
        <Select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)} className="w-auto">
          <option value="">Todas as prioridades</option>
          {Object.entries(PRIORITY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>
      </div>

      {isLoading && <LoadingState />}
      {!isLoading && filtered.length === 0 && <EmptyState title="Nenhuma tarefa encontrada" description="Ajuste os filtros ou crie uma nova tarefa." />}

      {!isLoading && filtered.length > 0 && (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="space-y-2.5 rounded-xl bg-red-50/40 p-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-red-600">Atrasadas</h3>
              <span className="rounded-full bg-red-100 px-2 py-0.5 text-[11px] font-semibold text-red-600">{columns.overdue.length}</span>
            </div>
            {columns.overdue.map((t: any) => <TaskCard key={t.id} t={t} />)}
            {columns.overdue.length === 0 && <p className="px-1 text-xs text-slate-400">Nenhuma tarefa atrasada.</p>}
          </div>
          <div className="space-y-2.5 rounded-xl bg-sky-50/40 p-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-sky-600">Pendentes</h3>
              <span className="rounded-full bg-sky-100 px-2 py-0.5 text-[11px] font-semibold text-sky-600">{columns.pending.length}</span>
            </div>
            {columns.pending.map((t: any) => <TaskCard key={t.id} t={t} />)}
            {columns.pending.length === 0 && <p className="px-1 text-xs text-slate-400">Nenhuma tarefa pendente.</p>}
          </div>
          <div className="space-y-2.5 rounded-xl bg-emerald-50/40 p-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-emerald-600">Concluídas</h3>
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[11px] font-semibold text-emerald-600">{columns.done.length}</span>
            </div>
            {columns.done.slice(0, 20).map((t: any) => <TaskCard key={t.id} t={t} />)}
            {columns.done.length === 0 && <p className="px-1 text-xs text-slate-400">Nenhuma tarefa concluída ainda.</p>}
          </div>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Nova tarefa">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Título">
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tipo">
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </Select>
            </Field>
            <Field label="Prioridade">
              <Select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                {Object.entries(PRIORITY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="Prazo">
            <Input type="datetime-local" value={form.dueAt} onChange={(e) => setForm({ ...form, dueAt: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Cliente (opcional)">
              <Select value={form.customerId} onChange={(e) => setForm({ ...form, customerId: e.target.value })}>
                <option value="">—</option>
                {(customers?.data ?? []).map((c: any) => <option key={c.id} value={c.id}>{c.companyName}</option>)}
              </Select>
            </Field>
            <Field label="Prospect (opcional)">
              <Select value={form.prospectId} onChange={(e) => setForm({ ...form, prospectId: e.target.value })}>
                <option value="">—</option>
                {(prospects?.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.companyName}</option>)}
              </Select>
            </Field>
          </div>
          <Field label="Descrição (opcional)">
            <Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </Field>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <Button type="submit" disabled={createMutation.isPending} className="w-full">
            {createMutation.isPending ? 'Salvando...' : 'Salvar tarefa'}
          </Button>
        </form>
      </Modal>

      <Modal open={!!detail} onClose={() => setDetail(null)} title={detail?.title ?? ''}>
        {detail && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="brand">{TYPE_LABEL[detail.type] ?? detail.type}</Badge>
              <Badge tone={detail.priority === 'high' ? 'warning' : 'neutral'}>{PRIORITY_LABEL[detail.priority] ?? detail.priority}</Badge>
              {detail.status === 'done' ? <Badge tone="success">Concluída</Badge> : isOverdue(detail) ? <Badge tone="danger">Atrasada</Badge> : <Badge tone="info">Pendente</Badge>}
            </div>
            <p className="text-xs text-slate-400">{detail.dueAt ? new Date(detail.dueAt).toLocaleString('pt-BR') : 'Sem prazo definido'}</p>
            {detail.description && <p className="whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-600">{detail.description}</p>}
            {detail.status !== 'done' && (
              <Button className="w-full" onClick={() => completeMutation.mutate(detail.id)} disabled={completeMutation.isPending}>
                <IconCheckSquare width={14} height={14} /> Marcar como concluída
              </Button>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
