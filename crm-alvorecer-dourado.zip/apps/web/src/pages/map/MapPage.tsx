import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ComposableMap, Geographies, Geography } from 'react-simple-maps';
import { api } from '../../lib/api';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardBody } from '../../components/ui/Card';
import { StatCard } from '../../components/ui/StatCard';
import brazilStates from '../../assets/brazil-states.json';
import { IconMapPin, IconBuilding, IconTrendingUp, IconFlag } from '../../components/ui/Icons';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const currencyCompact = new Intl.NumberFormat('pt-BR', { notation: 'compact', maximumFractionDigits: 1, style: 'currency', currency: 'BRL' });

const STATE_NAMES: Record<string, string> = {
  AC: 'Acre', AL: 'Alagoas', AP: 'Amapá', AM: 'Amazonas', BA: 'Bahia', CE: 'Ceará', DF: 'Distrito Federal',
  ES: 'Espírito Santo', GO: 'Goiás', MA: 'Maranhão', MT: 'Mato Grosso', MS: 'Mato Grosso do Sul', MG: 'Minas Gerais',
  PA: 'Pará', PB: 'Paraíba', PR: 'Paraná', PE: 'Pernambuco', PI: 'Piauí', RJ: 'Rio de Janeiro',
  RN: 'Rio Grande do Norte', RS: 'Rio Grande do Sul', RO: 'Rondônia', RR: 'Roraima', SC: 'Santa Catarina',
  SP: 'São Paulo', SE: 'Sergipe', TO: 'Tocantins',
};

export function MapPage() {
  const [hovered, setHovered] = useState<string | null>(null);
  const { data: geo, isLoading } = useQuery({ queryKey: ['rpt-geo'], queryFn: async () => (await api.get('/reports/geo')).data });

  const byState = useMemo(() => {
    const map = new Map<string, { customers: number; ltv: number; cities: number }>();
    for (const row of geo ?? []) {
      const entry = map.get(row.state) ?? { customers: 0, ltv: 0, cities: 0 };
      entry.customers += row.customers;
      entry.ltv += row.totalLtv;
      entry.cities += 1;
      map.set(row.state, entry);
    }
    return map;
  }, [geo]);

  const maxCustomers = Math.max(1, ...Array.from(byState.values()).map((v) => v.customers));
  const totalCustomers = Array.from(byState.values()).reduce((a, v) => a + v.customers, 0);
  const totalLtv = Array.from(byState.values()).reduce((a, v) => a + v.ltv, 0);
  const statesCovered = byState.size;
  const citiesCovered = (geo ?? []).length;
  const countries = new Set((geo ?? []).map((r: any) => r.country)).size;

  const colorFor = (sigla: string) => {
    const entry = byState.get(sigla);
    if (!entry || entry.customers === 0) return '#e2e8f0';
    const intensity = entry.customers / maxCustomers;
    // Interpola de brand-200 a brand-700 conforme a concentração de clientes.
    const stops = [
      { t: 0, c: [199, 210, 254] },
      { t: 0.5, c: [99, 102, 241] },
      { t: 1, c: [67, 56, 202] },
    ];
    let lo = stops[0], hi = stops[stops.length - 1];
    for (let i = 0; i < stops.length - 1; i++) {
      if (intensity >= stops[i].t && intensity <= stops[i + 1].t) { lo = stops[i]; hi = stops[i + 1]; break; }
    }
    const span = hi.t - lo.t || 1;
    const localT = (intensity - lo.t) / span;
    const rgb = lo.c.map((v, i) => Math.round(v + (hi.c[i] - v) * localT));
    return `rgb(${rgb.join(',')})`;
  };

  const rankedStates = Array.from(byState.entries()).sort((a, b) => b[1].customers - a[1].customers);
  const rankedCities = [...(geo ?? [])].sort((a: any, b: any) => b.customers - a.customers);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Mapa de Clientes"
        subtitle="Distribuição geográfica da carteira — cidade, estado e país, com concentração de clientes e LTV."
        actions={<span className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-sky-500 to-brand-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm"><IconMapPin width={14} height={14} /> Geolocalização comercial</span>}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Clientes localizados" value={totalCustomers} icon={<IconBuilding width={16} height={16} />} tone="brand" />
        <StatCard label="Estados atendidos" value={statesCovered} hint="de 27 UFs" icon={<IconMapPin width={16} height={16} />} tone="info" />
        <StatCard label="Cidades atendidas" value={citiesCovered} icon={<IconFlag width={16} height={16} />} tone="violet" />
        <StatCard label="LTV total mapeado" value={currencyCompact.format(totalLtv)} hint={`${countries} país(es)`} icon={<IconTrendingUp width={16} height={16} />} tone="success" />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Concentração por estado" subtitle="Quanto mais escuro, maior o número de clientes" />
          <CardBody>
            {isLoading ? (
              <div className="flex h-[420px] items-center justify-center text-sm text-slate-400">Carregando mapa...</div>
            ) : (
              <div className="relative">
                <ComposableMap projection="geoMercator" projectionConfig={{ center: [-52, -15], scale: 750 }} width={520} height={480} style={{ width: '100%', height: 'auto' }}>
                  <Geographies geography={brazilStates as any}>
                    {({ geographies }: any) =>
                      geographies.map((geography: any) => {
                        const sigla = geography.properties.sigla;
                        return (
                          <Geography
                            key={geography.rsmKey}
                            geography={geography}
                            onMouseEnter={() => setHovered(sigla)}
                            onMouseLeave={() => setHovered(null)}
                            style={{
                              default: { fill: colorFor(sigla), stroke: '#ffffff', strokeWidth: 0.75, outline: 'none' },
                              hover: { fill: '#f59e0b', stroke: '#ffffff', strokeWidth: 0.75, outline: 'none', cursor: 'pointer' },
                              pressed: { fill: '#d97706', stroke: '#ffffff', strokeWidth: 0.75, outline: 'none' },
                            }}
                          />
                        );
                      })
                    }
                  </Geographies>
                </ComposableMap>
                {hovered && (
                  <div className="pointer-events-none absolute left-3 top-3 rounded-lg border border-slate-200 bg-white px-3 py-2 shadow-popover">
                    <p className="text-xs font-semibold text-slate-700">{STATE_NAMES[hovered] ?? hovered} ({hovered})</p>
                    <p className="text-xs text-slate-500">{byState.get(hovered)?.customers ?? 0} cliente(s) · {currencyCompact.format(byState.get(hovered)?.ltv ?? 0)} LTV</p>
                  </div>
                )}
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Ranking por estado" subtitle="Estados com mais clientes" />
          <CardBody className="max-h-[480px] space-y-1 overflow-y-auto">
            {rankedStates.length === 0 && <p className="text-xs text-slate-400">Nenhum cliente com localização cadastrada.</p>}
            {rankedStates.map(([uf, v], i) => (
              <div key={uf} className="flex items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-slate-50">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-indigo-600 text-[11px] font-bold text-white">{uf}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-700">{STATE_NAMES[uf] ?? uf}</p>
                  <p className="text-xs text-slate-400">{v.cities} cidade{v.cities !== 1 ? 's' : ''} · {currencyCompact.format(v.ltv)} LTV</p>
                </div>
                <span className="text-sm font-semibold text-slate-700">{v.customers}</span>
                <span className="w-1 text-[10px] font-medium text-slate-400">#{i + 1}</span>
              </div>
            ))}
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader title="Detalhamento por cidade" subtitle="Todos os clientes agrupados por localização" />
        <CardBody className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs uppercase tracking-wide text-slate-400">
                <th className="pb-2 font-medium">Cidade</th>
                <th className="pb-2 font-medium">Estado</th>
                <th className="pb-2 font-medium">País</th>
                <th className="pb-2 text-right font-medium">Clientes</th>
                <th className="pb-2 text-right font-medium">LTV total</th>
              </tr>
            </thead>
            <tbody>
              {rankedCities.map((row: any) => (
                <tr key={`${row.city}-${row.state}`} className="border-b border-slate-50 last:border-0 hover:bg-slate-50">
                  <td className="py-2.5 font-medium text-slate-700">{row.city}</td>
                  <td className="py-2.5 text-slate-500">{row.state}</td>
                  <td className="py-2.5 text-slate-500">{row.country}</td>
                  <td className="py-2.5 text-right font-semibold text-slate-700">{row.customers}</td>
                  <td className="py-2.5 text-right text-slate-500">{currency.format(row.totalLtv)}</td>
                </tr>
              ))}
              {rankedCities.length === 0 && (
                <tr><td colSpan={5} className="py-6 text-center text-sm text-slate-400">Nenhum cliente com localização cadastrada ainda.</td></tr>
              )}
            </tbody>
          </table>
        </CardBody>
      </Card>
    </div>
  );
}
