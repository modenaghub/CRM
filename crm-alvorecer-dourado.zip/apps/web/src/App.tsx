import { Navigate, Route, Routes } from 'react-router-dom';
import { ProtectedRoute } from './components/ProtectedRoute';
import { AppLayout } from './components/layout/AppLayout';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterOrganizationPage } from './pages/auth/RegisterOrganizationPage';
import { DashboardPage } from './pages/DashboardPage';
import { CustomersPage } from './pages/customers/CustomersPage';
import { CustomerDetailPage } from './pages/customers/CustomerDetailPage';
import { ProspectsPage } from './pages/prospects/ProspectsPage';
import { SuppliersPage } from './pages/suppliers/SuppliersPage';
import { SupplierDetailPage } from './pages/suppliers/SupplierDetailPage';
import { ProductsPage } from './pages/products/ProductsPage';
import { TasksPage } from './pages/tasks/TasksPage';
import { KanbanPage } from './pages/opportunities/KanbanPage';
import { CustomObjectsPage } from './pages/custom-objects/CustomObjectsPage';
import { SalesPage } from './pages/sales/SalesPage';
import { PurchasesPage } from './pages/purchases/PurchasesPage';
import { GoalsPage } from './pages/goals/GoalsPage';
import { AuditPage } from './pages/audit/AuditPage';
import { ConversationsPage } from './pages/conversations/ConversationsPage';
import { EmailPage } from './pages/comingsoon/EmailPage';
import { CalendarPage } from './pages/calendar/CalendarPage';
import { AiCopilotPage } from './pages/comingsoon/AiCopilotPage';
import { ReportsPage } from './pages/reports/ReportsPage';
import { MapPage } from './pages/map/MapPage';
import { SettingsPage } from './pages/comingsoon/SettingsPage';

function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterOrganizationPage />} />

      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/customers/:id" element={<CustomerDetailPage />} />
          <Route path="/prospects" element={<ProspectsPage />} />
          <Route path="/suppliers" element={<SuppliersPage />} />
          <Route path="/suppliers/:id" element={<SupplierDetailPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/tasks" element={<TasksPage />} />
          <Route path="/opportunities" element={<KanbanPage />} />
          <Route path="/custom-objects" element={<CustomObjectsPage />} />
          <Route path="/sales" element={<SalesPage />} />
          <Route path="/purchases" element={<PurchasesPage />} />
          <Route path="/goals" element={<GoalsPage />} />
          <Route path="/audit" element={<AuditPage />} />
          <Route path="/whatsapp" element={<ConversationsPage />} />
          <Route path="/email" element={<EmailPage />} />
          <Route path="/calendar" element={<CalendarPage />} />
          <Route path="/ai" element={<AiCopilotPage />} />
          <Route path="/bi" element={<ReportsPage />} />
          <Route path="/map" element={<MapPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
