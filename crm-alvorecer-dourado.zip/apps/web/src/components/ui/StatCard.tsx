import { ReactNode } from 'react';
import clsx from 'clsx';

const TONE_GRADIENT: Record<string, string> = {
  brand: 'from-brand-500 to-indigo-600',
  success: 'from-emerald-500 to-teal-600',
  warning: 'from-amber-500 to-orange-600',
  danger: 'from-rose-500 to-red-600',
  info: 'from-sky-500 to-cyan-600',
  violet: 'from-fuchsia-500 to-purple-600',
  slate: 'from-slate-500 to-slate-700',
};

const TREND_CLASSES: Record<'up' | 'down' | 'neutral', string> = {
  up: 'text-emerald-600 bg-emerald-50',
  down: 'text-red-600 bg-red-50',
  neutral: 'text-slate-500 bg-slate-100',
};

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = 'brand',
  trend,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  tone?: 'brand' | 'success' | 'warning' | 'danger' | 'info' | 'violet' | 'slate';
  trend?: { direction: 'up' | 'down' | 'neutral'; label: string };
}) {
  return (
    <div className="group relative overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-card transition-all duration-200 ease-smooth hover:-translate-y-0.5 hover:shadow-popover">
      <div className={clsx('pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br opacity-[0.08]', TONE_GRADIENT[tone])} />
      <div className="relative flex items-center justify-between">
        <p className="text-xs font-medium text-slate-500">{label}</p>
        {icon && (
          <span className={clsx('flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br text-white shadow-sm', TONE_GRADIENT[tone])}>
            {icon}
          </span>
        )}
      </div>
      <p className="relative mt-2 text-2xl font-semibold tracking-tight text-slate-800">{value}</p>
      <div className="relative mt-1 flex items-center gap-2">
        {hint && <p className="text-xs text-slate-400">{hint}</p>}
        {trend && (
          <span className={clsx('inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold', TREND_CLASSES[trend.direction])}>
            {trend.direction === 'up' ? '↑' : trend.direction === 'down' ? '↓' : '·'} {trend.label}
          </span>
        )}
      </div>
    </div>
  );
}
