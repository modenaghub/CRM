import { IconCheckSquare } from './Icons';

export function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="pointer-events-none fixed bottom-6 right-6 z-[60] flex animate-toast-in items-center gap-2 rounded-lg bg-slate-900 px-4 py-3 text-sm text-white shadow-modal">
      <IconCheckSquare width={16} height={16} className="text-emerald-400" />
      {message}
    </div>
  );
}
