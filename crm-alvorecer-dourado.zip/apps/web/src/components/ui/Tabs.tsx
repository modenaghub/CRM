import clsx from 'clsx';

export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { key: string; label: string; count?: number }[];
  active: string;
  onChange: (key: string) => void;
}) {
  return (
    <div className="flex gap-1 overflow-x-auto border-b border-slate-200">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => onChange(tab.key)}
          className={clsx(
            'relative flex shrink-0 items-center gap-1.5 px-3.5 py-2.5 text-sm font-medium transition-colors',
            active === tab.key ? 'text-brand-700' : 'text-slate-500 hover:text-slate-700',
          )}
        >
          {tab.label}
          {tab.count !== undefined && (
            <span className={clsx('rounded-full px-1.5 py-0.5 text-[11px]', active === tab.key ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-500')}>
              {tab.count}
            </span>
          )}
          {active === tab.key && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-brand-600" />}
        </button>
      ))}
    </div>
  );
}
