import { SVGProps } from 'react';

// Conjunto de ícones próprios (linha, 24x24, currentColor) — identidade visual
// própria da plataforma (prompt-mestre, seção 30: "não copiar interfaces,
// criar identidade própria"). Formas geométricas simples, sem dependência de
// bibliotecas/fontes externas.
type IconProps = SVGProps<SVGSVGElement>;
const base = {
  width: 18,
  height: 18,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.8,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
};

export const IconDashboard = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3.5" y="3.5" width="7" height="8.5" rx="1.5" />
    <rect x="13.5" y="3.5" width="7" height="5" rx="1.5" />
    <rect x="13.5" y="11.5" width="7" height="9" rx="1.5" />
    <rect x="3.5" y="15" width="7" height="5.5" rx="1.5" />
  </svg>
);

export const IconBuilding = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="4" y="3" width="12" height="18" rx="1" />
    <rect x="16.5" y="9" width="4" height="12" rx="1" />
    <line x1="7" y1="7" x2="7" y2="7.01" />
    <line x1="10.5" y1="7" x2="10.5" y2="7.01" />
    <line x1="7" y1="11" x2="7" y2="11.01" />
    <line x1="10.5" y1="11" x2="10.5" y2="11.01" />
    <line x1="7" y1="15" x2="7" y2="15.01" />
    <line x1="10.5" y1="15" x2="10.5" y2="15.01" />
  </svg>
);

export const IconTarget = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <circle cx="12" cy="12" r="5" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none" />
  </svg>
);

export const IconTrendingUp = (p: IconProps) => (
  <svg {...base} {...p}>
    <polyline points="3.5,17 9.5,11 13.5,15 20.5,7" />
    <polyline points="14.5,7 20.5,7 20.5,13" />
  </svg>
);

export const IconPackage = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M3.5 7.5 12 3l8.5 4.5v9L12 21l-8.5-4.5v-9Z" />
    <polyline points="3.5,7.5 12,12 20.5,7.5" />
    <line x1="12" y1="12" x2="12" y2="21" />
  </svg>
);

export const IconTruck = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="2.5" y="7" width="11" height="9" rx="1" />
    <path d="M13.5 10h4l3 3v3h-7z" />
    <circle cx="6.5" cy="18" r="1.7" />
    <circle cx="16.5" cy="18" r="1.7" />
  </svg>
);

export const IconCheckSquare = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="2.5" />
    <polyline points="7.5,12 11,15.5 17,9" />
  </svg>
);

export const IconPuzzle = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M8 4h4v2.2a1.8 1.8 0 1 0 0 3.6V12h3.2a1.8 1.8 0 1 1 0 3.6V19H4v-4h2.2a1.8 1.8 0 1 0 0-3.6H4V8h4V4Z" />
  </svg>
);

export const IconFileText = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M6 3h8l4.5 4.5V21H6Z" />
    <polyline points="14,3 14,7.5 18.5,7.5" />
    <line x1="8.5" y1="12.5" x2="15.5" y2="12.5" />
    <line x1="8.5" y1="16" x2="15.5" y2="16" />
  </svg>
);

export const IconCart = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="9" cy="20" r="1.4" />
    <circle cx="17" cy="20" r="1.4" />
    <path d="M2.5 3h2.4l2 12.2A2 2 0 0 0 8.85 17H18a2 2 0 0 0 1.95-1.55L21.5 8H6" />
  </svg>
);

export const IconClipboardList = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="5" y="4" width="14" height="17" rx="1.5" />
    <rect x="8.5" y="2.5" width="7" height="3" rx="1" />
    <line x1="8" y1="11" x2="16" y2="11" />
    <line x1="8" y1="14.5" x2="16" y2="14.5" />
    <line x1="8" y1="18" x2="13" y2="18" />
  </svg>
);

export const IconFlag = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="5" y1="3.5" x2="5" y2="21" />
    <path d="M5 4.5h13l-3.2 4L18 12.5H5Z" />
  </svg>
);

export const IconShield = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M12 3.5 19 6v5.5c0 5-3 8-7 9.5-4-1.5-7-4.5-7-9.5V6Z" />
    <polyline points="9,12 11.2,14.2 15.2,10" />
  </svg>
);

export const IconMessage = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M3.5 5.5h17v11h-8.5L7 20.5v-4H3.5Z" />
    <line x1="7.5" y1="9.5" x2="16.5" y2="9.5" />
    <line x1="7.5" y1="13" x2="13" y2="13" />
  </svg>
);

export const IconMail = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3" y="5" width="18" height="14" rx="2" />
    <polyline points="3.5,6 12,13 20.5,6" />
  </svg>
);

export const IconCalendar = (p: IconProps) => (
  <svg {...base} {...p}>
    <rect x="3.5" y="5" width="17" height="15.5" rx="2" />
    <line x1="3.5" y1="9.5" x2="20.5" y2="9.5" />
    <line x1="8" y1="3" x2="8" y2="7" />
    <line x1="16" y1="3" x2="16" y2="7" />
  </svg>
);

export const IconSparkles = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M12 3.5 13.6 9l5.4 1.6L13.6 12.2 12 17.7 10.4 12.2 5 10.6 10.4 9Z" />
    <path d="M19 15.5 19.7 17.8 22 18.5 19.7 19.2 19 21.5 18.3 19.2 16 18.5 18.3 17.8Z" />
  </svg>
);

export const IconBarChart = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="4" y1="20.5" x2="20.5" y2="20.5" />
    <rect x="5.5" y="12" width="3.4" height="8.5" />
    <rect x="10.8" y="7" width="3.4" height="13.5" />
    <rect x="16.1" y="15" width="3.4" height="5.5" />
  </svg>
);

export const IconSettings = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l2-1.5-2-3.4-2.3.9a7.6 7.6 0 0 0-2.6-1.5L14 2.5h-4l-.5 2.5a7.6 7.6 0 0 0-2.6 1.5l-2.3-.9-2 3.4 2 1.5a7.6 7.6 0 0 0 0 3l-2 1.6 2 3.4 2.3-.9c.77.66 1.65 1.17 2.6 1.5l.5 2.4h4l.5-2.4a7.6 7.6 0 0 0 2.6-1.5l2.3.9 2-3.4Z" />
  </svg>
);

export const IconSearch = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="11" cy="11" r="7" />
    <line x1="21" y1="21" x2="16.2" y2="16.2" />
  </svg>
);

export const IconBell = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M6 10.5a6 6 0 0 1 12 0c0 4 1.5 5.5 1.5 5.5h-15S6 14.5 6 10.5Z" />
    <path d="M10 19a2.2 2.2 0 0 0 4 0" />
  </svg>
);

export const IconChevronDown = (p: IconProps) => (
  <svg {...base} {...p}>
    <polyline points="6,9 12,15 18,9" />
  </svg>
);

export const IconChevronRight = (p: IconProps) => (
  <svg {...base} {...p}>
    <polyline points="9,6 15,12 9,18" />
  </svg>
);

export const IconLogOut = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M9 20.5H5.5a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2H9" />
    <polyline points="16,16.5 21,12 16,7.5" />
    <line x1="21" y1="12" x2="9.5" y2="12" />
  </svg>
);

export const IconPlus = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="12" y1="4.5" x2="12" y2="19.5" />
    <line x1="4.5" y1="12" x2="19.5" y2="12" />
  </svg>
);

export const IconX = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="5.5" y1="5.5" x2="18.5" y2="18.5" />
    <line x1="18.5" y1="5.5" x2="5.5" y2="18.5" />
  </svg>
);

export const IconUsers = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="9" cy="8" r="3.2" />
    <path d="M3 20v-1.2A4.8 4.8 0 0 1 9 14a4.8 4.8 0 0 1 4.8 4.8V20" />
    <circle cx="17" cy="9" r="2.6" />
    <path d="M15.5 14.2A4.4 4.4 0 0 1 21 18.4V20" />
  </svg>
);

export const IconPhone = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M5.5 3.5h3l1.5 4-2 1.5a11 11 0 0 0 5.5 5.5l1.5-2 4 1.5v3a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 4 5.1a1.5 1.5 0 0 1 1.5-1.6Z" />
  </svg>
);

export const IconWhatsapp = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M6 18.5 4.5 21l2.6-1.4A8.5 8.5 0 1 0 4 12a8.4 8.4 0 0 0 1 4Z" />
    <path d="M9 10c0 3.5 2.5 6 6 6 .6 0 .6-1.5.1-2s-1.4-.8-1.7-.5l-.5.6c-1-.4-2.1-1.5-2.5-2.5l.6-.5c.3-.3.1-1.2-.5-1.7S9 8.4 9 10Z" />
  </svg>
);

export const IconEdit = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z" />
    <line x1="13.5" y1="6.5" x2="17.5" y2="10.5" />
  </svg>
);

export const IconArrowDownLeft = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="18" y1="6" x2="6" y2="18" />
    <polyline points="6,9 6,18 15,18" />
  </svg>
);

export const IconArrowUpRight = (p: IconProps) => (
  <svg {...base} {...p}>
    <line x1="6" y1="18" x2="18" y2="6" />
    <polyline points="9,6 18,6 18,15" />
  </svg>
);

export const IconClock = (p: IconProps) => (
  <svg {...base} {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <polyline points="12,7 12,12 15.5,14" />
  </svg>
);

export const IconMapPin = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M12 21.5s7-6.4 7-12A7 7 0 1 0 5 9.5c0 5.6 7 12 7 12Z" />
    <circle cx="12" cy="9.5" r="2.4" />
  </svg>
);

export const IconChevronLeft = (p: IconProps) => (
  <svg {...base} {...p}>
    <polyline points="15,6 9,12 15,18" />
  </svg>
);

export const IconInbox = (p: IconProps) => (
  <svg {...base} {...p}>
    <path d="M3.5 12.5h5l1.5 3h4l1.5-3h5" />
    <path d="M5 5.5h14l2 7v6.5a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 19V12.5Z" />
  </svg>
);
