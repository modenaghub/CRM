import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../lib/api';
import { IconSearch, IconX } from '../ui/Icons';

// Pesquisa global (prompt-mestre, seção 24): busca rápida, resultados
// agrupados por categoria, navega direto para o cadastro.
const GROUPS: { key: string; label: string; path: (id: string) => string }[] = [
  { key: 'customers', label: 'Clientes', path: (id) => `/customers/${id}` },
  { key: 'prospects', label: 'Prospects', path: () => `/prospects` },
  { key: 'suppliers', label: 'Fornecedores', path: (id) => `/suppliers/${id}` },
  { key: 'products', label: 'Produtos', path: () => `/products` },
  { key: 'opportunities', label: 'Oportunidades', path: () => `/opportunities` },
];

export function GlobalSearch() {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const ref = useRef<HTMLDivElement>(null);

  const { data } = useQuery({
    queryKey: ['global-search', q],
    queryFn: async () => (await api.get('/search', { params: { q } })).data,
    enabled: q.trim().length >= 2,
  });

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const hasResults = data && GROUPS.some((g) => data[g.key]?.length > 0);

  return (
    <div ref={ref} className="relative w-full max-w-md">
      <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm focus-within:border-brand-400 focus-within:bg-white focus-within:ring-1 focus-within:ring-brand-400">
        <IconSearch className="text-slate-400" width={16} height={16} />
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Buscar clientes, produtos, oportunidades..."
          className="w-full bg-transparent text-slate-700 outline-none placeholder:text-slate-400"
        />
        {q && (
          <button onClick={() => setQ('')} className="text-slate-400 hover:text-slate-600">
            <IconX width={14} height={14} />
          </button>
        )}
      </div>

      {open && q.trim().length >= 2 && (
        <div className="absolute left-0 right-0 top-full z-40 mt-1.5 max-h-96 overflow-y-auto rounded-xl border border-slate-200 bg-white p-2 shadow-popover animate-fade-in">
          {!hasResults && <p className="px-3 py-6 text-center text-sm text-slate-400">Nenhum resultado para "{q}".</p>}
          {GROUPS.map((g) => {
            const items = data?.[g.key] ?? [];
            if (!items.length) return null;
            return (
              <div key={g.key} className="mb-1 last:mb-0">
                <p className="px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">{g.label}</p>
                {items.map((item: any) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      navigate(g.path(item.id));
                      setOpen(false);
                      setQ('');
                    }}
                    className="flex w-full flex-col items-start rounded-lg px-2.5 py-1.5 text-left text-sm hover:bg-slate-50"
                  >
                    <span className="font-medium text-slate-700">{item.label}</span>
                    {item.sub && <span className="text-xs text-slate-400">{item.sub}</span>}
                  </button>
                ))}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
