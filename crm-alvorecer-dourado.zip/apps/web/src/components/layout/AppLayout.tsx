import { NavLink, Outlet, useLocation } from 'react-router-dom';
import clsx from 'clsx';
import { useAuthStore } from '../../store/auth';
import { useMe } from '../../hooks/useMe';
import { GlobalSearch } from './GlobalSearch';
import { NotificationsBell } from './NotificationsBell';
import { Avatar } from '../ui/Avatar';
import {
  IconDashboard, IconBuilding, IconTarget, IconTrendingUp, IconPackage, IconTruck, IconCheckSquare,
  IconPuzzle, IconFileText, IconCart, IconFlag, IconShield, IconMessage, IconMail,
  IconCalendar, IconSparkles, IconBarChart, IconSettings, IconLogOut, IconChevronDown, IconMapPin,
} from '../ui/Icons';

// Menu principal agrupado (prompt-mestre, seção 31). Cada item só aparece se
// o módulo correspondente estiver habilitado para a organização (Module
// Engine) — isso é o que permite o mesmo shell atender qualquer vertical.
type MenuItem = { key: string; label: string; path: string; icon: (p: any) => JSX.Element; module: string };
type MenuGroup = { label: string; items: MenuItem[] };

const MENU_GROUPS: MenuGroup[] = [
  {
    label: 'CRM',
    items: [
      { key: 'prospects', label: 'Prospects', path: '/prospects', icon: IconTarget, module: 'prospects' },
      { key: 'customers', label: 'Clientes', path: '/customers', icon: IconBuilding, module: 'customers' },
      { key: 'opportunities', label: 'Oportunidades', path: '/opportunities', icon: IconTrendingUp, module: 'opportunities' },
    ],
  },
  {
    label: 'Vendas',
    items: [
      { key: 'sales', label: 'Orçamentos & Pedidos', path: '/sales', icon: IconFileText, module: 'sales' },
      { key: 'products', label: 'Produtos', path: '/products', icon: IconPackage, module: 'products' },
      { key: 'goals', label: 'Metas', path: '/goals', icon: IconFlag, module: 'goals' },
    ],
  },
  {
    label: 'Compras',
    items: [
      { key: 'suppliers', label: 'Fornecedores', path: '/suppliers', icon: IconTruck, module: 'suppliers' },
      { key: 'purchases', label: 'Solicitações & Pedidos', path: '/purchases', icon: IconCart, module: 'purchases' },
    ],
  },
  {
    label: 'Comunicação & Agenda',
    items: [
      { key: 'tasks', label: 'Tarefas', path: '/tasks', icon: IconCheckSquare, module: 'tasks' },
      { key: 'calendar', label: 'Calendário', path: '/calendar', icon: IconCalendar, module: 'calendar' },
      { key: 'whatsapp', label: 'Conversas', path: '/whatsapp', icon: IconMessage, module: 'whatsapp' },
      { key: 'email', label: 'E-mail', path: '/email', icon: IconMail, module: 'email' },
    ],
  },
  {
    label: 'Inteligência & Gestão',
    items: [
      { key: 'ai', label: 'Copiloto IA', path: '/ai', icon: IconSparkles, module: 'ai' },
      { key: 'bi', label: 'Relatórios & BI', path: '/bi', icon: IconBarChart, module: 'bi' },
      { key: 'map', label: 'Mapa de Clientes', path: '/map', icon: IconMapPin, module: 'customers' },
      { key: 'audit', label: 'Auditoria', path: '/audit', icon: IconShield, module: 'audit' },
    ],
  },
  {
    label: 'Configurações',
    items: [
      { key: 'custom_objects', label: 'Objetos personalizados', path: '/custom-objects', icon: IconPuzzle, module: 'custom_objects' },
      { key: 'settings', label: 'Preferências', path: '/settings', icon: IconSettings, module: 'dashboard' },
    ],
  },
];

function NavItem({ item }: { item: MenuItem }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.path}
      className={({ isActive }) =>
        clsx(
          'group relative flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors',
          isActive ? 'bg-white/10 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-slate-100',
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive && <span className="absolute -left-3 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-gradient-to-b from-brand-400 to-fuchsia-400" />}
          <span className={clsx('flex h-6 w-6 items-center justify-center', isActive ? 'text-brand-300' : 'text-slate-500 group-hover:text-slate-300')}>
            <Icon />
          </span>
          {item.label}
        </>
      )}
    </NavLink>
  );
}

export function AppLayout() {
  const { organization, user, enabledModules } = useAuthStore();
  const logout = useAuthStore((s) => s.logout);
  const location = useLocation();
  useMe();

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="flex w-64 shrink-0 flex-col bg-slate-900">
        <div className="flex items-center gap-2.5 border-b border-white/10 px-5 py-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-brand-400 via-brand-600 to-fuchsia-600 font-display text-sm font-bold text-white shadow-lg shadow-brand-900/40">
            {organization?.name?.[0]?.toUpperCase() ?? 'N'}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{organization?.name ?? 'Nexus CRM'}</p>
            <p className="truncate text-xs capitalize text-slate-400">{organization?.segmentKey ?? 'plataforma'}</p>
          </div>
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              clsx(
                'relative flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors',
                isActive ? 'bg-white/10 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-slate-100',
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && <span className="absolute -left-3 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-gradient-to-b from-brand-400 to-fuchsia-400" />}
                <span className={clsx('flex h-6 w-6 items-center justify-center', isActive ? 'text-brand-300' : 'text-slate-500')}>
                  <IconDashboard />
                </span>
                Dashboard
              </>
            )}
          </NavLink>

          {MENU_GROUPS.map((group) => {
            const visibleItems = group.items.filter((item) => enabledModules.includes(item.module));
            if (visibleItems.length === 0) return null;
            return (
              <div key={group.label}>
                <p className="px-2.5 pb-1.5 text-[11px] font-semibold uppercase tracking-wide text-slate-500">{group.label}</p>
                <div className="space-y-0.5">
                  {visibleItems.map((item) => (
                    <NavItem key={item.key} item={item} />
                  ))}
                </div>
              </div>
            );
          })}
        </nav>

        <div className="border-t border-white/10 p-3">
          <div className="group relative flex items-center gap-2.5 rounded-lg px-2 py-2 hover:bg-white/5">
            <Avatar name={user?.name ?? '?'} size={30} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-slate-100">{user?.name}</p>
              <p className="truncate text-[11px] text-slate-500">{user?.email}</p>
            </div>
            <button onClick={logout} className="text-slate-500 hover:text-red-400" aria-label="Sair" title="Sair">
              <IconLogOut width={16} height={16} />
            </button>
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-white/90 px-6 shadow-sm backdrop-blur">
          <GlobalSearch />
          <div className="flex items-center gap-2">
            <NotificationsBell />
            <div className="mx-1 h-6 w-px bg-slate-200" />
            <button className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-100">
              <Avatar name={user?.name ?? '?'} size={28} />
              <IconChevronDown width={14} height={14} className="text-slate-400" />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-slate-50">
          <div key={location.pathname} className="mx-auto max-w-7xl animate-page-in px-6 py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
