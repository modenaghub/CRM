import { useCallback, useRef, useState } from 'react';

// Toast leve e local à página — usado para confirmar ações rápidas (registrar
// ligação, copiar link etc.) sem interromper o fluxo com um modal.
export function useToast() {
  const [message, setMessage] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const notify = useCallback((msg: string) => {
    setMessage(msg);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(null), 2600);
  }, []);

  return { message, notify };
}
