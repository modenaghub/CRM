import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { eq, sql } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool, { schema });

const MODULE_CATALOG: Array<{ key: string; name: string; isCore?: boolean }> = [
  { key: 'customers', name: 'Clientes', isCore: true },
  { key: 'prospects', name: 'Prospects', isCore: true },
  { key: 'suppliers', name: 'Fornecedores' },
  { key: 'contacts', name: 'Contatos', isCore: true },
  { key: 'products', name: 'Produtos' },
  { key: 'services', name: 'Serviços' },
  { key: 'opportunities', name: 'Oportunidades', isCore: true },
  { key: 'pipelines', name: 'Pipelines', isCore: true },
  { key: 'sales', name: 'Vendas' },
  { key: 'purchases', name: 'Compras' },
  { key: 'whatsapp', name: 'WhatsApp' },
  { key: 'email', name: 'E-mail' },
  { key: 'calendar', name: 'Agenda' },
  { key: 'tasks', name: 'Tarefas', isCore: true },
  { key: 'automation', name: 'Automação' },
  { key: 'bi', name: 'Relatórios & BI' },
  { key: 'ai', name: 'Inteligência Artificial' },
  { key: 'custom_objects', name: 'Objetos Personalizados' },
  { key: 'goals', name: 'Metas', isCore: true },
  { key: 'audit', name: 'Auditoria', isCore: true },
];

const PERMISSION_ACTIONS = ['view', 'create', 'edit', 'delete'];

const PLAN_MODULES: Record<string, string[]> = {
  starter: ['customers', 'prospects', 'contacts', 'pipelines', 'opportunities', 'tasks', 'calendar'],
  professional: [
    'customers', 'prospects', 'contacts', 'pipelines', 'opportunities', 'tasks', 'calendar',
    'whatsapp', 'email', 'automation', 'bi', 'sales', 'purchases', 'suppliers', 'products', 'services',
    'goals', 'audit',
  ],
  business: [
    'customers', 'prospects', 'contacts', 'pipelines', 'opportunities', 'tasks', 'calendar',
    'whatsapp', 'email', 'automation', 'bi', 'sales', 'purchases', 'suppliers', 'products', 'services',
    'ai', 'custom_objects', 'goals', 'audit',
  ],
  enterprise: MODULE_CATALOG.map((m) => m.key),
};

const FEATURE_FLAGS = [
  { key: 'whatsapp', description: 'Central de WhatsApp', defaultOn: false },
  { key: 'ai_copilot', description: 'Copiloto Comercial (IA)', defaultOn: false },
  { key: 'custom_objects', description: 'Dynamic Object Engine', defaultOn: false },
  { key: 'multi_branch', description: 'Múltiplas filiais', defaultOn: false },
  { key: 'api_access', description: 'API pública / API Keys', defaultOn: false },
  { key: 'white_label', description: 'White label', defaultOn: false },
];

// Template completo — Vertical Indústria (prompt-mestre, Parte I, seção 6)
const INDUSTRIA_TEMPLATE = {
  modules: PLAN_MODULES.business,
  menu: [
    'dashboard', 'customers', 'prospects', 'contacts', 'opportunities', 'products',
    'suppliers', 'purchases', 'sales', 'whatsapp', 'email', 'calendar', 'tasks', 'goals', 'audit', 'bi', 'ai', 'settings',
  ],
  pipeline: {
    name: 'Comercial Indústria',
    stages: [
      { name: 'Prospecção', probability: 5, color: '#94a3b8' },
      { name: 'Contato', probability: 15, color: '#60a5fa' },
      { name: 'Qualificação', probability: 30, color: '#38bdf8' },
      { name: 'Amostra/Teste', probability: 45, color: '#22d3ee' },
      { name: 'Proposta', probability: 60, color: '#a78bfa' },
      { name: 'Negociação', probability: 75, color: '#f59e0b' },
      { name: 'Pedido', probability: 90, color: '#fb923c' },
      { name: 'Cliente ativo', probability: 100, color: '#22c55e', isWon: true },
    ],
  },
  customFields: [
    { entityType: 'customer', key: 'territorio', label: 'Território', fieldType: 'text' },
    { entityType: 'customer', key: 'representante', label: 'Representante', fieldType: 'text' },
  ],
  dashboardKpis: ['faturamento', 'volume', 'margem', 'clientes_ativos', 'positivacao', 'mix', 'ticket', 'frequencia'],
  terminologies: { customer: 'Cliente B2B', prospect: 'Prospect Industrial' },
};

// Template completo — Vertical Oficina (prompt-mestre, Parte I, seção 14)
const OFICINA_TEMPLATE = {
  modules: ['customers', 'prospects', 'contacts', 'pipelines', 'opportunities', 'tasks', 'calendar', 'products', 'custom_objects', 'whatsapp', 'bi'],
  menu: ['dashboard', 'customers', 'custom_objects.veiculo', 'opportunities', 'products', 'calendar', 'tasks', 'whatsapp', 'bi', 'settings'],
  pipeline: {
    name: 'Ordens de Serviço',
    stages: [
      { name: 'Orçamento solicitado', probability: 10, color: '#94a3b8' },
      { name: 'Orçamento enviado', probability: 30, color: '#60a5fa' },
      { name: 'Aprovado', probability: 60, color: '#a78bfa' },
      { name: 'Em execução', probability: 80, color: '#f59e0b' },
      { name: 'Concluído', probability: 100, color: '#22c55e', isWon: true },
    ],
  },
  customObjects: [
    {
      key: 'veiculo',
      name: 'Veículo',
      fields: [
        { key: 'placa', label: 'Placa', fieldType: 'text', required: true },
        { key: 'modelo', label: 'Modelo', fieldType: 'text' },
        { key: 'marca', label: 'Marca', fieldType: 'text' },
        { key: 'ano', label: 'Ano', fieldType: 'number' },
        { key: 'quilometragem', label: 'Quilometragem', fieldType: 'number' },
      ],
    },
  ],
  dashboardKpis: ['ordens_abertas', 'ticket_medio_os', 'retorno', 'veiculos_ativos'],
  terminologies: { customer: 'Cliente', opportunity: 'Ordem de Serviço' },
};

async function main() {
  console.log('Seed: catálogo de módulos...');
  for (const m of MODULE_CATALOG) {
    await db.insert(schema.modules).values(m).onConflictDoNothing();
  }

  console.log('Seed: permissões...');
  for (const m of MODULE_CATALOG) {
    for (const action of PERMISSION_ACTIONS) {
      await db.insert(schema.permissions).values({ module: m.key, action }).onConflictDoNothing();
    }
  }

  console.log('Seed: planos...');
  const planRows = [
    { key: 'starter', name: 'Starter', order: 1 },
    { key: 'professional', name: 'Professional', order: 2 },
    { key: 'business', name: 'Business', order: 3 },
    { key: 'enterprise', name: 'Enterprise', order: 4 },
  ];
  for (const p of planRows) {
    await db.insert(schema.plans).values(p).onConflictDoNothing();
  }
  for (const [planKey, moduleKeys] of Object.entries(PLAN_MODULES)) {
    for (const moduleKey of moduleKeys) {
      await db.insert(schema.planModules).values({ planKey, moduleKey }).onConflictDoNothing();
    }
  }

  console.log('Seed: feature flags...');
  for (const f of FEATURE_FLAGS) {
    await db.insert(schema.featureFlags).values(f).onConflictDoNothing();
  }

  console.log('Seed: verticais + templates...');
  const verticalRows = [
    { key: 'industria', name: 'Indústria' },
    { key: 'distribuidora', name: 'Distribuidora' },
    { key: 'foodservice', name: 'Foodservice' },
    { key: 'varejo', name: 'Varejo' },
    { key: 'servicos', name: 'Serviços' },
    { key: 'representante', name: 'Representação Comercial' },
    { key: 'imobiliario', name: 'Imobiliário' },
    { key: 'autoescola', name: 'Autoescola' },
    { key: 'oficina', name: 'Oficina' },
    { key: 'agencia', name: 'Agência' },
    { key: 'personalizado', name: 'Personalizado', isCustom: true },
  ];
  const insertedVerticals: Record<string, string> = {};
  for (const v of verticalRows) {
    const [row] = await db
      .insert(schema.verticals)
      .values(v)
      .onConflictDoUpdate({ target: schema.verticals.key, set: { name: v.name } })
      .returning();
    insertedVerticals[v.key] = row.id;
  }

  await db.insert(schema.verticalTemplates).values({
    verticalId: insertedVerticals['industria'],
    config: INDUSTRIA_TEMPLATE,
  });
  await db.insert(schema.verticalTemplates).values({
    verticalId: insertedVerticals['oficina'],
    config: OFICINA_TEMPLATE,
  });
  console.log('  -> templates completos: industria, oficina (demais verticais com catálogo básico, template detalhado fica para próxima fase)');

  console.log('Seed: organização demo (Indústria)...');
  const [org] = await db
    .insert(schema.organizations)
    .values({
      name: 'Alvorecer Dourado Ltda (Demo)',
      tradeName: 'Alvorecer Dourado',
      document: '12.345.678/0001-90',
      segmentKey: 'industria',
      verticalId: insertedVerticals['industria'],
      primaryColor: '#4f46e5',
      status: 'active',
    })
    .returning();

  await db.insert(schema.subscriptions).values({ organizationId: org.id, planKey: 'business' });

  for (const moduleKey of INDUSTRIA_TEMPLATE.modules) {
    await db.insert(schema.organizationModules).values({ organizationId: org.id, moduleKey, enabled: true });
  }

  const [mainBranch] = await db
    .insert(schema.branches)
    .values({ organizationId: org.id, name: 'Matriz', isMain: true, city: 'São Paulo', state: 'SP' })
    .returning();

  console.log('Seed: roles + permissões...');
  const [adminRole] = await db
    .insert(schema.roles)
    .values({ organizationId: org.id, key: 'admin', name: 'Administrador', isSystem: true })
    .returning();
  const [sellerRole] = await db
    .insert(schema.roles)
    .values({ organizationId: org.id, key: 'vendedor', name: 'Vendedor', isSystem: true })
    .returning();

  const allPermissions = await db.select().from(schema.permissions);
  for (const perm of allPermissions) {
    await db.insert(schema.rolePermissions).values({ roleId: adminRole.id, permissionId: perm.id }).onConflictDoNothing();
  }
  const sellerModules = ['customers', 'prospects', 'contacts', 'opportunities', 'pipelines', 'tasks', 'products'];
  for (const perm of allPermissions) {
    if (sellerModules.includes(perm.module) && perm.action !== 'delete') {
      await db.insert(schema.rolePermissions).values({ roleId: sellerRole.id, permissionId: perm.id }).onConflictDoNothing();
    }
  }

  console.log('Seed: usuários...');
  const passwordHash = bcrypt.hashSync('Demo@123', 10);
  const [adminUser] = await db
    .insert(schema.users)
    .values({ name: 'Giovani Módena', email: 'admin@alvorecerdourado.com.br', passwordHash })
    .returning();
  const [sellerUser] = await db
    .insert(schema.users)
    .values({ name: 'Ana Vendedora', email: 'ana@alvorecerdourado.com.br', passwordHash })
    .returning();

  await db.insert(schema.memberships).values({
    userId: adminUser.id, organizationId: org.id, roleId: adminRole.id, branchId: mainBranch.id, isOwner: true,
  });
  await db.insert(schema.memberships).values({
    userId: sellerUser.id, organizationId: org.id, roleId: sellerRole.id, branchId: mainBranch.id, isOwner: false,
  });

  console.log('Seed: pipeline comercial...');
  const [pipeline] = await db
    .insert(schema.pipelines)
    .values({ organizationId: org.id, name: INDUSTRIA_TEMPLATE.pipeline.name, type: 'sales', isDefault: true })
    .returning();
  const stageRows: (typeof schema.pipelineStages.$inferSelect)[] = [];
  let order = 0;
  for (const s of INDUSTRIA_TEMPLATE.pipeline.stages) {
    const [row] = await db
      .insert(schema.pipelineStages)
      .values({
        pipelineId: pipeline.id,
        name: s.name,
        order: order++,
        color: s.color,
        probability: s.probability,
        isWon: !!(s as any).isWon,
      })
      .returning();
    stageRows.push(row);
  }

  console.log('Seed: fornecedores, produtos...');
  const [supplier1] = await db.insert(schema.suppliers).values({
    organizationId: org.id, companyName: 'Embalagens São Paulo Ltda', segment: 'Embalagens',
    city: 'Guarulhos', state: 'SP', phone: '(11) 4002-8922', whatsapp: '5511940028922', email: 'contato@embalagenssp.com.br',
    rating: 4, status: 'active',
  }).returning();
  await db.insert(schema.suppliers).values({
    organizationId: org.id, companyName: 'Matéria-Prima Nordeste S.A.', segment: 'Insumos',
    city: 'Recife', state: 'PE', phone: '(81) 3222-1010', whatsapp: '5581932221010', email: 'vendas@materiaprimanordeste.com.br', rating: 5, status: 'active',
  });

  const productNames = [
    { name: 'Molho de Tomate Premium 2kg', sku: 'MT-2KG', price: 18.9, cost: 11.2 },
    { name: 'Azeite Extra Virgem 500ml', sku: 'AZ-500', price: 32.5, cost: 19.0 },
    { name: 'Farinha Especial 25kg', sku: 'FE-25KG', price: 89.9, cost: 61.0 },
    { name: 'Conserva de Palmito 1kg', sku: 'CP-1KG', price: 24.7, cost: 14.5 },
    { name: 'Óleo de Soja 900ml (caixa 20un)', sku: 'OS-900-CX20', price: 145.0, cost: 98.0 },
  ];
  const products: (typeof schema.products.$inferSelect)[] = [];
  for (const p of productNames) {
    const [row] = await db.insert(schema.products).values({
      organizationId: org.id, name: p.name, sku: p.sku, price: String(p.price), cost: String(p.cost),
      unit: 'UN', stock: '500', minStock: '50', supplierId: supplier1.id, status: 'active',
    }).returning();
    products.push(row);
  }

  console.log('Seed: prospects...');
  const prospectData = [
    { companyName: 'Distribuidora Boa Mesa', city: 'Campinas', state: 'SP', potential: 'alto', origin: 'indicacao' },
    { companyName: 'Rede Supermix Atacado', city: 'Belo Horizonte', state: 'MG', potential: 'alto', origin: 'feira' },
    { companyName: 'Empório Sabor & Cia', city: 'Curitiba', state: 'PR', potential: 'medio', origin: 'site' },
    { companyName: 'Atacadão Litoral Norte', city: 'Santos', state: 'SP', potential: 'medio', origin: 'indicacao' },
    { companyName: 'Foodservice Brasil Distrib.', city: 'Rio de Janeiro', state: 'RJ', potential: 'alto', origin: 'linkedin' },
    { companyName: 'Mercadinho Central', city: 'Sorocaba', state: 'SP', potential: 'baixo', origin: 'whatsapp' },
  ];
  const prospects: (typeof schema.prospects.$inferSelect)[] = [];
  for (const p of prospectData) {
    const [row] = await db.insert(schema.prospects).values({
      organizationId: org.id, companyName: p.companyName, city: p.city, state: p.state,
      potential: p.potential, origin: p.origin, ownerId: sellerUser.id, segment: 'industria', status: 'open',
      score: Math.floor(Math.random() * 100),
    }).returning();
    prospects.push(row);
  }

  console.log('Seed: clientes...');
  const customerData = [
    { companyName: 'Rede Mineira de Supermercados', city: 'Belo Horizonte', state: 'MG', abcClassification: 'A', phone: '(31) 3222-4400', whatsapp: '5531932224400', email: 'compras@redemineira.com.br' },
    { companyName: 'Distribuidora Sul Alimentos', city: 'Porto Alegre', state: 'RS', abcClassification: 'A', phone: '(51) 3311-7788', whatsapp: '5551933117788', email: 'contato@distribuidorasul.com.br' },
    { companyName: 'Comercial Paulista de Alimentos', city: 'São Paulo', state: 'SP', abcClassification: 'B', phone: '(11) 3555-9021', whatsapp: '5511935559021', email: 'financeiro@comercialpaulista.com.br' },
    { companyName: 'Atacado Nordeste Ltda', city: 'Salvador', state: 'BA', abcClassification: 'C', phone: '(71) 3244-5566', whatsapp: '5571932445566', email: 'atendimento@atacadonordeste.com.br' },
  ];
  const customers: (typeof schema.customers.$inferSelect)[] = [];
  for (const c of customerData) {
    const [row] = await db.insert(schema.customers).values({
      organizationId: org.id, companyName: c.companyName, city: c.city, state: c.state,
      abcClassification: c.abcClassification, ownerId: sellerUser.id, status: 'active',
      phone: c.phone, whatsapp: c.whatsapp, email: c.email,
      ticketAverage: String((Math.random() * 5000 + 1000).toFixed(2)),
      lastPurchaseAt: new Date(Date.now() - Math.floor(Math.random() * 40) * 24 * 3600 * 1000),
    }).returning();
    customers.push(row);
  }

  console.log('Seed: contatos...');
  await db.insert(schema.contacts).values({
    organizationId: org.id, name: 'Carlos Menezes', jobTitle: 'Comprador', isPrimary: true,
    email: 'carlos@redemineira.com.br', phone: '(31) 99888-1122', customerId: customers[0].id,
  });
  await db.insert(schema.contacts).values({
    organizationId: org.id, name: 'Fernanda Lima', jobTitle: 'Gerente de Compras', isPrimary: true,
    email: 'fernanda@boamesa.com.br', phone: '(19) 99777-3344', prospectId: prospects[0].id,
  });

  console.log('Seed: oportunidades...');
  const oppData = [
    { title: 'Rede Mineira — reposição trimestral', stageIdx: 6, value: 42000, customerId: customers[0].id },
    { title: 'Distribuidora Sul — novo contrato anual', stageIdx: 5, value: 96000, customerId: customers[1].id },
    { title: 'Boa Mesa — proposta inicial', stageIdx: 4, value: 18000, prospectId: prospects[0].id },
    { title: 'Supermix Atacado — amostragem linha completa', stageIdx: 3, value: 25000, prospectId: prospects[1].id },
    { title: 'Empório Sabor — primeiro contato', stageIdx: 1, value: 6000, prospectId: prospects[2].id },
    { title: 'Foodservice Brasil — qualificação', stageIdx: 2, value: 31000, prospectId: prospects[4].id },
  ];
  const opportunities: (typeof schema.opportunities.$inferSelect)[] = [];
  for (const o of oppData) {
    const stage = stageRows[o.stageIdx];
    const [row] = await db.insert(schema.opportunities).values({
      organizationId: org.id, title: o.title, pipelineId: pipeline.id, stageId: stage.id,
      customerId: (o as any).customerId ?? null, prospectId: (o as any).prospectId ?? null,
      ownerId: sellerUser.id, value: String(o.value), probability: stage.probability,
      status: stage.isWon ? 'won' : 'open',
    }).returning();
    opportunities.push(row);
    await db.insert(schema.opportunityStageHistory).values({ opportunityId: row.id, toStageId: stage.id, changedById: sellerUser.id });
    await db.insert(schema.opportunityItems).values({
      opportunityId: row.id, productId: products[Math.floor(Math.random() * products.length)].id,
      quantity: String(Math.floor(Math.random() * 100) + 10), unitPrice: String((o.value / 50).toFixed(2)),
    });
  }

  console.log('Seed: tarefas...');
  await db.insert(schema.activityTasks).values([
    {
      organizationId: org.id, type: 'followup', title: 'Follow-up proposta Boa Mesa', priority: 'high',
      status: 'pending', assigneeId: sellerUser.id, prospectId: prospects[0].id, opportunityId: opportunities[2].id,
      dueAt: new Date(Date.now() + 1 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'call', title: 'Ligar para Supermix Atacado', priority: 'normal',
      status: 'pending', assigneeId: sellerUser.id, prospectId: prospects[1].id,
      dueAt: new Date(Date.now() + 2 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'visit', title: 'Visita técnica — Rede Mineira', priority: 'normal',
      status: 'pending', assigneeId: sellerUser.id, customerId: customers[0].id,
      dueAt: new Date(Date.now() + 5 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'whatsapp', title: 'Enviar catálogo — Empório Sabor', priority: 'low',
      status: 'overdue', assigneeId: sellerUser.id, prospectId: prospects[2].id,
      dueAt: new Date(Date.now() - 2 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'internal', title: 'Atualizar tabela de preços Q4', priority: 'normal',
      status: 'pending', assigneeId: adminUser.id, dueAt: new Date(Date.now() + 7 * 24 * 3600 * 1000),
    },
  ]);

  console.log('Seed: histórico de comunicação (ligações, WhatsApp, e-mails)...');
  await db.insert(schema.activityTasks).values([
    {
      organizationId: org.id, type: 'call', title: `Ligação com ${customers[0].companyName}`, priority: 'normal',
      status: 'done', assigneeId: sellerUser.id, customerId: customers[0].id, direction: 'outbound', durationMinutes: 14,
      description: 'Alinhamento sobre a reposição trimestral e prazos de entrega.',
      completedAt: new Date(Date.now() - 6 * 24 * 3600 * 1000), createdAt: new Date(Date.now() - 6 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'whatsapp', title: `WhatsApp com ${customers[0].companyName}`, priority: 'normal',
      status: 'done', assigneeId: sellerUser.id, customerId: customers[0].id, direction: 'inbound',
      description: 'Cliente confirmou recebimento da última entrega e pediu novo orçamento.',
      completedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000), createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'meeting', title: `Reunião com ${customers[0].companyName}`, priority: 'normal',
      status: 'pending', assigneeId: sellerUser.id, customerId: customers[0].id,
      description: 'Revisão trimestral de contrato e volumes.',
      dueAt: new Date(Date.now() + 4 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'email', title: `E-mail para ${customers[1].companyName}`, priority: 'normal',
      status: 'done', assigneeId: sellerUser.id, customerId: customers[1].id, direction: 'outbound',
      description: 'Envio da proposta comercial do novo contrato anual.',
      completedAt: new Date(Date.now() - 2 * 24 * 3600 * 1000), createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000),
    },
    {
      organizationId: org.id, type: 'call', title: `Ligação com ${supplier1.companyName}`, priority: 'normal',
      status: 'done', assigneeId: adminUser.id, supplierId: supplier1.id, direction: 'outbound', durationMinutes: 8,
      description: 'Negociação de prazo de entrega das embalagens.',
      completedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000), createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000),
    },
  ]);

  console.log('Seed: automação de exemplo (Workflow Builder)...');
  await db.insert(schema.automations).values({
    organizationId: org.id,
    name: 'Boas-vindas a novo cliente',
    triggerEvent: 'customer.created',
    conditions: [],
    actions: [{ type: 'create_task', params: { title: 'Ligar de boas-vindas para o novo cliente', type: 'call', priority: 'high', dueInDays: 1 } }],
    enabled: true,
  });

  console.log('Seed: vendas (orçamentos + pedidos)...');
  // Orçamento 1 -> convertido em pedido concluído (fecha o fluxo completo:
  // Oportunidade -> Orçamento -> Pedido -> Venda, seção 11 do prompt-mestre).
  const quote1Items = [
    { productId: products[0].id, quantity: '40', unitPrice: String(products[0].price ?? 0) },
    { productId: products[1].id, quantity: '20', unitPrice: String(products[1].price ?? 0) },
  ];
  const quote1Subtotal = quote1Items.reduce((acc, i) => acc + Number(i.quantity) * Number(i.unitPrice), 0);
  const [order1] = await db.insert(schema.salesOrders).values({
    organizationId: org.id, number: 1, customerId: customers[0].id, sellerId: sellerUser.id,
    status: 'completed', subtotal: String(quote1Subtotal), totalValue: String(quote1Subtotal),
    completedAt: new Date(Date.now() - 5 * 24 * 3600 * 1000), paymentTerms: '30/60 dias',
  }).returning();
  await db.insert(schema.salesOrderItems).values(quote1Items.map((i) => ({ salesOrderId: order1.id, ...i })));
  const [quote1] = await db.insert(schema.quotes).values({
    organizationId: org.id, number: 1, customerId: customers[0].id, sellerId: sellerUser.id,
    status: 'converted', convertedToOrderId: order1.id, subtotal: String(quote1Subtotal), totalValue: String(quote1Subtotal),
    paymentTerms: '30/60 dias', createdAt: new Date(Date.now() - 8 * 24 * 3600 * 1000),
  }).returning();
  await db.insert(schema.quoteItems).values(quote1Items.map((i) => ({ quoteId: quote1.id, ...i })));
  await db.update(schema.customers).set({
    lastPurchaseAt: order1.completedAt, firstPurchaseAt: order1.completedAt,
    ticketAverage: String(quote1Subtotal.toFixed(2)), ltv: String(quote1Subtotal.toFixed(2)),
  }).where(eq(schema.customers.id, customers[0].id));

  // Orçamento 2 -> ainda em aberto (aguardando aprovação do cliente).
  const quote2Items = [{ productId: products[2].id, quantity: '10', unitPrice: String(products[2].price ?? 0) }];
  const quote2Subtotal = quote2Items.reduce((acc, i) => acc + Number(i.quantity) * Number(i.unitPrice), 0);
  const [quote2] = await db.insert(schema.quotes).values({
    organizationId: org.id, number: 2, customerId: customers[1].id, sellerId: sellerUser.id,
    status: 'sent', subtotal: String(quote2Subtotal), totalValue: String(quote2Subtotal),
    validUntil: new Date(Date.now() + 10 * 24 * 3600 * 1000),
  }).returning();
  await db.insert(schema.quoteItems).values(quote2Items.map((i) => ({ quoteId: quote2.id, ...i })));

  // Pedido 2 -> confirmado, ainda não faturado.
  const order2Items = [{ productId: products[3].id, quantity: '15', unitPrice: String(products[3].price ?? 0) }];
  const order2Subtotal = order2Items.reduce((acc, i) => acc + Number(i.quantity) * Number(i.unitPrice), 0);
  const [order2] = await db.insert(schema.salesOrders).values({
    organizationId: org.id, number: 2, customerId: customers[2].id, sellerId: sellerUser.id,
    status: 'confirmed', subtotal: String(order2Subtotal), totalValue: String(order2Subtotal),
  }).returning();
  await db.insert(schema.salesOrderItems).values(order2Items.map((i) => ({ salesOrderId: order2.id, ...i })));

  console.log('Seed: compras (solicitações + pedidos + recebimento)...');
  const supplier2 = (await db.select().from(schema.suppliers).where(eq(schema.suppliers.organizationId, org.id)))[1];

  const request1Items = [{ productId: products[0].id, quantity: '200' }, { productId: products[4].id, quantity: '50' }];
  const [request1] = await db.insert(schema.purchaseRequests).values({
    organizationId: org.id, number: 1, title: 'Reposição de estoque — linha molhos e óleos', requesterId: adminUser.id, status: 'ordered',
  }).returning();
  await db.insert(schema.purchaseRequestItems).values(request1Items.map((i) => ({ purchaseRequestId: request1.id, ...i })));

  const po1Items = request1Items.map((i, idx) => ({ productId: i.productId, quantity: i.quantity, unitCost: String(Number(products.find((p) => p.id === i.productId)?.cost ?? 10)) }));
  const po1Subtotal = po1Items.reduce((acc, i) => acc + Number(i.quantity) * Number(i.unitCost), 0);
  const [po1] = await db.insert(schema.purchaseOrders).values({
    organizationId: org.id, number: 1, purchaseRequestId: request1.id, supplierId: supplier1.id, buyerId: adminUser.id,
    status: 'received', subtotal: String(po1Subtotal), totalValue: String(po1Subtotal), receivedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000),
  }).returning();
  await db.insert(schema.purchaseOrderItems).values(po1Items.map((i) => ({ purchaseOrderId: po1.id, ...i, receivedQuantity: i.quantity })));
  for (const i of po1Items) {
    await db.update(schema.products).set({ stock: sql`${schema.products.stock} + ${Number(i.quantity)}` }).where(eq(schema.products.id, i.productId!));
  }

  const [request2] = await db.insert(schema.purchaseRequests).values({
    organizationId: org.id, number: 2, title: 'Nova linha — conservas para o próximo trimestre', requesterId: adminUser.id, status: 'open',
  }).returning();
  await db.insert(schema.purchaseRequestItems).values({ purchaseRequestId: request2.id, productId: products[3].id, quantity: '100' });

  const po2Cost = String(Number(products[2].cost));
  const [po2] = await db.insert(schema.purchaseOrders).values({
    organizationId: org.id, number: 2, supplierId: supplier2.id, buyerId: adminUser.id,
    status: 'pending', subtotal: String(30 * Number(po2Cost)), totalValue: String(30 * Number(po2Cost)),
    expectedAt: new Date(Date.now() + 7 * 24 * 3600 * 1000),
  }).returning();
  await db.insert(schema.purchaseOrderItems).values({ purchaseOrderId: po2.id, productId: products[2].id, quantity: '30', unitCost: po2Cost });

  console.log('Seed: metas comerciais...');
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const monthEnd = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
  await db.insert(schema.goals).values([
    { organizationId: org.id, scopeType: 'organization', metric: 'revenue', targetValue: '150000', periodStart: monthStart, periodEnd: monthEnd },
    { organizationId: org.id, scopeType: 'user', scopeId: sellerUser.id, metric: 'revenue', targetValue: '60000', periodStart: monthStart, periodEnd: monthEnd },
    { organizationId: org.id, scopeType: 'user', scopeId: sellerUser.id, metric: 'opportunities_won', targetValue: '8', periodStart: monthStart, periodEnd: monthEnd },
  ]);

  console.log('Seed: notificações...');
  await db.insert(schema.notifications).values([
    { organizationId: org.id, userId: sellerUser.id, type: 'sale', title: 'Venda #1 concluída', body: 'Rede Mineira de Supermercados — pedido faturado.', entityType: 'sales_order', entityId: order1.id, read: false },
    { organizationId: org.id, userId: sellerUser.id, type: 'task', title: 'Tarefa atrasada', body: 'Enviar catálogo — Empório Sabor', read: false },
    { organizationId: org.id, userId: adminUser.id, type: 'purchase', title: 'Pedido de compra #1 recebido', body: 'Estoque atualizado automaticamente.', entityType: 'purchase_order', entityId: po1.id, read: true },
  ]);

  console.log('\nSeed concluído.');
  console.log('Organização demo:', org.name, `(id: ${org.id})`);
  console.log('Login admin -> admin@alvorecerdourado.com.br / Demo@123');
  console.log('Login vendedor -> ana@alvorecerdourado.com.br / Demo@123');

  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
