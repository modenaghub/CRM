import { IsIn, IsOptional, IsString } from 'class-validator';

export class UpdatePurchaseOrderDto {
  @IsOptional()
  @IsIn(['pending', 'sent', 'confirmed', 'cancelled'])
  status?: string;

  @IsOptional() @IsString() notes?: string;
}
