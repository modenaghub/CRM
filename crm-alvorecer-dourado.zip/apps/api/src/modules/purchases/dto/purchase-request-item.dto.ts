import { IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class PurchaseRequestItemDto {
  @IsOptional() @IsString() productId?: string;
  @IsOptional() @IsString() description?: string;
  @IsNumber() @Min(0.001) quantity!: number;
}
