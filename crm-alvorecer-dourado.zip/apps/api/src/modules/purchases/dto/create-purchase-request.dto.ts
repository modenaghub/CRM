import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsOptional, IsString, ValidateNested } from 'class-validator';
import { PurchaseRequestItemDto } from './purchase-request-item.dto';

// Necessidade de compra (prompt-mestre, seção 12: Necessidade → Cotação →
// Fornecedor → Pedido de compra → Recebimento).
export class CreatePurchaseRequestDto {
  @IsString() title!: string;
  @IsOptional() @IsString() notes?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => PurchaseRequestItemDto)
  items!: PurchaseRequestItemDto[];
}
