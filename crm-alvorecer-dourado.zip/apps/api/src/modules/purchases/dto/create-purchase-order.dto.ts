import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsDateString, IsOptional, IsString, ValidateNested } from 'class-validator';
import { IsNumber, Min } from 'class-validator';

class PurchaseOrderItemDto {
  @IsOptional() @IsString() productId?: string;
  @IsOptional() @IsString() description?: string;
  @IsNumber() @Min(0.001) quantity!: number;
  @IsNumber() @Min(0) unitCost!: number;
}

// Pedido de compra (prompt-mestre, seção 12) — pode ser gerado a partir de uma
// solicitação (purchaseRequestId) ou criado diretamente com um fornecedor.
export class CreatePurchaseOrderDto {
  @IsString() supplierId!: string;
  @IsOptional() @IsString() purchaseRequestId?: string;
  @IsOptional() @IsDateString() expectedAt?: string;
  @IsOptional() @IsString() notes?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => PurchaseOrderItemDto)
  items!: PurchaseOrderItemDto[];
}
