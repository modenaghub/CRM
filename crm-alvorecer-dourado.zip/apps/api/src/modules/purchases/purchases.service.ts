import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { and, desc, eq, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';
import { AuditService } from '../audit/audit.service';
import { CreatePurchaseRequestDto } from './dto/create-purchase-request.dto';
import { CreatePurchaseOrderDto } from './dto/create-purchase-order.dto';
import { UpdatePurchaseOrderDto } from './dto/update-purchase-order.dto';

// Módulo de Compras (prompt-mestre, seção 12): Necessidade → Cotação →
// Fornecedor → Pedido de compra → Recebimento → Histórico.
@Injectable()
export class PurchasesService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly events: EventEmitter2,
    private readonly audit: AuditService,
  ) {}

  // ------------------------------------------------------------ REQUESTS

  async listRequests(orgId: string, status?: string) {
    const conditions = [eq(schema.purchaseRequests.organizationId, orgId)];
    if (status) conditions.push(eq(schema.purchaseRequests.status, status));
    return this.db.select().from(schema.purchaseRequests).where(and(...conditions)).orderBy(desc(schema.purchaseRequests.createdAt));
  }

  async findRequest(orgId: string, id: string) {
    const request = await this.getOwnedRequest(orgId, id);
    const items = await this.db.select().from(schema.purchaseRequestItems).where(eq(schema.purchaseRequestItems.purchaseRequestId, id));
    return { ...request, items };
  }

  async createRequest(orgId: string, dto: CreatePurchaseRequestDto, userId: string) {
    const [{ nextNumber }] = await this.db
      .select({ nextNumber: sql<number>`coalesce(max(${schema.purchaseRequests.number}), 0) + 1` })
      .from(schema.purchaseRequests)
      .where(eq(schema.purchaseRequests.organizationId, orgId));

    const [request] = await this.db
      .insert(schema.purchaseRequests)
      .values({ organizationId: orgId, number: Number(nextNumber), title: dto.title, notes: dto.notes, requesterId: userId })
      .returning();

    await this.db.insert(schema.purchaseRequestItems).values(
      dto.items.map((i) => ({ purchaseRequestId: request.id, productId: i.productId, description: i.description, quantity: String(i.quantity) })),
    );

    await this.audit.log({ organizationId: orgId, userId, action: 'create', entityType: 'purchase_request', entityId: request.id, after: request });
    return this.findRequest(orgId, request.id);
  }

  // ------------------------------------------------------------- ORDERS

  async listOrders(orgId: string, supplierId?: string, status?: string) {
    const conditions = [eq(schema.purchaseOrders.organizationId, orgId)];
    if (supplierId) conditions.push(eq(schema.purchaseOrders.supplierId, supplierId));
    if (status) conditions.push(eq(schema.purchaseOrders.status, status));
    return this.db.select().from(schema.purchaseOrders).where(and(...conditions)).orderBy(desc(schema.purchaseOrders.createdAt));
  }

  async findOrder(orgId: string, id: string) {
    const order = await this.getOwnedOrder(orgId, id);
    const items = await this.db.select().from(schema.purchaseOrderItems).where(eq(schema.purchaseOrderItems.purchaseOrderId, id));
    return { ...order, items };
  }

  // Gera o Pedido de Compra escolhendo o fornecedor (comparação de
  // fornecedores fica a cargo do comprador na tela; seção 12).
  async createOrder(orgId: string, dto: CreatePurchaseOrderDto, userId: string) {
    const supplier = await this.db.query.suppliers.findFirst({ where: and(eq(schema.suppliers.id, dto.supplierId), eq(schema.suppliers.organizationId, orgId)) });
    if (!supplier) throw new NotFoundException('Fornecedor não encontrado.');

    const subtotal = dto.items.reduce((acc, i) => acc + i.quantity * i.unitCost, 0);
    const [{ nextNumber }] = await this.db
      .select({ nextNumber: sql<number>`coalesce(max(${schema.purchaseOrders.number}), 0) + 1` })
      .from(schema.purchaseOrders)
      .where(eq(schema.purchaseOrders.organizationId, orgId));

    const [order] = await this.db
      .insert(schema.purchaseOrders)
      .values({
        organizationId: orgId,
        number: Number(nextNumber),
        purchaseRequestId: dto.purchaseRequestId,
        supplierId: dto.supplierId,
        buyerId: userId,
        expectedAt: dto.expectedAt ? new Date(dto.expectedAt) : undefined,
        notes: dto.notes,
        subtotal: String(subtotal),
        totalValue: String(subtotal),
        status: 'pending',
      })
      .returning();

    await this.db.insert(schema.purchaseOrderItems).values(
      dto.items.map((i) => ({
        purchaseOrderId: order.id,
        productId: i.productId,
        description: i.description,
        quantity: String(i.quantity),
        unitCost: String(i.unitCost),
      })),
    );

    if (dto.purchaseRequestId) {
      await this.db.update(schema.purchaseRequests).set({ status: 'ordered', updatedAt: new Date() }).where(eq(schema.purchaseRequests.id, dto.purchaseRequestId));
    }

    this.events.emit('purchase_order.created', order);
    await this.audit.log({ organizationId: orgId, userId, action: 'create', entityType: 'purchase_order', entityId: order.id, after: order });
    return this.findOrder(orgId, order.id);
  }

  async updateOrder(orgId: string, id: string, dto: UpdatePurchaseOrderDto, userId: string) {
    const existing = await this.getOwnedOrder(orgId, id);
    const [row] = await this.db.update(schema.purchaseOrders).set({ ...dto, updatedAt: new Date() }).where(eq(schema.purchaseOrders.id, id)).returning();
    await this.audit.log({ organizationId: orgId, userId, action: 'update', entityType: 'purchase_order', entityId: id, before: { status: existing.status }, after: { status: row.status } });
    return row;
  }

  // Recebimento (prompt-mestre, seção 12) — dá entrada no estoque real dos
  // produtos e fecha o histórico de compras do fornecedor.
  async receiveOrder(orgId: string, id: string, userId: string) {
    const order = await this.findOrder(orgId, id);
    if (order.status === 'received') throw new NotFoundException('Este pedido já foi recebido.');

    for (const item of order.items) {
      if (!item.productId) continue;
      await this.db
        .update(schema.products)
        .set({ stock: sql`${schema.products.stock} + ${Number(item.quantity)}`, updatedAt: new Date() })
        .where(eq(schema.products.id, item.productId));
      await this.db.update(schema.purchaseOrderItems).set({ receivedQuantity: item.quantity }).where(eq(schema.purchaseOrderItems.id, item.id));
    }

    const [row] = await this.db
      .update(schema.purchaseOrders)
      .set({ status: 'received', receivedAt: new Date(), updatedAt: new Date() })
      .where(eq(schema.purchaseOrders.id, id))
      .returning();

    this.events.emit('purchase_order.received', row);
    await this.audit.log({ organizationId: orgId, userId, action: 'receive', entityType: 'purchase_order', entityId: id, after: { status: 'received' } });
    return this.findOrder(orgId, id);
  }

  private async getOwnedRequest(orgId: string, id: string) {
    const existing = await this.db.query.purchaseRequests.findFirst({ where: and(eq(schema.purchaseRequests.id, id), eq(schema.purchaseRequests.organizationId, orgId)) });
    if (!existing) throw new NotFoundException('Solicitação de compra não encontrada.');
    return existing;
  }

  private async getOwnedOrder(orgId: string, id: string) {
    const existing = await this.db.query.purchaseOrders.findFirst({ where: and(eq(schema.purchaseOrders.id, id), eq(schema.purchaseOrders.organizationId, orgId)) });
    if (!existing) throw new NotFoundException('Pedido de compra não encontrado.');
    return existing;
  }
}
