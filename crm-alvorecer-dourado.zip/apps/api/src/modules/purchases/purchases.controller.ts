import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { CurrentOrg, CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { PurchasesService } from './purchases.service';
import { CreatePurchaseRequestDto } from './dto/create-purchase-request.dto';
import { CreatePurchaseOrderDto } from './dto/create-purchase-order.dto';
import { UpdatePurchaseOrderDto } from './dto/update-purchase-order.dto';

@Controller()
export class PurchasesController {
  constructor(private readonly purchasesService: PurchasesService) {}

  // ---- Solicitações (necessidade de compra) ----
  @Get('purchase-requests')
  @RequirePermission('purchases', 'view')
  listRequests(@CurrentOrg() orgId: string, @Query('status') status?: string) {
    return this.purchasesService.listRequests(orgId, status);
  }

  @Get('purchase-requests/:id')
  @RequirePermission('purchases', 'view')
  findRequest(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.purchasesService.findRequest(orgId, id);
  }

  @Post('purchase-requests')
  @RequirePermission('purchases', 'create')
  createRequest(@CurrentOrg() orgId: string, @Body() dto: CreatePurchaseRequestDto, @CurrentUser() user: AuthUser) {
    return this.purchasesService.createRequest(orgId, dto, user.sub);
  }

  // ---- Pedidos de compra ----
  @Get('purchase-orders')
  @RequirePermission('purchases', 'view')
  listOrders(@CurrentOrg() orgId: string, @Query('supplierId') supplierId?: string, @Query('status') status?: string) {
    return this.purchasesService.listOrders(orgId, supplierId, status);
  }

  @Get('purchase-orders/:id')
  @RequirePermission('purchases', 'view')
  findOrder(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.purchasesService.findOrder(orgId, id);
  }

  @Post('purchase-orders')
  @RequirePermission('purchases', 'create')
  createOrder(@CurrentOrg() orgId: string, @Body() dto: CreatePurchaseOrderDto, @CurrentUser() user: AuthUser) {
    return this.purchasesService.createOrder(orgId, dto, user.sub);
  }

  @Patch('purchase-orders/:id')
  @RequirePermission('purchases', 'edit')
  updateOrder(@CurrentOrg() orgId: string, @Param('id') id: string, @Body() dto: UpdatePurchaseOrderDto, @CurrentUser() user: AuthUser) {
    return this.purchasesService.updateOrder(orgId, id, dto, user.sub);
  }

  @Post('purchase-orders/:id/receive')
  @RequirePermission('purchases', 'edit')
  receiveOrder(@CurrentOrg() orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.purchasesService.receiveOrder(orgId, id, user.sub);
  }
}
