import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { CurrentOrg } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { GoalsService } from './goals.service';
import { CreateGoalDto } from './dto/create-goal.dto';

@Controller('goals')
export class GoalsController {
  constructor(private readonly goalsService: GoalsService) {}

  @Get()
  @RequirePermission('goals', 'view')
  list(@CurrentOrg() orgId: string) {
    return this.goalsService.list(orgId);
  }

  @Post()
  @RequirePermission('goals', 'create')
  create(@CurrentOrg() orgId: string, @Body() dto: CreateGoalDto) {
    return this.goalsService.create(orgId, dto);
  }

  @Delete(':id')
  @RequirePermission('goals', 'delete')
  remove(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.goalsService.remove(orgId, id);
  }
}
