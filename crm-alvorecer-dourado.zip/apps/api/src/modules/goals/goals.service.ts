import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { and, count, eq, gte, lte, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';
import { CreateGoalDto } from './dto/create-goal.dto';

// Metas e gestão comercial (prompt-mestre, seção 19): meta x realizado,
// calculado em tempo real a partir dos dados reais do módulo de Vendas/CRM.
@Injectable()
export class GoalsService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async list(orgId: string) {
    const goals = await this.db.select().from(schema.goals).where(eq(schema.goals.organizationId, orgId));
    return Promise.all(goals.map((g) => this.withProgress(orgId, g)));
  }

  async create(orgId: string, dto: CreateGoalDto) {
    const [row] = await this.db
      .insert(schema.goals)
      .values({
        organizationId: orgId,
        scopeType: dto.scopeType,
        scopeId: dto.scopeId,
        metric: dto.metric,
        targetValue: String(dto.targetValue),
        periodStart: new Date(dto.periodStart),
        periodEnd: new Date(dto.periodEnd),
      })
      .returning();
    return this.withProgress(orgId, row);
  }

  async remove(orgId: string, id: string) {
    const existing = await this.db.query.goals.findFirst({ where: and(eq(schema.goals.id, id), eq(schema.goals.organizationId, orgId)) });
    if (!existing) throw new NotFoundException('Meta não encontrada.');
    await this.db.delete(schema.goals).where(eq(schema.goals.id, id));
    return { success: true };
  }

  private async withProgress(orgId: string, goal: typeof schema.goals.$inferSelect) {
    let achieved = 0;

    if (goal.metric === 'revenue') {
      const conditions = [
        eq(schema.salesOrders.organizationId, orgId),
        eq(schema.salesOrders.status, 'completed'),
        gte(schema.salesOrders.completedAt, goal.periodStart),
        lte(schema.salesOrders.completedAt, goal.periodEnd),
      ];
      if (goal.scopeType === 'user' && goal.scopeId) conditions.push(eq(schema.salesOrders.sellerId, goal.scopeId));
      const [row] = await this.db
        .select({ total: sql<string>`coalesce(sum(${schema.salesOrders.totalValue}), 0)` })
        .from(schema.salesOrders)
        .where(and(...conditions));
      achieved = Number(row.total);
    } else if (goal.metric === 'new_customers') {
      const conditions = [
        eq(schema.customers.organizationId, orgId),
        gte(schema.customers.createdAt, goal.periodStart),
        lte(schema.customers.createdAt, goal.periodEnd),
      ];
      if (goal.scopeType === 'user' && goal.scopeId) conditions.push(eq(schema.customers.ownerId, goal.scopeId));
      const [row] = await this.db.select({ value: count() }).from(schema.customers).where(and(...conditions));
      achieved = Number(row.value);
    } else if (goal.metric === 'opportunities_won') {
      const conditions = [
        eq(schema.opportunities.organizationId, orgId),
        eq(schema.opportunities.status, 'won'),
        gte(schema.opportunities.stageChangedAt, goal.periodStart),
        lte(schema.opportunities.stageChangedAt, goal.periodEnd),
      ];
      if (goal.scopeType === 'user' && goal.scopeId) conditions.push(eq(schema.opportunities.ownerId, goal.scopeId));
      const [row] = await this.db.select({ value: count() }).from(schema.opportunities).where(and(...conditions));
      achieved = Number(row.value);
    }

    const target = Number(goal.targetValue);
    const percent = target > 0 ? Math.min(999, Math.round((achieved / target) * 100)) : 0;
    return { ...goal, achievedValue: String(achieved.toFixed(2)), progressPercent: percent };
  }
}
