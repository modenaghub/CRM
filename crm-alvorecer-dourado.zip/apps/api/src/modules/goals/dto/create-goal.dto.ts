import { IsDateString, IsIn, IsNumber, IsOptional, IsString, Min } from 'class-validator';

// Metas (prompt-mestre, seção 19): por empresa/filial/equipe/vendedor/produto...
export class CreateGoalDto {
  @IsIn(['organization', 'team', 'user'])
  scopeType!: string;

  @IsOptional() @IsString() scopeId?: string;

  @IsIn(['revenue', 'new_customers', 'opportunities_won'])
  metric!: string;

  @IsNumber() @Min(0) targetValue!: number;

  @IsDateString() periodStart!: string;
  @IsDateString() periodEnd!: string;
}
