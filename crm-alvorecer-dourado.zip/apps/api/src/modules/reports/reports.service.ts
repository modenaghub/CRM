import { Inject, Injectable } from '@nestjs/common';
import { and, desc, eq, gte, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';

// Relatórios gerenciais (prompt-mestre, seção 27 — BI/Relatórios) — todos os
// números aqui são calculados ao vivo a partir do banco, sem dado fictício.
@Injectable()
export class ReportsService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async revenueByMonth(orgId: string, months = 6) {
    const since = new Date();
    since.setMonth(since.getMonth() - (months - 1));
    since.setDate(1);
    since.setHours(0, 0, 0, 0);

    const rows = await this.db.execute<{ month: string; total: string; count: string }>(sql`
      select to_char(date_trunc('month', ${schema.salesOrders.completedAt}), 'YYYY-MM') as month,
             coalesce(sum(${schema.salesOrders.totalValue}), 0) as total,
             count(*) as count
      from ${schema.salesOrders}
      where ${schema.salesOrders.organizationId} = ${orgId}
        and ${schema.salesOrders.status} = 'completed'
        and ${schema.salesOrders.completedAt} >= ${since}
      group by 1
      order by 1
    `);
    const byMonth = new Map((rows as any).rows.map((r: any) => [r.month, { total: Number(r.total), count: Number(r.count) }]));
    const result: { month: string; total: number; count: number }[] = [];
    const cursor = new Date(since);
    for (let i = 0; i < months; i++) {
      const key = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, '0')}`;
      const entry = (byMonth.get(key) as any) ?? { total: 0, count: 0 };
      result.push({ month: key, total: entry.total, count: entry.count });
      cursor.setMonth(cursor.getMonth() + 1);
    }
    return result;
  }

  async topCustomers(orgId: string, limit = 10) {
    const rows = await this.db.execute<any>(sql`
      select c.id, c.company_name as "companyName", c.abc_classification as "abcClassification",
             coalesce(sum(so.total_value), 0) as total, count(so.id) as orders
      from ${schema.salesOrders} so
      join ${schema.customers} c on c.id = so.customer_id
      where so.organization_id = ${orgId} and so.status = 'completed'
      group by c.id, c.company_name, c.abc_classification
      order by total desc
      limit ${limit}
    `);
    return (rows as any).rows.map((r: any) => ({ ...r, total: Number(r.total), orders: Number(r.orders) }));
  }

  async sellerPerformance(orgId: string) {
    const revenueRows = await this.db.execute<any>(sql`
      select u.id, u.name, coalesce(sum(so.total_value), 0) as revenue, count(so.id) as orders
      from ${schema.salesOrders} so
      join ${schema.users} u on u.id = so.seller_id
      where so.organization_id = ${orgId} and so.status = 'completed'
      group by u.id, u.name
    `);
    const wonRows = await this.db
      .select({ ownerId: schema.opportunities.ownerId, value: sql<string>`count(*)` })
      .from(schema.opportunities)
      .where(and(eq(schema.opportunities.organizationId, orgId), eq(schema.opportunities.status, 'won')))
      .groupBy(schema.opportunities.ownerId);

    const wonMap = new Map(wonRows.map((r) => [r.ownerId, Number(r.value)]));
    return (revenueRows as any).rows.map((r: any) => ({
      id: r.id,
      name: r.name,
      revenue: Number(r.revenue),
      orders: Number(r.orders),
      opportunitiesWon: wonMap.get(r.id) ?? 0,
    })).sort((a: any, b: any) => b.revenue - a.revenue);
  }

  async topProducts(orgId: string, limit = 10) {
    const rows = await this.db.execute<any>(sql`
      select p.id, p.name,
             coalesce(sum(soi.quantity), 0) as quantity,
             coalesce(sum(soi.quantity * soi.unit_price - soi.discount), 0) as revenue
      from ${schema.salesOrderItems} soi
      join ${schema.salesOrders} so on so.id = soi.sales_order_id
      join ${schema.products} p on p.id = soi.product_id
      where so.organization_id = ${orgId} and so.status = 'completed'
      group by p.id, p.name
      order by revenue desc
      limit ${limit}
    `);
    return (rows as any).rows.map((r: any) => ({ ...r, quantity: Number(r.quantity), revenue: Number(r.revenue) }));
  }

  async funnelConversion(orgId: string) {
    const [[{ value: prospectsTotal }], [{ value: prospectsConverted }], [{ value: customersTotal }], [{ value: opportunitiesOpen }], [{ value: opportunitiesWon }], [{ value: opportunitiesLost }], [wonValueRow]] = await Promise.all([
      this.db.select({ value: sql<string>`count(*)` }).from(schema.prospects).where(eq(schema.prospects.organizationId, orgId)),
      this.db.select({ value: sql<string>`count(*)` }).from(schema.prospects).where(and(eq(schema.prospects.organizationId, orgId), sql`${schema.prospects.convertedToCustomerId} is not null`)),
      this.db.select({ value: sql<string>`count(*)` }).from(schema.customers).where(eq(schema.customers.organizationId, orgId)),
      this.db.select({ value: sql<string>`count(*)` }).from(schema.opportunities).where(and(eq(schema.opportunities.organizationId, orgId), eq(schema.opportunities.status, 'open'))),
      this.db.select({ value: sql<string>`count(*)` }).from(schema.opportunities).where(and(eq(schema.opportunities.organizationId, orgId), eq(schema.opportunities.status, 'won'))),
      this.db.select({ value: sql<string>`count(*)` }).from(schema.opportunities).where(and(eq(schema.opportunities.organizationId, orgId), eq(schema.opportunities.status, 'lost'))),
      this.db.select({ total: sql<string>`coalesce(sum(${schema.opportunities.value}), 0)` }).from(schema.opportunities).where(and(eq(schema.opportunities.organizationId, orgId), eq(schema.opportunities.status, 'won'))),
    ]);
    const pTotal = Number(prospectsTotal);
    const pConv = Number(prospectsConverted);
    return {
      prospectsTotal: pTotal,
      prospectsConverted: pConv,
      conversionRate: pTotal > 0 ? Number(((pConv / pTotal) * 100).toFixed(1)) : 0,
      customersTotal: Number(customersTotal),
      opportunitiesOpen: Number(opportunitiesOpen),
      opportunitiesWon: Number(opportunitiesWon),
      opportunitiesLost: Number(opportunitiesLost),
      opportunitiesWonValue: Number(wonValueRow.total),
      winRate: Number(opportunitiesWon) + Number(opportunitiesLost) > 0
        ? Number(((Number(opportunitiesWon) / (Number(opportunitiesWon) + Number(opportunitiesLost))) * 100).toFixed(1))
        : 0,
    };
  }

  async activitySummary(orgId: string) {
    const rows = await this.db
      .select({ type: schema.activityTasks.type, status: schema.activityTasks.status, value: sql<string>`count(*)` })
      .from(schema.activityTasks)
      .where(and(eq(schema.activityTasks.organizationId, orgId), sql`${schema.activityTasks.type} in ('call','whatsapp','email','meeting','visit','followup')`))
      .groupBy(schema.activityTasks.type, schema.activityTasks.status);

    const summary: Record<string, { done: number; pending: number; overdue: number }> = {};
    for (const r of rows) {
      summary[r.type] ??= { done: 0, pending: 0, overdue: 0 };
      if (r.status === 'done') summary[r.type].done += Number(r.value);
      else if (r.status === 'overdue') summary[r.type].overdue += Number(r.value);
      else summary[r.type].pending += Number(r.value);
    }
    return summary;
  }

  async purchasesSummary(orgId: string) {
    const [[totalsRow], supplierRows] = await Promise.all([
      this.db
        .select({ total: sql<string>`coalesce(sum(${schema.purchaseOrders.totalValue}), 0)`, orders: sql<string>`count(*)` })
        .from(schema.purchaseOrders)
        .where(and(eq(schema.purchaseOrders.organizationId, orgId), eq(schema.purchaseOrders.status, 'received'))),
      this.db.execute<any>(sql`
        select s.id, s.company_name as "companyName", coalesce(sum(po.total_value), 0) as total, count(po.id) as orders
        from ${schema.purchaseOrders} po
        join ${schema.suppliers} s on s.id = po.supplier_id
        where po.organization_id = ${orgId} and po.status = 'received'
        group by s.id, s.company_name
        order by total desc
        limit 10
      `),
    ]);
    return {
      totalSpent: Number(totalsRow.total),
      ordersReceived: Number(totalsRow.orders),
      topSuppliers: (supplierRows as any).rows.map((r: any) => ({ ...r, total: Number(r.total), orders: Number(r.orders) })),
    };
  }

  async topDeals(orgId: string, status: 'open' | 'won' = 'open', limit = 5) {
    const rows = await this.db.execute<any>(sql`
      select o.id, o.title, o.value, o.status, o.probability,
             coalesce(c.company_name, pr.company_name) as "accountName",
             st.name as "stageName", st.color as "stageColor"
      from ${schema.opportunities} o
      left join ${schema.customers} c on c.id = o.customer_id
      left join ${schema.prospects} pr on pr.id = o.prospect_id
      left join ${schema.pipelineStages} st on st.id = o.stage_id
      where o.organization_id = ${orgId} and o.status = ${status}
      order by o.value desc nulls last
      limit ${limit}
    `);
    return (rows as any).rows.map((r: any) => ({ ...r, value: r.value != null ? Number(r.value) : null }));
  }

  async geoDistribution(orgId: string) {
    const rows = await this.db.execute<any>(sql`
      select coalesce(nullif(${schema.customers.state}, ''), '—') as state,
             coalesce(nullif(${schema.customers.city}, ''), '—') as city,
             coalesce(nullif(${schema.customers.country}, ''), 'Brasil') as country,
             count(*) as customers,
             coalesce(sum(${schema.customers.ltv}), 0) as "totalLtv"
      from ${schema.customers}
      where ${schema.customers.organizationId} = ${orgId}
      group by 1, 2, 3
      order by state, city
    `);
    return (rows as any).rows.map((r: any) => ({ ...r, customers: Number(r.customers), totalLtv: Number(r.totalLtv) }));
  }
}
