import { Controller, Get, Query } from '@nestjs/common';
import { CurrentOrg } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { ReportsService } from './reports.service';

@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('revenue-by-month')
  @RequirePermission('bi', 'view')
  revenueByMonth(@CurrentOrg() orgId: string, @Query('months') months?: string) {
    return this.reportsService.revenueByMonth(orgId, months ? Number(months) : undefined);
  }

  @Get('top-customers')
  @RequirePermission('bi', 'view')
  topCustomers(@CurrentOrg() orgId: string, @Query('limit') limit?: string) {
    return this.reportsService.topCustomers(orgId, limit ? Number(limit) : undefined);
  }

  @Get('seller-performance')
  @RequirePermission('bi', 'view')
  sellerPerformance(@CurrentOrg() orgId: string) {
    return this.reportsService.sellerPerformance(orgId);
  }

  @Get('top-products')
  @RequirePermission('bi', 'view')
  topProducts(@CurrentOrg() orgId: string, @Query('limit') limit?: string) {
    return this.reportsService.topProducts(orgId, limit ? Number(limit) : undefined);
  }

  @Get('funnel-conversion')
  @RequirePermission('bi', 'view')
  funnelConversion(@CurrentOrg() orgId: string) {
    return this.reportsService.funnelConversion(orgId);
  }

  @Get('activity-summary')
  @RequirePermission('bi', 'view')
  activitySummary(@CurrentOrg() orgId: string) {
    return this.reportsService.activitySummary(orgId);
  }

  @Get('purchases-summary')
  @RequirePermission('bi', 'view')
  purchasesSummary(@CurrentOrg() orgId: string) {
    return this.reportsService.purchasesSummary(orgId);
  }

  @Get('top-deals')
  @RequirePermission('bi', 'view')
  topDeals(@CurrentOrg() orgId: string, @Query('status') status?: 'open' | 'won', @Query('limit') limit?: string) {
    return this.reportsService.topDeals(orgId, status, limit ? Number(limit) : undefined);
  }

  @Get('geo')
  @RequirePermission('bi', 'view')
  geoDistribution(@CurrentOrg() orgId: string) {
    return this.reportsService.geoDistribution(orgId);
  }
}
