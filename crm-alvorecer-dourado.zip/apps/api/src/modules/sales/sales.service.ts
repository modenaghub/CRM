import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { and, desc, eq, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';
import { AuditService } from '../audit/audit.service';
import { CreateQuoteDto } from './dto/create-quote.dto';
import { UpdateQuoteDto } from './dto/update-quote.dto';
import { UpdateSalesOrderDto } from './dto/update-sales-order.dto';

function computeTotals(items: { quantity: number; unitPrice: number; discount?: number }[], freight = 0, orderDiscount = 0) {
  const subtotal = items.reduce((acc, i) => acc + i.quantity * i.unitPrice - (i.discount ?? 0), 0);
  const total = Math.max(0, subtotal + Number(freight) - Number(orderDiscount));
  return { subtotal, total };
}

// Módulo de Vendas (prompt-mestre, seção 11): Oportunidade → Orçamento →
// Pedido → Venda → Pós-venda.
@Injectable()
export class SalesService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly events: EventEmitter2,
    private readonly audit: AuditService,
  ) {}

  // ---------------------------------------------------------------- QUOTES

  async listQuotes(orgId: string, customerId?: string, status?: string) {
    const conditions = [eq(schema.quotes.organizationId, orgId)];
    if (customerId) conditions.push(eq(schema.quotes.customerId, customerId));
    if (status) conditions.push(eq(schema.quotes.status, status));
    return this.db.select().from(schema.quotes).where(and(...conditions)).orderBy(desc(schema.quotes.createdAt));
  }

  async findQuote(orgId: string, id: string) {
    const quote = await this.getOwnedQuote(orgId, id);
    const items = await this.db.select().from(schema.quoteItems).where(eq(schema.quoteItems.quoteId, id));
    return { ...quote, items };
  }

  async createQuote(orgId: string, dto: CreateQuoteDto, userId: string) {
    const { subtotal, total } = computeTotals(dto.items, dto.freight, dto.discount);
    const [{ nextNumber }] = await this.db
      .select({ nextNumber: sql<number>`coalesce(max(${schema.quotes.number}), 0) + 1` })
      .from(schema.quotes)
      .where(eq(schema.quotes.organizationId, orgId));

    const [quote] = await this.db
      .insert(schema.quotes)
      .values({
        organizationId: orgId,
        number: Number(nextNumber),
        customerId: dto.customerId,
        opportunityId: dto.opportunityId,
        sellerId: dto.sellerId ?? userId,
        validUntil: dto.validUntil ? new Date(dto.validUntil) : undefined,
        paymentTerms: dto.paymentTerms,
        freight: String(dto.freight ?? 0),
        discount: String(dto.discount ?? 0),
        notes: dto.notes,
        subtotal: String(subtotal),
        totalValue: String(total),
      })
      .returning();

    await this.db.insert(schema.quoteItems).values(
      dto.items.map((i) => ({
        quoteId: quote.id,
        productId: i.productId,
        serviceId: i.serviceId,
        description: i.description,
        quantity: String(i.quantity),
        unitPrice: String(i.unitPrice),
        discount: String(i.discount ?? 0),
      })),
    );

    this.events.emit('quote.created', quote);
    await this.audit.log({ organizationId: orgId, userId, action: 'create', entityType: 'quote', entityId: quote.id, after: quote });
    return this.findQuote(orgId, quote.id);
  }

  async updateQuote(orgId: string, id: string, dto: UpdateQuoteDto, userId: string) {
    const existing = await this.getOwnedQuote(orgId, id);
    const [row] = await this.db
      .update(schema.quotes)
      .set({ ...dto, updatedAt: new Date() })
      .where(eq(schema.quotes.id, id))
      .returning();
    await this.audit.log({ organizationId: orgId, userId, action: 'update', entityType: 'quote', entityId: id, before: existing, after: row });
    return row;
  }

  // "Conversão em pedido" (prompt-mestre, seção 11 e critério de aceitação, seção 57)
  async convertQuoteToOrder(orgId: string, id: string, userId: string) {
    const quote = await this.findQuote(orgId, id);
    if (quote.status === 'converted') throw new BadRequestException('Este orçamento já foi convertido em pedido.');

    const [{ nextNumber }] = await this.db
      .select({ nextNumber: sql<number>`coalesce(max(${schema.salesOrders.number}), 0) + 1` })
      .from(schema.salesOrders)
      .where(eq(schema.salesOrders.organizationId, orgId));

    const [order] = await this.db
      .insert(schema.salesOrders)
      .values({
        organizationId: orgId,
        number: Number(nextNumber),
        quoteId: quote.id,
        customerId: quote.customerId,
        sellerId: quote.sellerId,
        paymentTerms: quote.paymentTerms,
        freight: quote.freight,
        discount: quote.discount,
        notes: quote.notes,
        subtotal: quote.subtotal,
        totalValue: quote.totalValue,
        status: 'pending',
      })
      .returning();

    await this.db.insert(schema.salesOrderItems).values(
      quote.items.map((i: any) => ({
        salesOrderId: order.id,
        productId: i.productId,
        serviceId: i.serviceId,
        description: i.description,
        quantity: i.quantity,
        unitPrice: i.unitPrice,
        discount: i.discount,
      })),
    );

    await this.db.update(schema.quotes).set({ status: 'converted', convertedToOrderId: order.id, updatedAt: new Date() }).where(eq(schema.quotes.id, id));

    this.events.emit('sales_order.created', order);
    await this.audit.log({ organizationId: orgId, userId, action: 'convert', entityType: 'quote', entityId: id, after: { convertedToOrderId: order.id } });
    return this.findOrder(orgId, order.id);
  }

  async removeQuote(orgId: string, id: string) {
    await this.getOwnedQuote(orgId, id);
    await this.db.delete(schema.quoteItems).where(eq(schema.quoteItems.quoteId, id));
    await this.db.delete(schema.quotes).where(eq(schema.quotes.id, id));
    return { success: true };
  }

  // ------------------------------------------------------------- ORDERS

  async listOrders(orgId: string, customerId?: string, status?: string) {
    const conditions = [eq(schema.salesOrders.organizationId, orgId)];
    if (customerId) conditions.push(eq(schema.salesOrders.customerId, customerId));
    if (status) conditions.push(eq(schema.salesOrders.status, status));
    return this.db.select().from(schema.salesOrders).where(and(...conditions)).orderBy(desc(schema.salesOrders.createdAt));
  }

  async findOrder(orgId: string, id: string) {
    const order = await this.getOwnedOrder(orgId, id);
    const items = await this.db.select().from(schema.salesOrderItems).where(eq(schema.salesOrderItems.salesOrderId, id));
    return { ...order, items };
  }

  // "Criar venda -> deve atualizar indicadores" (prompt-mestre, seção 51)
  async updateOrderStatus(orgId: string, id: string, dto: UpdateSalesOrderDto, userId: string) {
    const existing = await this.getOwnedOrder(orgId, id);
    const values: any = { ...dto, updatedAt: new Date() };
    const wasCompleted = existing.status === 'completed';

    if (dto.status === 'completed' && !wasCompleted) {
      values.completedAt = new Date();
    }

    const [row] = await this.db.update(schema.salesOrders).set(values).where(eq(schema.salesOrders.id, id)).returning();

    if (dto.status === 'completed' && !wasCompleted) {
      await this.applyCustomerIndicators(row);
      this.events.emit('sales_order.completed', row);
    }

    await this.audit.log({ organizationId: orgId, userId, action: 'update_status', entityType: 'sales_order', entityId: id, before: { status: existing.status }, after: { status: row.status } });
    return row;
  }

  private async applyCustomerIndicators(order: typeof schema.salesOrders.$inferSelect) {
    const customer = await this.db.query.customers.findFirst({ where: eq(schema.customers.id, order.customerId) });
    if (!customer) return;

    const completedOrders = await this.db
      .select()
      .from(schema.salesOrders)
      .where(and(eq(schema.salesOrders.customerId, order.customerId), eq(schema.salesOrders.status, 'completed')));

    const totalValue = completedOrders.reduce((acc, o) => acc + Number(o.totalValue), 0);
    const ticketAverage = completedOrders.length ? totalValue / completedOrders.length : 0;

    await this.db
      .update(schema.customers)
      .set({
        lastPurchaseAt: new Date(),
        firstPurchaseAt: customer.firstPurchaseAt ?? new Date(),
        ticketAverage: String(ticketAverage.toFixed(2)),
        ltv: String(totalValue.toFixed(2)),
        updatedAt: new Date(),
      })
      .where(eq(schema.customers.id, order.customerId));
  }

  private async getOwnedQuote(orgId: string, id: string) {
    const existing = await this.db.query.quotes.findFirst({ where: and(eq(schema.quotes.id, id), eq(schema.quotes.organizationId, orgId)) });
    if (!existing) throw new NotFoundException('Orçamento não encontrado.');
    return existing;
  }

  private async getOwnedOrder(orgId: string, id: string) {
    const existing = await this.db.query.salesOrders.findFirst({ where: and(eq(schema.salesOrders.id, id), eq(schema.salesOrders.organizationId, orgId)) });
    if (!existing) throw new NotFoundException('Pedido de venda não encontrado.');
    return existing;
  }
}
