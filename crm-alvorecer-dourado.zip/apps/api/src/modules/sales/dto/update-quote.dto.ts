import { IsIn, IsOptional, IsString } from 'class-validator';

export class UpdateQuoteDto {
  @IsOptional()
  @IsIn(['draft', 'sent', 'approved', 'rejected', 'expired'])
  status?: string;

  @IsOptional() @IsString() notes?: string;
}
