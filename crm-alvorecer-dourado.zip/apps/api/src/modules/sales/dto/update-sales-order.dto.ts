import { IsIn, IsOptional, IsString } from 'class-validator';

export class UpdateSalesOrderDto {
  @IsOptional()
  @IsIn(['pending', 'confirmed', 'invoiced', 'completed', 'cancelled'])
  status?: string;

  @IsOptional() @IsString() notes?: string;
}
