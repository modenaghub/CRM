import { Type } from 'class-transformer';
import { ArrayMinSize, IsArray, IsDateString, IsNumber, IsOptional, IsString, Min, ValidateNested } from 'class-validator';
import { QuoteItemDto } from './quote-item.dto';

// Orçamento (prompt-mestre, seção 11: Oportunidade → Orçamento → Pedido → Venda).
export class CreateQuoteDto {
  @IsString() customerId!: string;
  @IsOptional() @IsString() opportunityId?: string;
  @IsOptional() @IsString() sellerId?: string;
  @IsOptional() @IsDateString() validUntil?: string;
  @IsOptional() @IsString() paymentTerms?: string;
  @IsOptional() @IsNumber() @Min(0) freight?: number;
  @IsOptional() @IsNumber() @Min(0) discount?: number;
  @IsOptional() @IsString() notes?: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => QuoteItemDto)
  items!: QuoteItemDto[];
}
