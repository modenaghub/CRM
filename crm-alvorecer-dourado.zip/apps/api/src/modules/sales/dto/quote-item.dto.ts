import { IsNumber, IsOptional, IsString, Min } from 'class-validator';

export class QuoteItemDto {
  @IsOptional() @IsString() productId?: string;
  @IsOptional() @IsString() serviceId?: string;
  @IsOptional() @IsString() description?: string;

  @IsNumber() @Min(0.001) quantity!: number;
  @IsNumber() @Min(0) unitPrice!: number;
  @IsOptional() @IsNumber() @Min(0) discount?: number;
}
