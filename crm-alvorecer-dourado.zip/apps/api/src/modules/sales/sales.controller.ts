import { Body, Controller, Delete, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { CurrentOrg, CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { SalesService } from './sales.service';
import { CreateQuoteDto } from './dto/create-quote.dto';
import { UpdateQuoteDto } from './dto/update-quote.dto';
import { UpdateSalesOrderDto } from './dto/update-sales-order.dto';

@Controller()
export class SalesController {
  constructor(private readonly salesService: SalesService) {}

  // ---- Orçamentos ----
  @Get('quotes')
  @RequirePermission('sales', 'view')
  listQuotes(@CurrentOrg() orgId: string, @Query('customerId') customerId?: string, @Query('status') status?: string) {
    return this.salesService.listQuotes(orgId, customerId, status);
  }

  @Get('quotes/:id')
  @RequirePermission('sales', 'view')
  findQuote(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.salesService.findQuote(orgId, id);
  }

  @Post('quotes')
  @RequirePermission('sales', 'create')
  createQuote(@CurrentOrg() orgId: string, @Body() dto: CreateQuoteDto, @CurrentUser() user: AuthUser) {
    return this.salesService.createQuote(orgId, dto, user.sub);
  }

  @Patch('quotes/:id')
  @RequirePermission('sales', 'edit')
  updateQuote(@CurrentOrg() orgId: string, @Param('id') id: string, @Body() dto: UpdateQuoteDto, @CurrentUser() user: AuthUser) {
    return this.salesService.updateQuote(orgId, id, dto, user.sub);
  }

  @Post('quotes/:id/convert')
  @RequirePermission('sales', 'create')
  convertQuote(@CurrentOrg() orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.salesService.convertQuoteToOrder(orgId, id, user.sub);
  }

  @Delete('quotes/:id')
  @RequirePermission('sales', 'delete')
  removeQuote(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.salesService.removeQuote(orgId, id);
  }

  // ---- Pedidos de venda ----
  @Get('sales-orders')
  @RequirePermission('sales', 'view')
  listOrders(@CurrentOrg() orgId: string, @Query('customerId') customerId?: string, @Query('status') status?: string) {
    return this.salesService.listOrders(orgId, customerId, status);
  }

  @Get('sales-orders/:id')
  @RequirePermission('sales', 'view')
  findOrder(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.salesService.findOrder(orgId, id);
  }

  @Patch('sales-orders/:id/status')
  @RequirePermission('sales', 'edit')
  updateOrderStatus(@CurrentOrg() orgId: string, @Param('id') id: string, @Body() dto: UpdateSalesOrderDto, @CurrentUser() user: AuthUser) {
    return this.salesService.updateOrderStatus(orgId, id, dto, user.sub);
  }
}
