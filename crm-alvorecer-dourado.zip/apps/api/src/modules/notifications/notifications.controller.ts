import { Controller, Get, Param, Post } from '@nestjs/common';
import { CurrentOrg, CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { NotificationsService } from './notifications.service';

@Controller('notifications')
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Get()
  listMine(@CurrentOrg() orgId: string, @CurrentUser() user: AuthUser) {
    return this.notificationsService.listMine(orgId, user.sub);
  }

  @Post(':id/read')
  markRead(@CurrentOrg() orgId: string, @CurrentUser() user: AuthUser, @Param('id') id: string) {
    return this.notificationsService.markRead(orgId, user.sub, id);
  }

  @Post('read-all')
  markAllRead(@CurrentOrg() orgId: string, @CurrentUser() user: AuthUser) {
    return this.notificationsService.markAllRead(orgId, user.sub);
  }
}
