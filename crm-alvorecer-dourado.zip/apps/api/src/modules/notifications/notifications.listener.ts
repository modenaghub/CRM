import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { NotificationsService } from './notifications.service';

// Gera notificações reais a partir dos eventos de domínio do núcleo
// (prompt-mestre, seção 27: "Notificar: nova oportunidade, tarefa atrasada,
// venda, compra, alerta da IA...").
@Injectable()
export class NotificationsListener {
  constructor(private readonly notifications: NotificationsService) {}

  @OnEvent('task.created')
  async onTaskCreated(task: any) {
    if (!task.assigneeId) return;
    await this.notifications.create({
      organizationId: task.organizationId,
      userId: task.assigneeId,
      type: 'task',
      title: 'Nova tarefa atribuída a você',
      body: task.title,
      entityType: 'task',
      entityId: task.id,
    });
  }

  @OnEvent('opportunity.won')
  async onOpportunityWon(opportunity: any) {
    if (!opportunity.ownerId) return;
    await this.notifications.create({
      organizationId: opportunity.organizationId,
      userId: opportunity.ownerId,
      type: 'opportunity_won',
      title: 'Oportunidade ganha! 🎉',
      body: opportunity.title,
      entityType: 'opportunity',
      entityId: opportunity.id,
    });
  }

  @OnEvent('sales_order.completed')
  async onSalesOrderCompleted(order: any) {
    if (!order.sellerId) return;
    await this.notifications.create({
      organizationId: order.organizationId,
      userId: order.sellerId,
      type: 'sale',
      title: `Venda #${order.number} concluída`,
      body: 'Pedido convertido em venda com sucesso.',
      entityType: 'sales_order',
      entityId: order.id,
    });
  }

  @OnEvent('purchase_order.received')
  async onPurchaseOrderReceived(order: any) {
    if (!order.buyerId) return;
    await this.notifications.create({
      organizationId: order.organizationId,
      userId: order.buyerId,
      type: 'purchase',
      title: `Pedido de compra #${order.number} recebido`,
      body: 'Estoque atualizado automaticamente.',
      entityType: 'purchase_order',
      entityId: order.id,
    });
  }
}
