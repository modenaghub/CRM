import { Inject, Injectable } from '@nestjs/common';
import { and, desc, eq } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';

// Central de notificações (prompt-mestre, seção 27).
@Injectable()
export class NotificationsService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async create(params: {
    organizationId: string;
    userId: string;
    type: string;
    title: string;
    body?: string;
    entityType?: string;
    entityId?: string;
  }) {
    const [row] = await this.db.insert(schema.notifications).values(params).returning();
    return row;
  }

  async listMine(orgId: string, userId: string) {
    return this.db
      .select()
      .from(schema.notifications)
      .where(and(eq(schema.notifications.organizationId, orgId), eq(schema.notifications.userId, userId)))
      .orderBy(desc(schema.notifications.createdAt))
      .limit(30);
  }

  async markRead(orgId: string, userId: string, id: string) {
    const [row] = await this.db
      .update(schema.notifications)
      .set({ read: true })
      .where(and(eq(schema.notifications.id, id), eq(schema.notifications.organizationId, orgId), eq(schema.notifications.userId, userId)))
      .returning();
    return row;
  }

  async markAllRead(orgId: string, userId: string) {
    await this.db
      .update(schema.notifications)
      .set({ read: true })
      .where(and(eq(schema.notifications.organizationId, orgId), eq(schema.notifications.userId, userId)));
    return { success: true };
  }
}
