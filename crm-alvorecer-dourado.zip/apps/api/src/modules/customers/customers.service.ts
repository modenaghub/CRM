import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { and, count, desc, eq, getTableColumns, ilike, or, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';
import { PaginationQueryDto } from '../../common/dto/pagination-query.dto';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';

@Injectable()
export class CustomersService {
  constructor(
    @Inject(DB) private readonly db: Db,
    private readonly events: EventEmitter2,
  ) {}

  async list(orgId: string, query: PaginationQueryDto) {
    const conditions = [eq(schema.customers.organizationId, orgId)];
    if (query.status) conditions.push(eq(schema.customers.status, query.status));
    if (query.search) {
      conditions.push(
        or(
          ilike(schema.customers.companyName, `%${query.search}%`),
          ilike(schema.customers.document, `%${query.search}%`),
          ilike(schema.customers.email, `%${query.search}%`),
        )!,
      );
    }
    const where = and(...conditions);

    const [{ total }] = await this.db.select({ total: count() }).from(schema.customers).where(where);
    // Cards do Cliente 360º precisam de um resumo (estágio, vendas, contatos,
    // última interação) sem N+1 — subqueries correlacionadas resolvem isso em
    // uma única consulta.
    const rows = await this.db
      .select({
        ...getTableColumns(schema.customers),
        // OBS: a coluna do lado esquerdo precisa ser qualificada com o nome da
        // tabela (via sql.raw) — dentro da subquery correlacionada, um Column
        // interpolado sem qualificação resolve para a tabela da própria
        // subquery (bug sutil do drizzle-orm 0.36 com sql`` + subqueries).
        openOpportunities: sql<number>`(select count(*) from ${schema.opportunities} o where o.customer_id = ${sql.raw('"customers"."id"')} and o.status = 'open')`.mapWith(Number),
        salesCount: sql<number>`(select count(*) from ${schema.salesOrders} so where so.customer_id = ${sql.raw('"customers"."id"')} and so.status = 'completed')`.mapWith(Number),
        salesTotal: sql<number>`(select coalesce(sum(so.total_value),0) from ${schema.salesOrders} so where so.customer_id = ${sql.raw('"customers"."id"')} and so.status = 'completed')`.mapWith(Number),
        contactsCount: sql<number>`(select count(*) from ${schema.contacts} ct where ct.customer_id = ${sql.raw('"customers"."id"')})`.mapWith(Number),
        lastInteractionAt: sql<string | null>`(select max(at.completed_at) from ${schema.activityTasks} at where at.customer_id = ${sql.raw('"customers"."id"')} and at.completed_at is not null)`,
      })
      .from(schema.customers)
      .where(where)
      .orderBy(desc(schema.customers.createdAt))
      .limit(query.pageSize)
      .offset((query.page - 1) * query.pageSize);

    return { data: rows, total: Number(total), page: query.page, pageSize: query.pageSize };
  }

  // Cliente 360º (prompt-mestre, seção 45) — visão consolidada em uma tela só.
  async findOne360(orgId: string, id: string) {
    const customer = await this.db.query.customers.findFirst({
      where: and(eq(schema.customers.id, id), eq(schema.customers.organizationId, orgId)),
    });
    if (!customer) throw new NotFoundException('Cliente não encontrado.');

    const [contacts, opportunities, tasks, notes, quotes, salesOrders] = await Promise.all([
      this.db.select().from(schema.contacts).where(eq(schema.contacts.customerId, id)),
      this.db.select().from(schema.opportunities).where(eq(schema.opportunities.customerId, id)),
      this.db.select().from(schema.activityTasks).where(eq(schema.activityTasks.customerId, id)),
      this.db.select().from(schema.notes).where(eq(schema.notes.customerId, id)).orderBy(desc(schema.notes.createdAt)),
      this.db.select().from(schema.quotes).where(eq(schema.quotes.customerId, id)).orderBy(desc(schema.quotes.createdAt)),
      this.db.select().from(schema.salesOrders).where(eq(schema.salesOrders.customerId, id)).orderBy(desc(schema.salesOrders.createdAt)),
    ]);

    return { ...customer, contacts, opportunities, tasks, notes, quotes, salesOrders };
  }

  async create(orgId: string, dto: CreateCustomerDto) {
    const [row] = await this.db.insert(schema.customers).values({ organizationId: orgId, ...dto }).returning();
    this.events.emit('customer.created', row);
    return row;
  }

  async update(orgId: string, id: string, dto: UpdateCustomerDto) {
    const existing = await this.db.query.customers.findFirst({
      where: and(eq(schema.customers.id, id), eq(schema.customers.organizationId, orgId)),
    });
    if (!existing) throw new NotFoundException('Cliente não encontrado.');
    const [row] = await this.db
      .update(schema.customers)
      .set({ ...dto, updatedAt: new Date() })
      .where(eq(schema.customers.id, id))
      .returning();
    this.events.emit('customer.updated', row);
    return row;
  }

  async remove(orgId: string, id: string) {
    const existing = await this.db.query.customers.findFirst({
      where: and(eq(schema.customers.id, id), eq(schema.customers.organizationId, orgId)),
    });
    if (!existing) throw new NotFoundException('Cliente não encontrado.');
    await this.db.delete(schema.customers).where(eq(schema.customers.id, id));
    return { success: true };
  }
}
