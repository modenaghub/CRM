import { Inject, Injectable } from '@nestjs/common';
import { and, desc, eq } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';

// Auditoria (prompt-mestre, seção 22): registra quem fez o quê, quando, e o
// valor antes/depois, para qualquer entidade relevante do núcleo.
@Injectable()
export class AuditService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async log(params: {
    organizationId: string;
    userId?: string | null;
    action: string; // create | update | delete | move_stage | convert | receive
    entityType: string;
    entityId: string;
    before?: any;
    after?: any;
  }) {
    await this.db.insert(schema.auditLogs).values({
      organizationId: params.organizationId,
      userId: params.userId ?? null,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId,
      before: params.before ?? null,
      after: params.after ?? null,
    });
  }

  async listRecent(orgId: string, limit = 50, entityType?: string) {
    const conditions = [eq(schema.auditLogs.organizationId, orgId)];
    if (entityType) conditions.push(eq(schema.auditLogs.entityType, entityType));

    const rows = await this.db
      .select({
        log: schema.auditLogs,
        userName: schema.users.name,
      })
      .from(schema.auditLogs)
      .leftJoin(schema.users, eq(schema.users.id, schema.auditLogs.userId))
      .where(and(...conditions))
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(limit);

    return rows.map((r) => ({ ...r.log, userName: r.userName ?? 'Sistema' }));
  }
}
