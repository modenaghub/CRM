import { Controller, Get, Query } from '@nestjs/common';
import { CurrentOrg } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { AuditService } from './audit.service';

@Controller('audit-logs')
export class AuditController {
  constructor(private readonly auditService: AuditService) {}

  @Get()
  @RequirePermission('audit', 'view')
  list(@CurrentOrg() orgId: string, @Query('entityType') entityType?: string, @Query('limit') limit?: string) {
    return this.auditService.listRecent(orgId, limit ? Number(limit) : 50, entityType);
  }
}
