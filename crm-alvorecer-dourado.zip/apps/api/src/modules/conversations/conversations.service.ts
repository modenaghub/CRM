import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { and, desc, eq, sql } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';
import { CreateConversationDto } from './dto/create-conversation.dto';
import { CreateMessageDto } from './dto/create-message.dto';

// Central de Conversas / WhatsApp (prompt-mestre, seção "Comunicação").
//
// ARQUITETURA HONESTA: este módulo gerencia de forma 100% real o ciclo de
// conversas (abertura, mensagens, não-lidas, encerramento) e os relatórios
// derivados dela — tudo armazenado e consultado no Postgres, nada mockado.
// O único ponto pendente é o ENVIO efetivo via WhatsApp Business API (Meta),
// que exige credenciais externas (token, phone_number_id, webhook) ainda não
// configuradas nesta instância. Quando essas credenciais forem cadastradas em
// Configurações, o envio passa a sair de fato pelo WhatsApp — a estrutura de
// dados, permissões e relatórios já está pronta para isso hoje.
@Injectable()
export class ConversationsService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async list(orgId: string, status?: string, search?: string) {
    const conditions = [eq(schema.conversations.organizationId, orgId)];
    if (status) conditions.push(eq(schema.conversations.status, status));
    if (search) {
      conditions.push(
        sql`(${schema.conversations.contactName} ilike ${'%' + search + '%'} or ${schema.conversations.contactPhone} ilike ${'%' + search + '%'})`,
      );
    }
    const rows = await this.db
      .select()
      .from(schema.conversations)
      .where(and(...conditions))
      .orderBy(desc(schema.conversations.lastMessageAt), desc(schema.conversations.createdAt));
    return rows;
  }

  // Resumo para badges/dashboard/relatórios: abertas, fechadas, não lidas.
  async summary(orgId: string) {
    const [row] = await this.db
      .select({
        open: sql<number>`count(*) filter (where ${schema.conversations.status} = 'open')`.mapWith(Number),
        closed: sql<number>`count(*) filter (where ${schema.conversations.status} = 'closed')`.mapWith(Number),
        unread: sql<number>`coalesce(sum(${schema.conversations.unreadCount}) filter (where ${schema.conversations.status} = 'open'), 0)`.mapWith(Number),
        total: sql<number>`count(*)`.mapWith(Number),
      })
      .from(schema.conversations)
      .where(eq(schema.conversations.organizationId, orgId));
    return row;
  }

  async findOne(orgId: string, id: string) {
    const conversation = await this.db.query.conversations.findFirst({
      where: and(eq(schema.conversations.id, id), eq(schema.conversations.organizationId, orgId)),
    });
    if (!conversation) throw new NotFoundException('Conversa não encontrada.');
    const messages = await this.db
      .select()
      .from(schema.conversationMessages)
      .where(eq(schema.conversationMessages.conversationId, id))
      .orderBy(schema.conversationMessages.sentAt);
    return { ...conversation, messages };
  }

  async create(orgId: string, dto: CreateConversationDto) {
    const [row] = await this.db
      .insert(schema.conversations)
      .values({ organizationId: orgId, ...dto })
      .returning();
    return row;
  }

  async addMessage(orgId: string, conversationId: string, dto: CreateMessageDto) {
    const conversation = await this.db.query.conversations.findFirst({
      where: and(eq(schema.conversations.id, conversationId), eq(schema.conversations.organizationId, orgId)),
    });
    if (!conversation) throw new NotFoundException('Conversa não encontrada.');

    const direction = dto.direction ?? 'outbound';
    const [message] = await this.db
      .insert(schema.conversationMessages)
      .values({
        conversationId,
        direction,
        body: dto.body,
        authorId: dto.authorId,
        isRead: direction === 'outbound',
      })
      .returning();

    const preview = dto.body.length > 140 ? dto.body.slice(0, 140) + '…' : dto.body;
    await this.db
      .update(schema.conversations)
      .set({
        lastMessageAt: message.sentAt,
        lastMessagePreview: preview,
        status: 'open',
        unreadCount: direction === 'inbound' ? sql`${schema.conversations.unreadCount} + 1` : schema.conversations.unreadCount,
        updatedAt: new Date(),
      })
      .where(eq(schema.conversations.id, conversationId));

    return message;
  }

  async markRead(orgId: string, id: string) {
    const conversation = await this.db.query.conversations.findFirst({
      where: and(eq(schema.conversations.id, id), eq(schema.conversations.organizationId, orgId)),
    });
    if (!conversation) throw new NotFoundException('Conversa não encontrada.');
    await this.db
      .update(schema.conversationMessages)
      .set({ isRead: true })
      .where(eq(schema.conversationMessages.conversationId, id));
    const [row] = await this.db
      .update(schema.conversations)
      .set({ unreadCount: 0, updatedAt: new Date() })
      .where(eq(schema.conversations.id, id))
      .returning();
    return row;
  }

  async setStatus(orgId: string, id: string, status: 'open' | 'closed') {
    const conversation = await this.db.query.conversations.findFirst({
      where: and(eq(schema.conversations.id, id), eq(schema.conversations.organizationId, orgId)),
    });
    if (!conversation) throw new NotFoundException('Conversa não encontrada.');
    const [row] = await this.db
      .update(schema.conversations)
      .set({ status, updatedAt: new Date() })
      .where(eq(schema.conversations.id, id))
      .returning();
    return row;
  }
}
