import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { CurrentOrg } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/require-permission.decorator';
import { ConversationsService } from './conversations.service';
import { CreateConversationDto } from './dto/create-conversation.dto';
import { CreateMessageDto } from './dto/create-message.dto';

@Controller('conversations')
export class ConversationsController {
  constructor(private readonly conversationsService: ConversationsService) {}

  @Get()
  @RequirePermission('whatsapp', 'view')
  list(@CurrentOrg() orgId: string, @Query('status') status?: string, @Query('search') search?: string) {
    return this.conversationsService.list(orgId, status, search);
  }

  @Get('summary')
  @RequirePermission('whatsapp', 'view')
  summary(@CurrentOrg() orgId: string) {
    return this.conversationsService.summary(orgId);
  }

  @Get(':id')
  @RequirePermission('whatsapp', 'view')
  findOne(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.conversationsService.findOne(orgId, id);
  }

  @Post()
  @RequirePermission('whatsapp', 'create')
  create(@CurrentOrg() orgId: string, @Body() dto: CreateConversationDto) {
    return this.conversationsService.create(orgId, dto);
  }

  @Post(':id/messages')
  @RequirePermission('whatsapp', 'create')
  addMessage(@CurrentOrg() orgId: string, @Param('id') id: string, @Body() dto: CreateMessageDto) {
    return this.conversationsService.addMessage(orgId, id, dto);
  }

  @Post(':id/read')
  @RequirePermission('whatsapp', 'edit')
  markRead(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.conversationsService.markRead(orgId, id);
  }

  @Patch(':id/close')
  @RequirePermission('whatsapp', 'edit')
  close(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.conversationsService.setStatus(orgId, id, 'closed');
  }

  @Patch(':id/reopen')
  @RequirePermission('whatsapp', 'edit')
  reopen(@CurrentOrg() orgId: string, @Param('id') id: string) {
    return this.conversationsService.setStatus(orgId, id, 'open');
  }
}
