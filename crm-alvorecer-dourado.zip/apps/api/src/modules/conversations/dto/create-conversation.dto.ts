import { IsIn, IsOptional, IsString } from 'class-validator';

export class CreateConversationDto {
  @IsOptional() @IsIn(['whatsapp', 'email', 'chat']) channel?: string;

  @IsOptional() @IsString() customerId?: string;
  @IsOptional() @IsString() prospectId?: string;
  @IsOptional() @IsString() supplierId?: string;

  @IsOptional() @IsString() contactName?: string;
  @IsOptional() @IsString() contactPhone?: string;
  @IsOptional() @IsString() assignedToId?: string;
}
