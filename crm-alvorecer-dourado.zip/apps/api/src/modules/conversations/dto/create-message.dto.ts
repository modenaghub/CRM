import { IsIn, IsOptional, IsString, MinLength } from 'class-validator';

export class CreateMessageDto {
  @MinLength(1) body!: string;

  @IsOptional() @IsIn(['inbound', 'outbound']) direction?: string;

  @IsOptional() @IsString() authorId?: string;
}
