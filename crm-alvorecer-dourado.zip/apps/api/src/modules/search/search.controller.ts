import { Controller, Get, Query } from '@nestjs/common';
import { CurrentOrg } from '../../common/decorators/current-user.decorator';
import { SearchService } from './search.service';

@Controller('search')
export class SearchController {
  constructor(private readonly searchService: SearchService) {}

  @Get()
  search(@CurrentOrg() orgId: string, @Query('q') q: string) {
    return this.searchService.search(orgId, q);
  }
}
