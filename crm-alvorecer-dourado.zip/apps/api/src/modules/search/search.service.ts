import { Inject, Injectable } from '@nestjs/common';
import { and, eq, ilike, or } from 'drizzle-orm';
import { DB } from '../../db/db.module';
import { Db } from '../../db/client';
import * as schema from '../../db/schema';

// Pesquisa global (prompt-mestre, seção 24): busca rápida agrupada por
// categoria, por nome/CNPJ/telefone/e-mail/código.
@Injectable()
export class SearchService {
  constructor(@Inject(DB) private readonly db: Db) {}

  async search(orgId: string, q: string) {
    if (!q || q.trim().length < 2) {
      return { customers: [], prospects: [], suppliers: [], products: [], opportunities: [] };
    }
    const term = `%${q.trim()}%`;

    const [customers, prospects, suppliers, products, opportunities] = await Promise.all([
      this.db
        .select({ id: schema.customers.id, label: schema.customers.companyName, sub: schema.customers.document })
        .from(schema.customers)
        .where(and(eq(schema.customers.organizationId, orgId), or(ilike(schema.customers.companyName, term), ilike(schema.customers.document, term), ilike(schema.customers.email, term), ilike(schema.customers.phone, term))!))
        .limit(5),
      this.db
        .select({ id: schema.prospects.id, label: schema.prospects.companyName, sub: schema.prospects.city })
        .from(schema.prospects)
        .where(and(eq(schema.prospects.organizationId, orgId), or(ilike(schema.prospects.companyName, term), ilike(schema.prospects.document, term), ilike(schema.prospects.email, term))!))
        .limit(5),
      this.db
        .select({ id: schema.suppliers.id, label: schema.suppliers.companyName, sub: schema.suppliers.segment })
        .from(schema.suppliers)
        .where(and(eq(schema.suppliers.organizationId, orgId), or(ilike(schema.suppliers.companyName, term), ilike(schema.suppliers.document, term))!))
        .limit(5),
      this.db
        .select({ id: schema.products.id, label: schema.products.name, sub: schema.products.sku })
        .from(schema.products)
        .where(and(eq(schema.products.organizationId, orgId), or(ilike(schema.products.name, term), ilike(schema.products.sku, term), ilike(schema.products.code, term))!))
        .limit(5),
      this.db
        .select({ id: schema.opportunities.id, label: schema.opportunities.title, sub: schema.opportunities.status })
        .from(schema.opportunities)
        .where(and(eq(schema.opportunities.organizationId, orgId), ilike(schema.opportunities.title, term)))
        .limit(5),
    ]);

    return { customers, prospects, suppliers, products, opportunities };
  }
}
