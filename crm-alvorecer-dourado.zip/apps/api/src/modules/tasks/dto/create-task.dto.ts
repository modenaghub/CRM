import { IsDateString, IsIn, IsInt, IsNotEmpty, IsOptional, IsString, Min } from 'class-validator';

// Tarefas e follow-up (prompt-mestre, seção 53). Também usado para registrar
// comunicações já realizadas (ligação/whatsapp/e-mail) no histórico do Cliente 360º.
export class CreateTaskDto {
  @IsString() @IsNotEmpty() type!: string; // call|whatsapp|email|meeting|visit|followup|internal|proposal|return
  @IsString() @IsNotEmpty() title!: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsDateString() dueAt?: string;
  @IsOptional() @IsString() priority?: string;
  @IsOptional() @IsString() assigneeId?: string;
  @IsOptional() @IsString() customerId?: string;
  @IsOptional() @IsString() prospectId?: string;
  @IsOptional() @IsString() opportunityId?: string;
  @IsOptional() @IsString() supplierId?: string;
  @IsOptional() @IsIn(['inbound', 'outbound']) direction?: string;
  @IsOptional() @IsInt() @Min(0) durationMinutes?: number;
  @IsOptional() @IsString() status?: string; // permite registrar já como "done"
}
