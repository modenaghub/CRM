ALTER TABLE "activity_tasks" ADD COLUMN "direction" text;--> statement-breakpoint
ALTER TABLE "activity_tasks" ADD COLUMN "duration_minutes" integer;