CREATE TABLE IF NOT EXISTS "purchase_order_items" (
	"id" text PRIMARY KEY NOT NULL,
	"purchase_order_id" text NOT NULL,
	"product_id" text,
	"description" text,
	"quantity" numeric(14, 3) DEFAULT '1' NOT NULL,
	"unit_cost" numeric(14, 2) NOT NULL,
	"received_quantity" numeric(14, 3) DEFAULT '0' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "purchase_request_items" (
	"id" text PRIMARY KEY NOT NULL,
	"purchase_request_id" text NOT NULL,
	"product_id" text,
	"description" text,
	"quantity" numeric(14, 3) DEFAULT '1' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "purchase_requests" (
	"id" text PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"number" integer NOT NULL,
	"title" text NOT NULL,
	"requester_id" text,
	"status" text DEFAULT 'open' NOT NULL,
	"notes" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "quote_items" (
	"id" text PRIMARY KEY NOT NULL,
	"quote_id" text NOT NULL,
	"product_id" text,
	"service_id" text,
	"description" text,
	"quantity" numeric(14, 3) DEFAULT '1' NOT NULL,
	"unit_price" numeric(14, 2) NOT NULL,
	"discount" numeric(14, 2) DEFAULT '0' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "sales_order_items" (
	"id" text PRIMARY KEY NOT NULL,
	"sales_order_id" text NOT NULL,
	"product_id" text,
	"service_id" text,
	"description" text,
	"quantity" numeric(14, 3) DEFAULT '1' NOT NULL,
	"unit_price" numeric(14, 2) NOT NULL,
	"discount" numeric(14, 2) DEFAULT '0' NOT NULL
);
--> statement-breakpoint
ALTER TABLE "purchase_orders" ALTER COLUMN "supplier_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "purchase_orders" ALTER COLUMN "total_value" SET DEFAULT '0';--> statement-breakpoint
ALTER TABLE "purchase_orders" ALTER COLUMN "total_value" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ALTER COLUMN "customer_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ALTER COLUMN "total_value" SET DEFAULT '0';--> statement-breakpoint
ALTER TABLE "quotes" ALTER COLUMN "total_value" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ALTER COLUMN "customer_id" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ALTER COLUMN "total_value" SET DEFAULT '0';--> statement-breakpoint
ALTER TABLE "sales_orders" ALTER COLUMN "total_value" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "number" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "purchase_request_id" text;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "buyer_id" text;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "expected_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "received_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "notes" text;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "subtotal" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "purchase_orders" ADD COLUMN "updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "number" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "seller_id" text;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "payment_terms" text;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "freight" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "discount" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "notes" text;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "subtotal" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "converted_to_order_id" text;--> statement-breakpoint
ALTER TABLE "quotes" ADD COLUMN "updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "number" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "quote_id" text;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "seller_id" text;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "payment_terms" text;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "freight" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "discount" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "notes" text;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "subtotal" numeric(14, 2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "completed_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "sales_orders" ADD COLUMN "updated_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "purchase_order_items_order_idx" ON "purchase_order_items" USING btree ("purchase_order_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "purchase_request_items_request_idx" ON "purchase_request_items" USING btree ("purchase_request_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "purchase_requests_org_idx" ON "purchase_requests" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "quote_items_quote_idx" ON "quote_items" USING btree ("quote_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "sales_order_items_order_idx" ON "sales_order_items" USING btree ("sales_order_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "purchase_orders_org_idx" ON "purchase_orders" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "purchase_orders_supplier_idx" ON "purchase_orders" USING btree ("supplier_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "quotes_org_idx" ON "quotes" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "quotes_customer_idx" ON "quotes" USING btree ("customer_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "sales_orders_org_idx" ON "sales_orders" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "sales_orders_customer_idx" ON "sales_orders" USING btree ("customer_id");